import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

const String apiBaseUrl = 'https://likezilla.ir/ahmadvand/backend_php';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const PrivateTeacherApp());
}

String money(dynamic value) {
  final n = int.tryParse(value.toString().replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;
  final s = n.toString();
  final out = StringBuffer();
  for (int i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) out.write(',');
    out.write(s[i]);
  }
  return '${out.toString()} تومان';
}

String statusText(String value) {
  switch (value) {
    case 'approved':
      return 'تایید شده';
    case 'rejected':
      return 'رد شده';
    default:
      return 'در انتظار بررسی';
  }
}

Color themeColor(String theme) => theme == 'boy' ? const Color(0xFF3182F6) : const Color(0xFFFF5FA2);

class PrivateTeacherApp extends StatelessWidget {
  const PrivateTeacherApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'کلاس خصوصی',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Roboto',
        colorSchemeSeed: const Color(0xFFFF5FA2),
        scaffoldBackgroundColor: const Color(0xFFF7F7FB),
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(18)),
          filled: true,
          fillColor: Colors.white,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            minimumSize: const Size.fromHeight(52),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          ),
        ),
      ),
      home: const Directionality(textDirection: TextDirection.rtl, child: RootPage()),
    );
  }
}

class ApiError implements Exception {
  ApiError(this.message);
  final String message;
  @override
  String toString() => message;
}

class ApiClient {
  String? token;

  Map<String, String> get headers => <String, String>{
        'Content-Type': 'application/json',
        if (token != null && token!.isNotEmpty) 'Authorization': 'Bearer $token',
      };

  Uri uri(String path) => Uri.parse('$apiBaseUrl$path');

  Future<dynamic> _handle(http.Response res) async {
    dynamic body;
    try {
      body = res.body.isEmpty ? null : jsonDecode(res.body);
    } catch (_) {
      body = null;
    }
    if (res.statusCode >= 200 && res.statusCode < 300) return body;
    if (body is Map && body['message'] != null) throw ApiError(body['message'].toString());
    throw ApiError('خطا در ارتباط با سرور');
  }

  Future<dynamic> _request(Future<http.Response> Function() call) async {
    try {
      return _handle(await call().timeout(const Duration(seconds: 25)));
    } on ApiError {
      rethrow;
    } on SocketException {
      throw ApiError('اتصال به سرور برقرار نشد. اینترنت گوشی، VPN یا DNS دامنه را بررسی کن. اگر APK را با GitHub ساختی، باید نسخه V8 با مجوز اینترنت ساخته شود.');
    } on TimeoutException {
      throw ApiError('سرور دیر پاسخ داد. اینترنت یا هاست را بررسی کن و دوباره تلاش کن.');
    } on http.ClientException catch (e) {
      if (e.message.toLowerCase().contains('failed host lookup')) {
        throw ApiError('دامنه سرور پیدا نشد. اینترنت گوشی یا DNS دامنه را بررسی کن.');
      }
      throw ApiError('ارتباط با سرور برقرار نشد.');
    } catch (_) {
      throw ApiError('خطای ارتباط با سرور.');
    }
  }

  Future<dynamic> get(String path) async => _request(() => http.get(uri(path), headers: headers));
  Future<dynamic> post(String path, Map<String, dynamic> data) async => _request(() => http.post(uri(path), headers: headers, body: jsonEncode(data)));
  Future<dynamic> put(String path, Map<String, dynamic> data) async => _request(() => http.put(uri(path), headers: headers, body: jsonEncode(data)));
  Future<dynamic> patch(String path, Map<String, dynamic> data) async => _request(() => http.patch(uri(path), headers: headers, body: jsonEncode(data)));
  Future<dynamic> delete(String path) async => _request(() => http.delete(uri(path), headers: headers));
}

class AppSettings {
  AppSettings({
    required this.appTitle,
    required this.teacherName,
    required this.cardNumber,
    required this.cardOwner,
    required this.supportPhone,
    required this.paymentHelp,
  });

  factory AppSettings.fromJson(Map<String, dynamic> j) => AppSettings(
        appTitle: j['appTitle']?.toString() ?? 'کلاس خصوصی',
        teacherName: j['teacherName']?.toString() ?? 'خانم معلم',
        cardNumber: j['cardNumber']?.toString() ?? '',
        cardOwner: j['cardOwner']?.toString() ?? '',
        supportPhone: j['supportPhone']?.toString() ?? '',
        paymentHelp: j['paymentHelp']?.toString() ?? 'بعد از کارت‌به‌کارت، رسید را ثبت کن.',
      );

  final String appTitle;
  final String teacherName;
  final String cardNumber;
  final String cardOwner;
  final String supportPhone;
  final String paymentHelp;
}

class UserData {
  UserData({required this.role, required this.name, required this.phone, required this.theme});

  factory UserData.fromJson(Map<String, dynamic> j) => UserData(
        role: j['role']?.toString() ?? '',
        name: j['name']?.toString() ?? '',
        phone: j['phone']?.toString() ?? '',
        theme: j['theme']?.toString() == 'boy' ? 'boy' : 'girl',
      );

  final String role;
  final String name;
  final String phone;
  final String theme;
}

class Course {
  Course({
    required this.id,
    required this.title,
    required this.subject,
    required this.grade,
    required this.price,
    required this.schedule,
    required this.type,
    required this.accessLink,
    required this.description,
    required this.isActive,
    required this.resources,
  });

  factory Course.fromJson(Map<String, dynamic> j) {
    final resources = <Resource>[];
    final raw = j['resources'];
    if (raw is List) {
      for (final item in raw) {
        if (item is Map) resources.add(Resource.fromJson(Map<String, dynamic>.from(item)));
      }
    }
    return Course(
      id: j['id']?.toString() ?? j['_id']?.toString() ?? '',
      title: j['title']?.toString() ?? '',
      subject: j['subject']?.toString() ?? '',
      grade: j['grade']?.toString() ?? '',
      price: int.tryParse(j['price'].toString()) ?? 0,
      schedule: j['schedule']?.toString() ?? '',
      type: j['type']?.toString() == 'offline' ? 'offline' : 'online',
      accessLink: j['accessLink']?.toString() ?? '',
      description: j['description']?.toString() ?? '',
      isActive: j['isActive'] == true || j['isActive'] == 1,
      resources: resources,
    );
  }

  final String id;
  final String title;
  final String subject;
  final String grade;
  final int price;
  final String schedule;
  final String type;
  final String accessLink;
  final String description;
  final bool isActive;
  final List<Resource> resources;
}

class Resource {
  Resource({required this.title, required this.kind, required this.url});

  factory Resource.fromJson(Map<String, dynamic> j) => Resource(
        title: j['title']?.toString() ?? '',
        kind: j['kind']?.toString() ?? 'link',
        url: j['url']?.toString() ?? '',
      );

  final String title;
  final String kind;
  final String url;
}

class Enrollment {
  Enrollment({required this.id, required this.status, required this.receiptText, this.course, this.student, this.rejectReason = ''});

  factory Enrollment.fromJson(Map<String, dynamic> j) => Enrollment(
        id: j['id']?.toString() ?? j['_id']?.toString() ?? '',
        status: j['status']?.toString() ?? 'pending',
        receiptText: j['receiptText']?.toString() ?? '',
        rejectReason: j['rejectReason']?.toString() ?? '',
        course: j['course'] is Map ? Course.fromJson(Map<String, dynamic>.from(j['course'])) : null,
        student: j['student'] is Map ? UserData.fromJson(Map<String, dynamic>.from(j['student'])) : null,
      );

  final String id;
  final String status;
  final String receiptText;
  final String rejectReason;
  final Course? course;
  final UserData? student;
}

class RootPage extends StatefulWidget {
  const RootPage({super.key});

  @override
  State<RootPage> createState() => _RootPageState();
}

class _RootPageState extends State<RootPage> {
  final ApiClient api = ApiClient();
  AppSettings? settings;
  UserData? user;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    loadSettings();
  }

  Future<void> loadSettings() async {
    try {
      final res = await api.get('/api/settings');
      if (res is Map) settings = AppSettings.fromJson(Map<String, dynamic>.from(res));
    } catch (_) {
      settings = AppSettings(appTitle: 'کلاس خصوصی', teacherName: 'خانم معلم', cardNumber: '', cardOwner: '', supportPhone: '', paymentHelp: 'رسید پرداخت را ثبت کن.');
    }
    if (mounted) setState(() => loading = false);
  }

  void loginDone(String token, UserData newUser) {
    setState(() {
      api.token = token;
      user = newUser;
    });
  }

  void logout() {
    setState(() {
      api.token = null;
      user = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final s = settings!;
    if (user == null) return LoginPage(api: api, settings: s, onLogin: loginDone);
    if (user!.role == 'teacher') return TeacherHome(api: api, settings: s, user: user!, onLogout: logout, onSettingsChanged: loadSettings);
    return StudentHome(api: api, settings: s, user: user!, onLogout: logout);
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key, required this.api, required this.settings, required this.onLogin});

  final ApiClient api;
  final AppSettings settings;
  final void Function(String token, UserData user) onLogin;

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool teacherMode = false;
  bool busy = false;
  String gender = 'girl';
  final teacherPhone = TextEditingController();
  final teacherPassword = TextEditingController();
  final studentName = TextEditingController();
  final studentPhone = TextEditingController();
  final parentPhone = TextEditingController();

  static const Color loginColor = Color(0xFF7C3AED);

  @override
  void dispose() {
    teacherPhone.dispose();
    teacherPassword.dispose();
    studentName.dispose();
    studentPhone.dispose();
    parentPhone.dispose();
    super.dispose();
  }

  Future<void> doLogin() async {
    if (teacherMode) {
      if (teacherPhone.text.trim().isEmpty || teacherPassword.text.isEmpty) {
        showMsg(context, 'شماره و رمز معلم را وارد کن.');
        return;
      }
    } else {
      if (studentName.text.trim().isEmpty || studentPhone.text.trim().isEmpty) {
        showMsg(context, 'نام و شماره دانش‌آموز را وارد کن.');
        return;
      }
    }

    setState(() => busy = true);
    try {
      final path = teacherMode ? '/api/auth/teacher-login' : '/api/auth/student-login';
      final data = teacherMode
          ? <String, dynamic>{'phone': teacherPhone.text.trim(), 'password': teacherPassword.text}
          : <String, dynamic>{'name': studentName.text.trim(), 'phone': studentPhone.text.trim(), 'parentPhone': parentPhone.text.trim(), 'theme': gender};
      final res = await widget.api.post(path, data);
      final token = res['token'].toString();
      final user = UserData.fromJson(Map<String, dynamic>.from(res['user']));
      widget.onLogin(token, user);
    } catch (e) {
      showMsg(context, cleanError(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(22),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(30),
                    boxShadow: const [BoxShadow(color: Color(0x14000000), blurRadius: 24, offset: Offset(0, 12))],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const Icon(Icons.school_rounded, size: 52, color: loginColor),
                      const SizedBox(height: 12),
                      Text(
                        widget.settings.appTitle,
                        textAlign: TextAlign.center,
                        style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w900, color: const Color(0xFF1F2937)),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'ورود به کلاس‌های ${widget.settings.teacherName}',
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Color(0xFF6B7280), fontSize: 14),
                      ),
                      const SizedBox(height: 22),
                      Container(
                        padding: const EdgeInsets.all(5),
                        decoration: BoxDecoration(color: const Color(0xFFF3F4F6), borderRadius: BorderRadius.circular(18)),
                        child: Row(
                          children: [
                            Expanded(child: _RoleButton(text: 'دانش‌آموز', selected: !teacherMode, onTap: () => setState(() => teacherMode = false))),
                            Expanded(child: _RoleButton(text: 'معلم', selected: teacherMode, onTap: () => setState(() => teacherMode = true))),
                          ],
                        ),
                      ),
                      const SizedBox(height: 18),
                      AnimatedSwitcher(
                        duration: const Duration(milliseconds: 180),
                        child: teacherMode ? _teacherFields() : _studentFields(),
                      ),
                      const SizedBox(height: 18),
                      ElevatedButton(
                        onPressed: busy ? null : doLogin,
                        style: ElevatedButton.styleFrom(backgroundColor: loginColor, foregroundColor: Colors.white),
                        child: Text(busy ? 'در حال ورود...' : 'ورود'),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),
                const Text(
                  'بعد از ورود، ظاهر بخش دانش‌آموز بر اساس دختر/پسر تغییر می‌کند.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Color(0xFF6B7280), fontSize: 12),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _teacherFields() {
    return Column(
      key: const ValueKey('teacher'),
      children: [
        TextField(controller: teacherPhone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'شماره معلم')),
        const SizedBox(height: 12),
        TextField(controller: teacherPassword, obscureText: true, decoration: const InputDecoration(labelText: 'رمز ورود')),
      ],
    );
  }

  Widget _studentFields() {
    return Column(
      key: const ValueKey('student'),
      children: [
        TextField(controller: studentName, decoration: const InputDecoration(labelText: 'نام دانش‌آموز')),
        const SizedBox(height: 12),
        TextField(controller: studentPhone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'شماره دانش‌آموز')),
        const SizedBox(height: 12),
        TextField(controller: parentPhone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'شماره والدین')),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: gender,
          decoration: const InputDecoration(labelText: 'جنسیت دانش‌آموز'),
          items: const [
            DropdownMenuItem(value: 'girl', child: Text('دختر')),
            DropdownMenuItem(value: 'boy', child: Text('پسر')),
          ],
          onChanged: (v) => setState(() => gender = v ?? 'girl'),
        ),
      ],
    );
  }
}

class _RoleButton extends StatelessWidget {
  const _RoleButton({required this.text, required this.selected, required this.onTap});

  final String text;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: BoxDecoration(
          color: selected ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(14),
          boxShadow: selected ? const [BoxShadow(color: Color(0x10000000), blurRadius: 12, offset: Offset(0, 4))] : null,
        ),
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: TextStyle(fontWeight: FontWeight.bold, color: selected ? const Color(0xFF7C3AED) : const Color(0xFF6B7280)),
        ),
      ),
    );
  }
}

class TeacherHome extends StatefulWidget {
  const TeacherHome({super.key, required this.api, required this.settings, required this.user, required this.onLogout, required this.onSettingsChanged});

  final ApiClient api;
  final AppSettings settings;
  final UserData user;
  final VoidCallback onLogout;
  final Future<void> Function() onSettingsChanged;

  @override
  State<TeacherHome> createState() => _TeacherHomeState();
}

class _TeacherHomeState extends State<TeacherHome> {
  int tab = 0;
  bool loading = true;
  List<Course> courses = [];
  List<Enrollment> enrollments = [];

  @override
  void initState() {
    super.initState();
    refresh();
  }

  Future<void> refresh() async {
    setState(() => loading = true);
    try {
      final c = await widget.api.get('/api/courses');
      courses = (c as List).map((e) => Course.fromJson(Map<String, dynamic>.from(e))).toList();
      final en = await widget.api.get('/api/enrollments');
      enrollments = (en as List).map((e) => Enrollment.fromJson(Map<String, dynamic>.from(e))).toList();
    } catch (e) {
      showMsg(context, e.toString());
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> updateStatus(Enrollment e, String status) async {
    try {
      await widget.api.patch('/api/enrollments/${e.id}/status', {'status': status, 'rejectReason': status == 'rejected' ? 'رسید تایید نشد' : ''});
      await refresh();
    } catch (err) {
      showMsg(context, err.toString());
    }
  }

  Future<void> deleteCourse(Course c) async {
    try {
      await widget.api.delete('/api/courses/${c.id}');
      await refresh();
    } catch (err) {
      showMsg(context, err.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.settings.appTitle), actions: [IconButton(onPressed: widget.onLogout, icon: const Icon(Icons.logout_rounded))]),
      floatingActionButton: tab == 0 ? FloatingActionButton.extended(onPressed: () => openCourseSheet(context, widget.api, null, refresh), icon: const Icon(Icons.add), label: const Text('کلاس جدید')) : null,
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: refresh,
              child: ListView(
                padding: const EdgeInsets.all(14),
                children: [
                  HeaderCard(title: 'پنل معلم', subtitle: '${courses.length} کلاس، ${enrollments.length} ثبت‌نام', color: const Color(0xFF7C3AED)),
                  const SizedBox(height: 12),
                  SegmentedButton<int>(
                    segments: const [
                      ButtonSegment(value: 0, icon: Icon(Icons.school_rounded), label: Text('کلاس‌ها')),
                      ButtonSegment(value: 1, icon: Icon(Icons.receipt_long_rounded), label: Text('رسیدها')),
                      ButtonSegment(value: 2, icon: Icon(Icons.settings_rounded), label: Text('تنظیمات')),
                    ],
                    selected: {tab},
                    onSelectionChanged: (s) => setState(() => tab = s.first),
                  ),
                  const SizedBox(height: 12),
                  if (tab == 0) ...courses.map((c) => CourseCard(
                        course: c,
                        teacher: true,
                        onEdit: () => openCourseSheet(context, widget.api, c, refresh),
                        onDelete: () => deleteCourse(c),
                      )),
                  if (tab == 1) ...enrollments.map((e) => EnrollmentCard(enrollment: e, teacher: true, onApprove: () => updateStatus(e, 'approved'), onReject: () => updateStatus(e, 'rejected'))),
                  if (tab == 2) SettingsForm(api: widget.api, settings: widget.settings, onDone: () async { await widget.onSettingsChanged(); if (mounted) refresh(); }),
                ],
              ),
            ),
    );
  }
}

class StudentHome extends StatefulWidget {
  const StudentHome({super.key, required this.api, required this.settings, required this.user, required this.onLogout});

  final ApiClient api;
  final AppSettings settings;
  final UserData user;
  final VoidCallback onLogout;

  @override
  State<StudentHome> createState() => _StudentHomeState();
}

class _StudentHomeState extends State<StudentHome> {
  bool loading = true;
  int tab = 0;
  List<Course> courses = [];
  List<Enrollment> enrollments = [];

  @override
  void initState() {
    super.initState();
    refresh();
  }

  Future<void> refresh() async {
    setState(() => loading = true);
    try {
      final c = await widget.api.get('/api/courses');
      courses = (c as List).map((e) => Course.fromJson(Map<String, dynamic>.from(e))).where((c) => c.isActive).toList();
      final en = await widget.api.get('/api/enrollments');
      enrollments = (en as List).map((e) => Enrollment.fromJson(Map<String, dynamic>.from(e))).toList();
    } catch (e) {
      showMsg(context, e.toString());
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  Future<void> enroll(Course c) async {
    final controller = TextEditingController();
    final text = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('ثبت رسید پرداخت'),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text('شماره کارت: ${widget.settings.cardNumber}'),
          Text('به نام: ${widget.settings.cardOwner}'),
          const SizedBox(height: 12),
          TextField(controller: controller, maxLines: 3, decoration: const InputDecoration(labelText: 'توضیح رسید / کد پیگیری')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('انصراف')),
          ElevatedButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('ارسال')),
        ],
      ),
    );
    if (text == null) return;
    try {
      await widget.api.post('/api/enrollments', {'courseId': c.id, 'receiptText': text});
      await refresh();
      showMsg(context, 'رسید ارسال شد و منتظر تایید معلم است.');
    } catch (e) {
      showMsg(context, e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = themeColor(widget.user.theme);
    return Scaffold(
      appBar: AppBar(title: Text(widget.settings.appTitle), actions: [IconButton(onPressed: widget.onLogout, icon: const Icon(Icons.logout_rounded))]),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: refresh,
              child: ListView(
                padding: const EdgeInsets.all(14),
                children: [
                  HeaderCard(title: 'سلام ${widget.user.name} ${widget.user.theme == 'boy' ? '🚀' : '🌸'}', subtitle: 'کلاس‌های ${widget.settings.teacherName}', color: color),
                  const SizedBox(height: 12),
                  SegmentedButton<int>(
                    segments: const [
                      ButtonSegment(value: 0, icon: Icon(Icons.school_rounded), label: Text('کلاس‌ها')),
                      ButtonSegment(value: 1, icon: Icon(Icons.check_circle_rounded), label: Text('کلاس‌های من')),
                    ],
                    selected: {tab},
                    onSelectionChanged: (s) => setState(() => tab = s.first),
                  ),
                  const SizedBox(height: 12),
                  if (tab == 0) ...courses.map((c) => CourseCard(course: c, teacher: false, onEnroll: () => enroll(c))),
                  if (tab == 1) ...enrollments.map((e) => EnrollmentCard(enrollment: e, teacher: false)),
                  if (tab == 1 && enrollments.isEmpty) const InfoCard(text: 'هنوز در کلاسی ثبت‌نام نکرده‌ای.'),
                ],
              ),
            ),
    );
  }
}

class CourseCard extends StatelessWidget {
  const CourseCard({super.key, required this.course, required this.teacher, this.onEnroll, this.onEdit, this.onDelete});

  final Course course;
  final bool teacher;
  final VoidCallback? onEnroll;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [
            Icon(course.type == 'online' ? Icons.video_call_rounded : Icons.menu_book_rounded, color: course.type == 'online' ? Colors.pink : Colors.blue),
            const SizedBox(width: 8),
            Expanded(child: Text(course.title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold))),
            if (!course.isActive) const Chip(label: Text('غیرفعال')),
          ]),
          const SizedBox(height: 6),
          Text('${course.subject} - پایه ${course.grade}'),
          Text(course.type == 'online' ? 'آنلاین' : 'آفلاین'),
          if (course.schedule.isNotEmpty) Text('زمان: ${course.schedule}'),
          Text('قیمت: ${money(course.price)}'),
          if (course.description.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text(course.description)),
          if (teacher && course.accessLink.isNotEmpty) Text('لینک: ${course.accessLink}', maxLines: 1, overflow: TextOverflow.ellipsis),
          const SizedBox(height: 10),
          if (teacher)
            Row(children: [
              Expanded(child: OutlinedButton.icon(onPressed: onEdit, icon: const Icon(Icons.edit_rounded), label: const Text('ویرایش'))),
              const SizedBox(width: 8),
              Expanded(child: OutlinedButton.icon(onPressed: onDelete, icon: const Icon(Icons.delete_rounded), label: const Text('حذف'))),
            ])
          else
            ElevatedButton.icon(onPressed: onEnroll, icon: const Icon(Icons.app_registration_rounded), label: const Text('ثبت‌نام و ارسال رسید')),
        ]),
      ),
    );
  }
}

class EnrollmentCard extends StatelessWidget {
  const EnrollmentCard({super.key, required this.enrollment, required this.teacher, this.onApprove, this.onReject});

  final Enrollment enrollment;
  final bool teacher;
  final VoidCallback? onApprove;
  final VoidCallback? onReject;

  @override
  Widget build(BuildContext context) {
    final c = enrollment.course;
    final st = enrollment.student;
    final approved = enrollment.status == 'approved';
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [
            Expanded(child: Text(c?.title ?? 'کلاس حذف شده', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold))),
            Chip(label: Text(statusText(enrollment.status))),
          ]),
          if (teacher && st != null) Text('دانش‌آموز: ${st.name} - ${st.phone}'),
          if (enrollment.receiptText.isNotEmpty) Text('رسید: ${enrollment.receiptText}'),
          if (enrollment.rejectReason.isNotEmpty) Text('علت رد: ${enrollment.rejectReason}', style: const TextStyle(color: Colors.red)),
          if (teacher && enrollment.status == 'pending') ...[
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: ElevatedButton.icon(onPressed: onApprove, icon: const Icon(Icons.check_rounded), label: const Text('تایید'))),
              const SizedBox(width: 8),
              Expanded(child: OutlinedButton.icon(onPressed: onReject, icon: const Icon(Icons.close_rounded), label: const Text('رد'))),
            ]),
          ],
          if (!teacher && approved && c != null) ...[
            const Divider(height: 22),
            if (c.accessLink.isNotEmpty) ElevatedButton.icon(onPressed: () => copyToClipboard(context, c.accessLink), icon: const Icon(Icons.video_call_rounded), label: const Text('کپی لینک ورود به کلاس')),
            ...c.resources.map((r) => TextButton.icon(onPressed: () => copyToClipboard(context, r.url), icon: const Icon(Icons.link_rounded), label: Text('کپی لینک ${r.title}'))),
          ],
        ]),
      ),
    );
  }
}

Future<void> openCourseSheet(BuildContext context, ApiClient api, Course? course, Future<void> Function() onDone) async {
  final title = TextEditingController(text: course?.title ?? '');
  final subject = TextEditingController(text: course?.subject ?? '');
  final grade = TextEditingController(text: course?.grade ?? '');
  final price = TextEditingController(text: course?.price.toString() ?? '');
  final schedule = TextEditingController(text: course?.schedule ?? '');
  final accessLink = TextEditingController(text: course?.accessLink ?? '');
  final description = TextEditingController(text: course?.description ?? '');
  String type = course?.type ?? 'online';
  bool isActive = course?.isActive ?? true;
  bool busy = false;

  await showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    builder: (ctx) => Directionality(
      textDirection: TextDirection.rtl,
      child: StatefulBuilder(
        builder: (ctx, setLocal) => Padding(
          padding: EdgeInsets.only(left: 16, right: 16, top: 16, bottom: MediaQuery.of(ctx).viewInsets.bottom + 16),
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Text(course == null ? 'افزودن کلاس' : 'ویرایش کلاس', style: Theme.of(ctx).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              TextField(controller: title, decoration: const InputDecoration(labelText: 'عنوان کلاس')),
              const SizedBox(height: 10),
              TextField(controller: subject, decoration: const InputDecoration(labelText: 'درس')),
              const SizedBox(height: 10),
              TextField(controller: grade, decoration: const InputDecoration(labelText: 'پایه')),
              const SizedBox(height: 10),
              TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'قیمت')),
              const SizedBox(height: 10),
              TextField(controller: schedule, decoration: const InputDecoration(labelText: 'زمان کلاس')),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(child: ChoiceChip(label: const Text('آنلاین'), selected: type == 'online', onSelected: (_) => setLocal(() => type = 'online'))),
                const SizedBox(width: 10),
                Expanded(child: ChoiceChip(label: const Text('آفلاین'), selected: type == 'offline', onSelected: (_) => setLocal(() => type = 'offline'))),
              ]),
              const SizedBox(height: 10),
              TextField(controller: accessLink, decoration: const InputDecoration(labelText: 'لینک کلاس / لینک فایل')),
              const SizedBox(height: 10),
              TextField(controller: description, maxLines: 3, decoration: const InputDecoration(labelText: 'توضیحات')),
              SwitchListTile(value: isActive, onChanged: (v) => setLocal(() => isActive = v), title: const Text('کلاس فعال باشد')),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: busy
                    ? null
                    : () async {
                        setLocal(() => busy = true);
                        final data = <String, dynamic>{
                          'title': title.text.trim(),
                          'subject': subject.text.trim(),
                          'grade': grade.text.trim(),
                          'price': price.text.trim(),
                          'schedule': schedule.text.trim(),
                          'type': type,
                          'accessLink': accessLink.text.trim(),
                          'description': description.text.trim(),
                          'isActive': isActive,
                        };
                        var closed = false;
                        try {
                          if (course == null) {
                            await api.post('/api/courses', data);
                          } else {
                            await api.put('/api/courses/${course.id}', data);
                          }
                          if (ctx.mounted) {
                            closed = true;
                            Navigator.pop(ctx);
                          }
                          await onDone();
                        } catch (e) {
                          if (ctx.mounted) showMsg(ctx, e.toString());
                        } finally {
                          if (!closed && ctx.mounted) setLocal(() => busy = false);
                        }
                      },
                child: Text(busy ? 'در حال ذخیره...' : 'ذخیره کلاس'),
              ),
            ]),
          ),
        ),
      ),
    ),
  );

  title.dispose();
  subject.dispose();
  grade.dispose();
  price.dispose();
  schedule.dispose();
  accessLink.dispose();
  description.dispose();
}

class SettingsForm extends StatefulWidget {
  const SettingsForm({super.key, required this.api, required this.settings, required this.onDone});

  final ApiClient api;
  final AppSettings settings;
  final VoidCallback onDone;

  @override
  State<SettingsForm> createState() => _SettingsFormState();
}

class _SettingsFormState extends State<SettingsForm> {
  late final TextEditingController appTitle;
  late final TextEditingController teacherName;
  late final TextEditingController cardNumber;
  late final TextEditingController cardOwner;
  late final TextEditingController supportPhone;
  late final TextEditingController paymentHelp;
  bool busy = false;

  @override
  void initState() {
    super.initState();
    appTitle = TextEditingController(text: widget.settings.appTitle);
    teacherName = TextEditingController(text: widget.settings.teacherName);
    cardNumber = TextEditingController(text: widget.settings.cardNumber);
    cardOwner = TextEditingController(text: widget.settings.cardOwner);
    supportPhone = TextEditingController(text: widget.settings.supportPhone);
    paymentHelp = TextEditingController(text: widget.settings.paymentHelp);
  }

  @override
  void dispose() {
    appTitle.dispose();
    teacherName.dispose();
    cardNumber.dispose();
    cardOwner.dispose();
    supportPhone.dispose();
    paymentHelp.dispose();
    super.dispose();
  }

  Future<void> save() async {
    setState(() => busy = true);
    try {
      await widget.api.put('/api/settings', {
        'appTitle': appTitle.text.trim(),
        'teacherName': teacherName.text.trim(),
        'cardNumber': cardNumber.text.trim(),
        'cardOwner': cardOwner.text.trim(),
        'supportPhone': supportPhone.text.trim(),
        'paymentHelp': paymentHelp.text.trim(),
      });
      widget.onDone();
      showMsg(context, 'تنظیمات ذخیره شد.');
    } catch (e) {
      showMsg(context, e.toString());
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          TextField(controller: appTitle, decoration: const InputDecoration(labelText: 'عنوان اپ')),
          const SizedBox(height: 10),
          TextField(controller: teacherName, decoration: const InputDecoration(labelText: 'نام معلم')),
          const SizedBox(height: 10),
          TextField(controller: cardNumber, decoration: const InputDecoration(labelText: 'شماره کارت')),
          const SizedBox(height: 10),
          TextField(controller: cardOwner, decoration: const InputDecoration(labelText: 'نام صاحب کارت')),
          const SizedBox(height: 10),
          TextField(controller: supportPhone, decoration: const InputDecoration(labelText: 'شماره پشتیبانی')),
          const SizedBox(height: 10),
          TextField(controller: paymentHelp, maxLines: 3, decoration: const InputDecoration(labelText: 'راهنمای پرداخت')),
          const SizedBox(height: 12),
          ElevatedButton(onPressed: busy ? null : save, child: Text(busy ? 'صبر کنید...' : 'ذخیره تنظیمات')),
        ]),
      ),
    );
  }
}

class HeaderCard extends StatelessWidget {
  const HeaderCard({super.key, required this.title, required this.subtitle, required this.color});

  final String title;
  final String subtitle;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        gradient: LinearGradient(colors: [color, color.withOpacity(0.68)]),
        boxShadow: [BoxShadow(color: color.withOpacity(0.24), blurRadius: 20, offset: const Offset(0, 10))],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: Theme.of(context).textTheme.headlineSmall?.copyWith(color: Colors.white, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text(subtitle, style: const TextStyle(color: Colors.white, fontSize: 16)),
      ]),
    );
  }
}

class InfoCard extends StatelessWidget {
  const InfoCard({super.key, required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Text(text, textAlign: TextAlign.center),
      ),
    );
  }
}

String cleanError(Object e) {
  var text = e.toString();
  text = text.replaceFirst('Exception: ', '').replaceFirst('ApiError: ', '');
  return text;
}

void showMsg(BuildContext context, String text) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(cleanError(text))));
}

Future<void> copyToClipboard(BuildContext context, String text) async {
  await Clipboard.setData(ClipboardData(text: text));
  if (context.mounted) showMsg(context, 'لینک کپی شد. داخل مرورگر یا گوگل میت بازش کن.');
}
