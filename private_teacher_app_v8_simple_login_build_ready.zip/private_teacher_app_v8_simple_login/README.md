# Private Teacher App V8

تغییرات نسخه 8:

- صفحه ورود ساده‌تر و ثابت شد.
- انتخاب دختر/پسر دیگر رنگ صفحه ورود را عوض نمی‌کند.
- ظاهر داخل پنل دانش‌آموز بعد از ورود بر اساس جنسیت تغییر می‌کند.
- پیام خطای اتصال به سرور فارسی و واضح‌تر شد.
- Workflow داخل پروژه مجوز INTERNET را به AndroidManifest اضافه می‌کند.

API ثابت داخل اپ:
https://likezilla.ir/ahmadvand/backend_php

ورود معلم تست:
Phone: 09035906224
Password: 1234Za

نکته مهم برای GitHub Actions:
اگر ZIP را فقط به عنوان فایل در ریشه ریپو آپلود می‌کنی، GitHub فایل workflow داخل ZIP را نمی‌خواند. باید فایل `.github/workflows/build-apk.yml` خود ریپو هم نسخه جدید باشد.
