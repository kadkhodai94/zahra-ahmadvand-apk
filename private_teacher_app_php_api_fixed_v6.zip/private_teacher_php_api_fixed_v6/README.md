# Private Teacher App - PHP Host Auto Installer V5

این نسخه برای هاست‌های معمولی بدون Node.js ساخته شده است.

## محتویات

```text
backend_php/   بک‌اند PHP/MySQL با نصب خودکار
flutter_app/   سورس اپ Flutter
demo_html/     دمو HTML
```

## نصب سریع

1. پوشه `backend_php` را در `public_html` آپلود کن.
2. در cPanel یک MySQL Database و User بساز و User را با ALL PRIVILEGES به Database وصل کن.
3. لینک زیر را باز کن:

```text
https://YourDomain.com/backend_php/install.php
```

4. در صفحه نصب، معمولاً فقط رمز دیتابیس را وارد کن و نصب خودکار را بزن.
5. بعد از نصب، این لینک باید JSON بدهد:

```text
https://YourDomain.com/backend_php/api/settings
```

6. برای امنیت، فایل `install.php` را حذف کن.

## ورود پیش‌فرض معلم

```text
شماره: 09120000000
رمز: 1234
```


نسخه V6: آدرس API داخل اپ ثابت شد و کاربر دیگر نیاز به وارد کردن دستی آدرس سرور ندارد.
API: https://likezilla.ir/ahmadvand/backend_php
