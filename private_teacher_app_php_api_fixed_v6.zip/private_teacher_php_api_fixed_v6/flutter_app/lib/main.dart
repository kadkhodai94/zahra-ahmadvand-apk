import 'dart:convert';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher_string.dart';

const defaultApiBaseUrl = 'https://likezilla.ir/ahmadvand/backend_php';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const PrivateTeacherCloudApp());
}

String money(dynamic value) {
  final n = int.tryParse(value.toString()) ?? 0;
  final chars = n.toString().split('').reversed.toList();
  final out = <String>[];
  for (var i = 0; i < chars.length; i++) {
    if (i > 0 && i % 3 == 0) out.add(',');
    out.add(chars[i]);
  }
  return '${out.reversed.join()} تومان';
}

Color themeColor(String theme) => theme == 'boy' ? const Color(0xFF4DA3FF) : const Color(0xFFFF6FAE);
String themeEmoji(String theme) => theme == 'boy' ? '🚀' : '🌸';
String statusText(String status) {
  switch (status) {
    case 'approved':
      return 'تایید شده';
    case 'rejected':
      return 'رد شده';
    default:
      return 'در انتظار بررسی';
  }
}

class ApiException implements Exception {
  ApiException(this.message);
  final String message;
  @override
  String toString() => message;
}

class ApiClient {
  ApiClient({required this.baseUrl, this.token});
  String baseUrl;
  String? token;

  Map<String, String> get headers => {
        'Content-Type': 'application/json',
        if (token != null && token!.isNotEmpty) 'Authorization': 'Bearer $token',
      };

  Uri uri(String path) => Uri.parse('$baseUrl$path');

  Future<dynamic> _handle(http.Response res) async {
    dynamic body;
    try {
      body = res.body.isEmpty ? null : jsonDecode(res.body);
    } catch (_) {
      body = null;
    }
    if (res.statusCode >= 200 && res.statusCode < 300) return body;
    throw ApiException((body is Map && body['message'] != null) ? body['message'].toString() : 'خطا در ارتباط با سرور');
  }

  Future<dynamic> get(String path) async => _handle(await http.get(uri(path), headers: headers));
  Future<dynamic> post(String path, Map<String, dynamic> data) async => _handle(await http.post(uri(path), headers: headers, body: jsonEncode(data)));
  Future<dynamic> put(String path, Map<String, dynamic> data) async => _handle(await http.put(uri(path), headers: headers, body: jsonEncode(data)));
  Future<dynamic> patch(String path, Map<String, dynamic> data) async => _handle(await http.patch(uri(path), headers: headers, body: jsonEncode(data)));
  Future<dynamic> delete(String path) async => _handle(await http.delete(uri(path), headers: headers));

  Future<Map<String, dynamic>> uploadFile(PlatformFile file) async {
    if (file.path == null) throw ApiException('این فایل قابل ارسال نیست');
    final request = http.MultipartRequest('POST', uri('/api/uploads'));
    if (token != null && token!.isNotEmpty) request.headers['Authorization'] = 'Bearer $token';
    request.files.add(await http.MultipartFile.fromPath('file', file.path!, filename: file.name));
    final streamed = await request.send();
    final res = await http.Response.fromStream(streamed);
    final body = await _handle(res);
    return Map<String, dynamic>.from(body as Map);
  }
}

class AppSettingsModel {
  AppSettingsModel({
    required this.appTitle,
    required this.teacherName,
    required this.cardNumber,
    required this.cardOwner,
    required this.supportPhone,
    required this.paymentHelp,
  });
  final String appTitle;
  final String teacherName;
  final String cardNumber;
  final String cardOwner;
  final String supportPhone;
  final String paymentHelp;

  factory AppSettingsModel.fromJson(Map<String, dynamic> json) => AppSettingsModel(
        appTitle: json['appTitle'] ?? 'کلاس خصوصی مهربون',
        teacherName: json['teacherName'] ?? 'خانم معلم',
        cardNumber: json['cardNumber'] ?? '6037 0000 0000 0000',
        cardOwner: json['cardOwner'] ?? 'نام صاحب کارت',
        supportPhone: json['supportPhone'] ?? '09xxxxxxxxx',
        paymentHelp: json['paymentHelp'] ?? 'بعد از کارت‌به‌کارت، رسید را ثبت کن.',
      );
}

class ResourceModel {
  ResourceModel({required this.id, required this.title, required this.kind, required this.url});
  final String id;
  final String title;
  final String kind;
  final String url;
  factory ResourceModel.fromJson(Map<String, dynamic> json) => ResourceModel(
        id: (json['_id'] ?? json['id'] ?? '').toString(),
        title: json['title'] ?? '',
        kind: json['kind'] ?? 'link',
        url: json['url'] ?? '',
      );
  Map<String, dynamic> toJson() => {'title': title, 'kind': kind, 'url': url};
}

class CourseModel {
  CourseModel({
    required this.id,
    required this.title,
    required this.subject,
    required this.grade,
    required this.price,
    required this.schedule,
    required this.type,
    required this.accessLink,
    required this.description,
    required this.isActive,
    required this.resources,
  });
  final String id;
  final String title;
  final String subject;
  final String grade;
  final int price;
  final String schedule;
  final String type;
  final String accessLink;
  final String description;
  final bool isActive;
  final List<ResourceModel> resources;

  factory CourseModel.fromJson(Map<String, dynamic> json) => CourseModel(
        id: (json['_id'] ?? json['id'] ?? '').toString(),
        title: json['title'] ?? '',
        subject: json['subject'] ?? '',
        grade: json['grade'] ?? '',
        price: int.tryParse((json['price'] ?? 0).toString()) ?? 0,
        schedule: json['schedule'] ?? '',
        type: json['type'] ?? 'online',
        accessLink: json['accessLink'] ?? '',
        description: json['description'] ?? '',
        isActive: json['isActive'] != false,
        resources: ((json['resources'] ?? []) as List).map((e) => ResourceModel.fromJson(Map<String, dynamic>.from(e))).toList(),
      );
}

class UserModel {
  UserModel({required this.id, required this.role, required this.name, required this.phone, required this.theme, required this.parentPhone});
  final String id;
  final String role;
  final String name;
  final String phone;
  final String theme;
  final String parentPhone;
  factory UserModel.fromJson(Map<String, dynamic> json) => UserModel(
        id: (json['id'] ?? json['_id'] ?? '').toString(),
        role: json['role'] ?? 'student',
        name: json['name'] ?? '',
        phone: json['phone'] ?? '',
        theme: json['theme'] ?? 'girl',
        parentPhone: json['parentPhone'] ?? '',
      );
}

class EnrollmentModel {
  EnrollmentModel({
    required this.id,
    required this.status,
    required this.receiptText,
    required this.receiptFileUrl,
    required this.rejectReason,
    required this.course,
    required this.student,
  });
  final String id;
  final String status;
  final String receiptText;
  final String receiptFileUrl;
  final String rejectReason;
  final CourseModel? course;
  final UserModel? student;

  factory EnrollmentModel.fromJson(Map<String, dynamic> json) => EnrollmentModel(
        id: (json['_id'] ?? json['id'] ?? '').toString(),
        status: json['status'] ?? 'pending',
        receiptText: json['receiptText'] ?? '',
        receiptFileUrl: json['receiptFileUrl'] ?? '',
        rejectReason: json['rejectReason'] ?? '',
        course: json['course'] is Map ? CourseModel.fromJson(Map<String, dynamic>.from(json['course'])) : null,
        student: json['student'] is Map ? UserModel.fromJson(Map<String, dynamic>.from(json['student'])) : null,
      );
}

class PrivateTeacherCloudApp extends StatefulWidget {
  const PrivateTeacherCloudApp({super.key});
  @override
  State<PrivateTeacherCloudApp> createState() => _PrivateTeacherCloudAppState();
}

class _PrivateTeacherCloudAppState extends State<PrivateTeacherCloudApp> {
  ApiClient api = ApiClient(baseUrl: defaultApiBaseUrl);
  UserModel? user;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    restoreSession();
  }

  Future<void> restoreSession() async {
    final prefs = await SharedPreferences.getInstance();
    final baseUrl = defaultApiBaseUrl;
    final token = prefs.getString('token');
    api = ApiClient(baseUrl: baseUrl, token: token);
    if (token != null && token.isNotEmpty) {
      try {
        final res = await api.get('/api/auth/me');
        user = UserModel.fromJson(Map<String, dynamic>.from(res['user']));
      } catch (_) {
        await prefs.remove('token');
      }
    }
    setState(() => loading = false);
  }

  Future<void> setSession({required String token, required UserModel nextUser, required String baseUrl}) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('token', token);
    await prefs.setString('apiBaseUrl', baseUrl);
    setState(() {
      api = ApiClient(baseUrl: baseUrl, token: token);
      user = nextUser;
    });
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('token');
    setState(() => user = null);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      locale: const Locale('fa'),
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Roboto',
        colorScheme: ColorScheme.fromSeed(seedColor: user == null ? const Color(0xFFFF6FAE) : themeColor(user!.theme)),
        scaffoldBackgroundColor: const Color(0xFFFFFAFD),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
        ),
      ),
      home: Directionality(
        textDirection: TextDirection.rtl,
        child: loading
            ? const Scaffold(body: Center(child: CircularProgressIndicator()))
            : user == null
                ? LoginScreen(onLogin: setSession)
                : user!.role == 'teacher'
                    ? TeacherHome(api: api, user: user!, onLogout: logout)
                    : StudentHome(api: api, user: user!, onLogout: logout),
      ),
    );
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key, required this.onLogin});
  final Future<void> Function({required String token, required UserModel nextUser, required String baseUrl}) onLogin;
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
    final teacherPhone = TextEditingController(text: '09120000000');
  final teacherPass = TextEditingController(text: '1234');
  final studentName = TextEditingController();
  final studentPhone = TextEditingController();
  final parentPhone = TextEditingController();
  bool isTeacher = false;
  String theme = 'girl';
  bool loading = false;

  Future<void> login() async {
    setState(() => loading = true);
    try {
      final api = ApiClient(baseUrl: defaultApiBaseUrl);
      final res = isTeacher
          ? await api.post('/api/auth/teacher-login', {'phone': teacherPhone.text.trim(), 'password': teacherPass.text.trim()})
          : await api.post('/api/auth/student-login', {
              'name': studentName.text.trim(),
              'phone': studentPhone.text.trim(),
              'parentPhone': parentPhone.text.trim(),
              'theme': theme,
            });
      final token = res['token'].toString();
      final nextUser = UserModel.fromJson(Map<String, dynamic>.from(res['user']));
      await widget.onLogin(token: token, nextUser: nextUser, baseUrl: defaultApiBaseUrl);
    } catch (e) {
      if (mounted) showSnack(context, e.toString());
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = isTeacher ? const Color(0xFF7C4DFF) : themeColor(theme);
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [color.withOpacity(.85), color.withOpacity(.45)]),
                borderRadius: BorderRadius.circular(28),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('کلاس خصوصی مهربون 📚', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: Colors.white)),
                  SizedBox(height: 8),
                  Text('ورود معلم و دانش‌آموز با سرور مشترک', style: TextStyle(color: Colors.white, fontSize: 15)),
                ],
              ),
            ),
            const SizedBox(height: 16),
            SegmentedButton<bool>(
              segments: const [
                ButtonSegment(value: false, label: Text('دانش‌آموز'), icon: Icon(Icons.face_rounded)),
                ButtonSegment(value: true, label: Text('معلم'), icon: Icon(Icons.admin_panel_settings_rounded)),
              ],
              selected: {isTeacher},
              onSelectionChanged: (v) => setState(() => isTeacher = v.first),
            ),
            const SizedBox(height: 14),
            if (isTeacher) ...[
              TextField(controller: teacherPhone, keyboardType: TextInputType.phone, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'شماره موبایل معلم')),
              const SizedBox(height: 12),
              TextField(controller: teacherPass, obscureText: true, decoration: const InputDecoration(labelText: 'رمز معلم')),
            ] else ...[
              TextField(controller: studentName, decoration: const InputDecoration(labelText: 'نام دانش‌آموز')),
              const SizedBox(height: 12),
              TextField(controller: studentPhone, keyboardType: TextInputType.phone, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'شماره موبایل')),
              const SizedBox(height: 12),
              TextField(controller: parentPhone, keyboardType: TextInputType.phone, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'شماره والدین')),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: ThemeChoice(title: 'دخترونه 🌸', selected: theme == 'girl', color: themeColor('girl'), onTap: () => setState(() => theme = 'girl'))),
                  const SizedBox(width: 10),
                  Expanded(child: ThemeChoice(title: 'پسرونه 🚀', selected: theme == 'boy', color: themeColor('boy'), onTap: () => setState(() => theme = 'boy'))),
                ],
              ),
            ],
            const SizedBox(height: 18),
            FilledButton.icon(
              style: FilledButton.styleFrom(backgroundColor: color, padding: const EdgeInsets.symmetric(vertical: 15)),
              onPressed: loading ? null : login,
              icon: loading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.login_rounded),
              label: const Text('ورود به اپ'),
            ),
          ],
        ),
      ),
    );
  }
}

class ThemeChoice extends StatelessWidget {
  const ThemeChoice({super.key, required this.title, required this.selected, required this.color, required this.onTap});
  final String title;
  final bool selected;
  final Color color;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: selected ? color.withOpacity(.15) : Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: selected ? color : Colors.black12, width: selected ? 2 : 1)),
        child: Center(child: Text(title, style: TextStyle(fontWeight: FontWeight.w800, color: selected ? color : Colors.black87))),
      ),
    );
  }
}

class TeacherHome extends StatefulWidget {
  const TeacherHome({super.key, required this.api, required this.user, required this.onLogout});
  final ApiClient api;
  final UserModel user;
  final VoidCallback onLogout;
  @override
  State<TeacherHome> createState() => _TeacherHomeState();
}

class _TeacherHomeState extends State<TeacherHome> {
  int tab = 0;
  List<CourseModel> courses = [];
  List<EnrollmentModel> enrollments = [];
  AppSettingsModel? settings;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() => loading = true);
    try {
      final c = await widget.api.get('/api/courses') as List;
      final e = await widget.api.get('/api/enrollments') as List;
      final s = await widget.api.get('/api/settings');
      courses = c.map((x) => CourseModel.fromJson(Map<String, dynamic>.from(x))).toList();
      enrollments = e.map((x) => EnrollmentModel.fromJson(Map<String, dynamic>.from(x))).toList();
      settings = AppSettingsModel.fromJson(Map<String, dynamic>.from(s));
    } catch (e) {
      if (mounted) showSnack(context, e.toString());
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      TeacherCoursesPage(api: widget.api, courses: courses, onChanged: load),
      TeacherEnrollmentsPage(api: widget.api, enrollments: enrollments, onChanged: load),
      TeacherSettingsPage(api: widget.api, settings: settings, onChanged: load),
    ];
    return Scaffold(
      appBar: AppBar(
        title: Text(settings?.appTitle ?? 'پنل معلم'),
        actions: [IconButton(onPressed: widget.onLogout, icon: const Icon(Icons.logout_rounded))],
      ),
      body: loading ? const Center(child: CircularProgressIndicator()) : pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.menu_book_rounded), label: 'کلاس‌ها'),
          NavigationDestination(icon: Icon(Icons.receipt_long_rounded), label: 'ثبت‌نام‌ها'),
          NavigationDestination(icon: Icon(Icons.settings_rounded), label: 'تنظیمات'),
        ],
      ),
      floatingActionButton: tab == 0
          ? FloatingActionButton.extended(
              onPressed: () async {
                await Navigator.push(context, MaterialPageRoute(builder: (_) => Directionality(textDirection: TextDirection.rtl, child: CourseFormScreen(api: widget.api))));
                load();
              },
              icon: const Icon(Icons.add),
              label: const Text('کلاس جدید'),
            )
          : null,
    );
  }
}

class TeacherCoursesPage extends StatelessWidget {
  const TeacherCoursesPage({super.key, required this.api, required this.courses, required this.onChanged});
  final ApiClient api;
  final List<CourseModel> courses;
  final Future<void> Function() onChanged;
  @override
  Widget build(BuildContext context) {
    if (courses.isEmpty) return const EmptyState(text: 'هنوز کلاسی ثبت نشده است');
    return RefreshIndicator(
      onRefresh: onChanged,
      child: ListView.separated(
        padding: const EdgeInsets.all(14),
        itemCount: courses.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (context, index) {
          final course = courses[index];
          return CourseCard(
            course: course,
            teacherMode: true,
            trailing: Wrap(
              children: [
                IconButton(
                  tooltip: 'ویرایش',
                  onPressed: () async {
                    await Navigator.push(context, MaterialPageRoute(builder: (_) => Directionality(textDirection: TextDirection.rtl, child: CourseFormScreen(api: api, course: course))));
                    onChanged();
                  },
                  icon: const Icon(Icons.edit_rounded),
                ),
                IconButton(
                  tooltip: 'حذف',
                  onPressed: () async {
                    final ok = await confirm(context, 'این کلاس حذف شود؟');
                    if (ok) {
                      try {
                        await api.delete('/api/courses/${course.id}');
                        onChanged();
                      } catch (e) {
                        if (context.mounted) showSnack(context, e.toString());
                      }
                    }
                  },
                  icon: const Icon(Icons.delete_rounded, color: Colors.red),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class TeacherEnrollmentsPage extends StatelessWidget {
  const TeacherEnrollmentsPage({super.key, required this.api, required this.enrollments, required this.onChanged});
  final ApiClient api;
  final List<EnrollmentModel> enrollments;
  final Future<void> Function() onChanged;

  Future<void> setStatus(BuildContext context, EnrollmentModel e, String status) async {
    try {
      await api.patch('/api/enrollments/${e.id}/status', {'status': status});
      onChanged();
    } catch (err) {
      if (context.mounted) showSnack(context, err.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    if (enrollments.isEmpty) return const EmptyState(text: 'هنوز ثبت‌نامی ارسال نشده است');
    return RefreshIndicator(
      onRefresh: onChanged,
      child: ListView.separated(
        padding: const EdgeInsets.all(14),
        itemCount: enrollments.length,
        separatorBuilder: (_, __) => const SizedBox(height: 10),
        itemBuilder: (context, index) {
          final e = enrollments[index];
          return Container(
            padding: const EdgeInsets.all(14),
            decoration: cardDecoration(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(e.course?.title ?? 'کلاس حذف شده', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                Text('دانش‌آموز: ${e.student?.name ?? '-'} | ${e.student?.phone ?? '-'}'),
                if ((e.student?.parentPhone ?? '').isNotEmpty) Text('شماره والدین: ${e.student!.parentPhone}'),
                const SizedBox(height: 8),
                Chip(label: Text(statusText(e.status))),
                if (e.receiptText.isNotEmpty) Text('توضیح رسید: ${e.receiptText}'),
                if (e.receiptFileUrl.isNotEmpty)
                  TextButton.icon(onPressed: () => launchUrlString(e.receiptFileUrl), icon: const Icon(Icons.image_rounded), label: const Text('دیدن فایل رسید')),
                Row(
                  children: [
                    Expanded(child: FilledButton.icon(onPressed: () => setStatus(context, e, 'approved'), icon: const Icon(Icons.check), label: const Text('تایید'))),
                    const SizedBox(width: 8),
                    Expanded(child: OutlinedButton.icon(onPressed: () => setStatus(context, e, 'rejected'), icon: const Icon(Icons.close), label: const Text('رد'))),
                  ],
                )
              ],
            ),
          );
        },
      ),
    );
  }
}

class TeacherSettingsPage extends StatefulWidget {
  const TeacherSettingsPage({super.key, required this.api, required this.settings, required this.onChanged});
  final ApiClient api;
  final AppSettingsModel? settings;
  final Future<void> Function() onChanged;
  @override
  State<TeacherSettingsPage> createState() => _TeacherSettingsPageState();
}

class _TeacherSettingsPageState extends State<TeacherSettingsPage> {
  final appTitle = TextEditingController();
  final teacherName = TextEditingController();
  final cardNumber = TextEditingController();
  final cardOwner = TextEditingController();
  final supportPhone = TextEditingController();
  final paymentHelp = TextEditingController();

  @override
  void initState() {
    super.initState();
    fill();
  }

  @override
  void didUpdateWidget(covariant TeacherSettingsPage oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.settings != widget.settings) fill();
  }

  void fill() {
    final s = widget.settings;
    if (s == null) return;
    appTitle.text = s.appTitle;
    teacherName.text = s.teacherName;
    cardNumber.text = s.cardNumber;
    cardOwner.text = s.cardOwner;
    supportPhone.text = s.supportPhone;
    paymentHelp.text = s.paymentHelp;
  }

  Future<void> save() async {
    try {
      await widget.api.put('/api/settings', {
        'appTitle': appTitle.text.trim(),
        'teacherName': teacherName.text.trim(),
        'cardNumber': cardNumber.text.trim(),
        'cardOwner': cardOwner.text.trim(),
        'supportPhone': supportPhone.text.trim(),
        'paymentHelp': paymentHelp.text.trim(),
      });
      if (mounted) showSnack(context, 'تنظیمات ذخیره شد');
      widget.onChanged();
    } catch (e) {
      if (mounted) showSnack(context, e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(14),
      children: [
        TextField(controller: appTitle, decoration: const InputDecoration(labelText: 'عنوان اپ')),
        const SizedBox(height: 10),
        TextField(controller: teacherName, decoration: const InputDecoration(labelText: 'نام معلم')),
        const SizedBox(height: 10),
        TextField(controller: cardNumber, keyboardType: TextInputType.number, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'شماره کارت')),
        const SizedBox(height: 10),
        TextField(controller: cardOwner, decoration: const InputDecoration(labelText: 'نام صاحب کارت')),
        const SizedBox(height: 10),
        TextField(controller: supportPhone, keyboardType: TextInputType.phone, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'شماره پشتیبانی')),
        const SizedBox(height: 10),
        TextField(controller: paymentHelp, maxLines: 3, decoration: const InputDecoration(labelText: 'راهنمای پرداخت')),
        const SizedBox(height: 14),
        FilledButton.icon(onPressed: save, icon: const Icon(Icons.save_rounded), label: const Text('ذخیره تنظیمات')),
      ],
    );
  }
}

class CourseFormScreen extends StatefulWidget {
  const CourseFormScreen({super.key, required this.api, this.course});
  final ApiClient api;
  final CourseModel? course;
  @override
  State<CourseFormScreen> createState() => _CourseFormScreenState();
}

class _CourseFormScreenState extends State<CourseFormScreen> {
  final title = TextEditingController();
  final subject = TextEditingController();
  final grade = TextEditingController();
  final price = TextEditingController();
  final schedule = TextEditingController();
  final accessLink = TextEditingController();
  final description = TextEditingController();
  String type = 'online';
  bool isActive = true;
  List<ResourceModel> resources = [];
  bool saving = false;

  @override
  void initState() {
    super.initState();
    final c = widget.course;
    if (c != null) {
      title.text = c.title;
      subject.text = c.subject;
      grade.text = c.grade;
      price.text = c.price.toString();
      schedule.text = c.schedule;
      accessLink.text = c.accessLink;
      description.text = c.description;
      type = c.type;
      isActive = c.isActive;
      resources = List.of(c.resources);
    }
  }

  Future<void> pickResource() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.any);
    if (result == null || result.files.isEmpty) return;
    try {
      final uploaded = await widget.api.uploadFile(result.files.first);
      final filename = uploaded['fileName']?.toString() ?? result.files.first.name;
      final url = uploaded['url'].toString();
      setState(() => resources.add(ResourceModel(id: '', title: filename, kind: guessKind(filename), url: url)));
    } catch (e) {
      if (mounted) showSnack(context, e.toString());
    }
  }

  Future<void> addLinkResource() async {
    final titleCtrl = TextEditingController();
    final urlCtrl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          title: const Text('افزودن لینک آموزشی'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: titleCtrl, decoration: const InputDecoration(labelText: 'عنوان')),
            const SizedBox(height: 8),
            TextField(controller: urlCtrl, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'لینک')),
          ]),
          actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('لغو')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('ثبت'))],
        ),
      ),
    );
    if (ok == true && titleCtrl.text.trim().isNotEmpty && urlCtrl.text.trim().isNotEmpty) {
      setState(() => resources.add(ResourceModel(id: '', title: titleCtrl.text.trim(), kind: 'link', url: urlCtrl.text.trim())));
    }
  }

  Future<void> save() async {
    setState(() => saving = true);
    try {
      final data = {
        'title': title.text.trim(),
        'subject': subject.text.trim(),
        'grade': grade.text.trim(),
        'price': price.text.trim(),
        'schedule': schedule.text.trim(),
        'type': type,
        'accessLink': accessLink.text.trim(),
        'description': description.text.trim(),
        'isActive': isActive,
        'resources': resources.map((e) => e.toJson()).toList(),
      };
      if (widget.course == null) {
        await widget.api.post('/api/courses', data);
      } else {
        await widget.api.put('/api/courses/${widget.course!.id}', data);
      }
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) showSnack(context, e.toString());
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.course == null ? 'کلاس جدید' : 'ویرایش کلاس')),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          TextField(controller: title, decoration: const InputDecoration(labelText: 'عنوان کلاس')),
          const SizedBox(height: 10),
          TextField(controller: subject, decoration: const InputDecoration(labelText: 'درس')),
          const SizedBox(height: 10),
          TextField(controller: grade, decoration: const InputDecoration(labelText: 'پایه / مقطع')),
          const SizedBox(height: 10),
          TextField(controller: price, keyboardType: TextInputType.number, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'قیمت')),
          const SizedBox(height: 10),
          TextField(controller: schedule, decoration: const InputDecoration(labelText: 'زمان کلاس')),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: type,
            decoration: const InputDecoration(labelText: 'نوع کلاس'),
            items: const [DropdownMenuItem(value: 'online', child: Text('آنلاین')), DropdownMenuItem(value: 'offline', child: Text('آفلاین'))],
            onChanged: (v) => setState(() => type = v ?? 'online'),
          ),
          const SizedBox(height: 10),
          TextField(controller: accessLink, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'لینک کلاس / دسترسی')),
          const SizedBox(height: 10),
          TextField(controller: description, maxLines: 3, decoration: const InputDecoration(labelText: 'توضیحات')),
          const SizedBox(height: 10),
          SwitchListTile(value: isActive, onChanged: (v) => setState(() => isActive = v), title: const Text('کلاس فعال باشد')),
          const SizedBox(height: 14),
          Row(children: [
            Expanded(child: OutlinedButton.icon(onPressed: pickResource, icon: const Icon(Icons.upload_file), label: const Text('آپلود فایل'))),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton.icon(onPressed: addLinkResource, icon: const Icon(Icons.link), label: const Text('افزودن لینک'))),
          ]),
          const SizedBox(height: 8),
          ...resources.asMap().entries.map((entry) => ListTile(
                tileColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                title: Text(entry.value.title),
                subtitle: Text(entry.value.kind),
                trailing: IconButton(onPressed: () => setState(() => resources.removeAt(entry.key)), icon: const Icon(Icons.delete_outline)),
              )),
          const SizedBox(height: 18),
          FilledButton.icon(onPressed: saving ? null : save, icon: const Icon(Icons.save_rounded), label: Text(saving ? 'در حال ذخیره...' : 'ذخیره کلاس')),
        ],
      ),
    );
  }
}

class StudentHome extends StatefulWidget {
  const StudentHome({super.key, required this.api, required this.user, required this.onLogout});
  final ApiClient api;
  final UserModel user;
  final VoidCallback onLogout;
  @override
  State<StudentHome> createState() => _StudentHomeState();
}

class _StudentHomeState extends State<StudentHome> {
  List<CourseModel> courses = [];
  List<EnrollmentModel> enrollments = [];
  AppSettingsModel? settings;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() => loading = true);
    try {
      final c = await widget.api.get('/api/courses') as List;
      final e = await widget.api.get('/api/enrollments') as List;
      final s = await widget.api.get('/api/settings');
      courses = c.map((x) => CourseModel.fromJson(Map<String, dynamic>.from(x))).where((x) => x.isActive).toList();
      enrollments = e.map((x) => EnrollmentModel.fromJson(Map<String, dynamic>.from(x))).toList();
      settings = AppSettingsModel.fromJson(Map<String, dynamic>.from(s));
    } catch (e) {
      if (mounted) showSnack(context, e.toString());
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  EnrollmentModel? enrollmentFor(String courseId) {
    for (final e in enrollments) {
      if (e.course?.id == courseId) return e;
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final color = themeColor(widget.user.theme);
    return Scaffold(
      appBar: AppBar(
        title: Text('${themeEmoji(widget.user.theme)} ${settings?.appTitle ?? 'کلاس خصوصی'}'),
        actions: [IconButton(onPressed: widget.onLogout, icon: const Icon(Icons.logout_rounded))],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: load,
              child: ListView(
                padding: const EdgeInsets.all(14),
                children: [
                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(color: color.withOpacity(.14), borderRadius: BorderRadius.circular(24)),
                    child: Text('سلام ${widget.user.name} عزیز 👋\nکلاس موردنظرت رو انتخاب کن و بعد از پرداخت، رسیدت رو بفرست.', style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                  ),
                  const SizedBox(height: 14),
                  if (courses.isEmpty) const EmptyState(text: 'فعلاً کلاسی فعال نیست') else ...courses.map((course) {
                    final e = enrollmentFor(course.id);
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: CourseCard(
                        course: course,
                        enrollment: e,
                        studentTheme: widget.user.theme,
                        settings: settings,
                        trailing: FilledButton(
                          onPressed: () async {
                            await Navigator.push(context, MaterialPageRoute(builder: (_) => Directionality(textDirection: TextDirection.rtl, child: ReceiptScreen(api: widget.api, course: course, settings: settings))));
                            load();
                          },
                          child: Text(e == null ? 'ثبت‌نام' : 'ارسال دوباره رسید'),
                        ),
                      ),
                    );
                  }),
                ],
              ),
            ),
    );
  }
}

class ReceiptScreen extends StatefulWidget {
  const ReceiptScreen({super.key, required this.api, required this.course, required this.settings});
  final ApiClient api;
  final CourseModel course;
  final AppSettingsModel? settings;
  @override
  State<ReceiptScreen> createState() => _ReceiptScreenState();
}

class _ReceiptScreenState extends State<ReceiptScreen> {
  final receiptText = TextEditingController();
  String receiptFileUrl = '';
  String receiptFileName = '';
  bool sending = false;

  Future<void> pickReceipt() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['jpg', 'jpeg', 'png', 'webp', 'pdf']);
    if (result == null || result.files.isEmpty) return;
    try {
      final uploaded = await widget.api.uploadFile(result.files.first);
      setState(() {
        receiptFileUrl = uploaded['url'].toString();
        receiptFileName = uploaded['fileName']?.toString() ?? result.files.first.name;
      });
      if (mounted) showSnack(context, 'رسید آپلود شد');
    } catch (e) {
      if (mounted) showSnack(context, e.toString());
    }
  }

  Future<void> send() async {
    setState(() => sending = true);
    try {
      await widget.api.post('/api/enrollments', {
        'courseId': widget.course.id,
        'receiptText': receiptText.text.trim(),
        'receiptFileUrl': receiptFileUrl,
      });
      if (mounted) {
        showSnack(context, 'رسید ارسال شد و منتظر تایید معلم است');
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) showSnack(context, e.toString());
    } finally {
      if (mounted) setState(() => sending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.settings;
    return Scaffold(
      appBar: AppBar(title: const Text('پرداخت و ارسال رسید')),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          CourseCard(course: widget.course),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: cardDecoration(),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('اطلاعات کارت‌به‌کارت', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              SelectableText(s?.cardNumber ?? '-', textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              Text('به نام: ${s?.cardOwner ?? '-'}'),
              Text(s?.paymentHelp ?? ''),
            ]),
          ),
          const SizedBox(height: 12),
          TextField(controller: receiptText, maxLines: 3, decoration: const InputDecoration(labelText: 'توضیح رسید / کد پیگیری')),
          const SizedBox(height: 10),
          OutlinedButton.icon(onPressed: pickReceipt, icon: const Icon(Icons.upload_file), label: Text(receiptFileName.isEmpty ? 'انتخاب عکس یا PDF رسید' : receiptFileName)),
          const SizedBox(height: 14),
          FilledButton.icon(onPressed: sending ? null : send, icon: const Icon(Icons.send_rounded), label: Text(sending ? 'در حال ارسال...' : 'ارسال رسید برای تایید')),
        ],
      ),
    );
  }
}

class CourseCard extends StatelessWidget {
  const CourseCard({super.key, required this.course, this.trailing, this.teacherMode = false, this.enrollment, this.studentTheme = 'girl', this.settings});
  final CourseModel course;
  final Widget? trailing;
  final bool teacherMode;
  final EnrollmentModel? enrollment;
  final String studentTheme;
  final AppSettingsModel? settings;

  @override
  Widget build(BuildContext context) {
    final approved = enrollment?.status == 'approved';
    final color = themeColor(studentTheme);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: cardDecoration(),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Text(course.title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900))),
          if (trailing != null) trailing!,
        ]),
        const SizedBox(height: 6),
        Wrap(spacing: 8, runSpacing: 6, children: [
          Chip(label: Text(course.type == 'online' ? 'آنلاین' : 'آفلاین')),
          Chip(label: Text(course.grade)),
          Chip(label: Text(course.subject)),
          Chip(label: Text(course.isActive ? 'فعال' : 'غیرفعال')),
        ]),
        const SizedBox(height: 6),
        Text('زمان: ${course.schedule.isEmpty ? '-' : course.schedule}'),
        Text('قیمت: ${money(course.price)}'),
        if (course.description.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text(course.description)),
        if (enrollment != null) ...[
          const Divider(height: 20),
          Text('وضعیت ثبت‌نام: ${statusText(enrollment!.status)}', style: TextStyle(fontWeight: FontWeight.w900, color: approved ? Colors.green : color)),
          if (enrollment!.status == 'rejected' && enrollment!.rejectReason.isNotEmpty) Text('دلیل رد: ${enrollment!.rejectReason}'),
        ],
        if (approved) ...[
          const Divider(height: 20),
          if (course.accessLink.isNotEmpty) TextButton.icon(onPressed: () => launchUrlString(course.accessLink), icon: const Icon(Icons.video_call_rounded), label: const Text('ورود به کلاس / لینک دسترسی')),
          if (course.resources.isNotEmpty) const Text('منابع آموزشی:', style: TextStyle(fontWeight: FontWeight.w900)),
          ...course.resources.map((r) => ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.folder_rounded),
                title: Text(r.title),
                subtitle: Text(r.kind),
                onTap: () => launchUrlString(r.url),
              )),
        ] else if (!teacherMode && course.resources.isNotEmpty) ...[
          const SizedBox(height: 8),
          Text('منابع و لینک کلاس بعد از تایید پرداخت باز می‌شود.', style: TextStyle(color: color, fontWeight: FontWeight.w800)),
        ],
      ]),
    );
  }
}

BoxDecoration cardDecoration() => BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(22),
      boxShadow: [BoxShadow(color: Colors.black.withOpacity(.04), blurRadius: 14, offset: const Offset(0, 8))],
      border: Border.all(color: Colors.black.withOpacity(.05)),
    );

class EmptyState extends StatelessWidget {
  const EmptyState({super.key, required this.text});
  final String text;
  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.auto_stories_rounded, size: 70, color: Colors.black26),
            const SizedBox(height: 12),
            Text(text, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800)),
          ]),
        ),
      );
}

String guessKind(String filename) {
  final f = filename.toLowerCase();
  if (f.endsWith('.pdf')) return 'pdf';
  if (f.endsWith('.mp4') || f.endsWith('.mov')) return 'video';
  if (f.endsWith('.jpg') || f.endsWith('.jpeg') || f.endsWith('.png') || f.endsWith('.webp')) return 'image';
  return 'other';
}

void showSnack(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message.replaceFirst('Exception: ', ''))));
}

Future<bool> confirm(BuildContext context, String text) async {
  final res = await showDialog<bool>(
    context: context,
    builder: (_) => Directionality(
      textDirection: TextDirection.rtl,
      child: AlertDialog(
        title: const Text('تایید'),
        content: Text(text),
        actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('نه')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('بله'))],
      ),
    ),
  );
  return res == true;
}
