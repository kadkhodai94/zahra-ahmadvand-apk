# Private Teacher Flutter App - PHP/MySQL Backend Version

این نسخه به بک‌اند PHP/MySQL وصل می‌شود و برای هاست‌های معمولی سی‌پنل یا دایرکت‌ادمین مناسب است.

## تنظیم آدرس API

در صفحه ورود اپ، آدرس API را وارد کنید:

```text
https://likezilla.ir/ahmadvand/backend_php
```

یا داخل فایل زیر مقدار `defaultApiBaseUrl` را تغییر دهید:

```text
lib/main.dart
```

## گرفتن پکیج‌ها

```bash
flutter pub get
```

## اجرای اپ

```bash
flutter run
```

## ساخت APK

```bash
flutter build apk --release
```


نسخه V6: آدرس API داخل اپ ثابت شد و کاربر دیگر نیاز به وارد کردن دستی آدرس سرور ندارد.
API: https://likezilla.ir/ahmadvand/backend_php
