<?php
// این فایل فقط نمونه است. در نسخه V5 لازم نیست دستی کپی/ویرایشش کنی.
// کافی است install.php را در مرورگر باز کنی تا config.php خودکار ساخته شود.
return [
    'db_host' => 'localhost',
    'db_name' => 'ilkezi_teacher_app',
    'db_user' => 'ilkezi_teacher_app',
    'db_pass' => 'DATABASE_PASSWORD',
    'base_url' => 'https://YOUR_DOMAIN.com/backend_php',
    'teacher_phone' => '09120000000',
    'teacher_password' => '1234',
];
