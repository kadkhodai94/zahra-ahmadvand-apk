<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$configPath = __DIR__ . '/config.php';
if (!file_exists($configPath)) {
    json_response(['message' => 'فایل config.php ساخته نشده است. برای نصب خودکار install.php را باز کنید.'], 500);
}
$config = require $configPath;

try {
    $pdo = new PDO(
        'mysql:host=' . $config['db_host'] . ';dbname=' . $config['db_name'] . ';charset=utf8mb4',
        $config['db_user'],
        $config['db_pass'],
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (Throwable $e) {
    json_response(['message' => 'اتصال به دیتابیس برقرار نشد', 'error' => $e->getMessage()], 500);
}

$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?: '/';
$apiPos = strpos($path, '/api/');
$path = $apiPos === false ? '/' : substr($path, $apiPos);
$path = rtrim($path, '/');
$parts = array_values(array_filter(explode('/', $path)));

try {
    route($pdo, $config, $method, $parts);
} catch (HttpError $e) {
    json_response(['message' => $e->getMessage()], $e->status);
} catch (Throwable $e) {
    json_response(['message' => 'خطای داخلی سرور', 'error' => $e->getMessage()], 500);
}

function route(PDO $pdo, array $config, string $method, array $parts): void
{
    if (($parts[0] ?? '') !== 'api') {
        json_response(['message' => 'Private Teacher API - PHP/MySQL']);
    }

    $group = $parts[1] ?? '';

    if ($group === 'auth') {
        if ($method === 'POST' && ($parts[2] ?? '') === 'teacher-login') teacher_login($pdo);
        if ($method === 'POST' && ($parts[2] ?? '') === 'student-login') student_login($pdo);
        if ($method === 'GET' && ($parts[2] ?? '') === 'me') {
            $user = require_auth($pdo);
            json_response(['user' => public_user($user)]);
        }
    }

    if ($group === 'settings') {
        if ($method === 'GET') json_response(get_settings($pdo));
        if ($method === 'PUT') {
            teacher_only(require_auth($pdo));
            update_settings($pdo, body_json());
        }
    }

    if ($group === 'uploads') {
        if ($method === 'POST') {
            require_auth($pdo);
            upload_file($config);
        }
    }

    if ($group === 'courses') {
        $id = $parts[2] ?? null;
        if ($method === 'GET' && !$id) list_courses($pdo);
        if ($method === 'GET' && $id) show_course($pdo, (int)$id);
        if ($method === 'POST' && !$id) {
            teacher_only(require_auth($pdo));
            create_course($pdo, body_json());
        }
        if ($method === 'PUT' && $id && !isset($parts[3])) {
            teacher_only(require_auth($pdo));
            update_course($pdo, (int)$id, body_json());
        }
        if ($method === 'DELETE' && $id && !isset($parts[3])) {
            teacher_only(require_auth($pdo));
            delete_course($pdo, (int)$id);
        }
        if ($method === 'POST' && $id && ($parts[3] ?? '') === 'resources') {
            teacher_only(require_auth($pdo));
            add_resource($pdo, (int)$id, body_json());
        }
        if ($method === 'DELETE' && $id && ($parts[3] ?? '') === 'resources' && isset($parts[4])) {
            teacher_only(require_auth($pdo));
            delete_resource($pdo, (int)$id, (int)$parts[4]);
        }
    }

    if ($group === 'enrollments') {
        if ($method === 'GET') {
            $user = require_auth($pdo);
            list_enrollments($pdo, $user);
        }
        if ($method === 'POST') {
            $user = require_auth($pdo);
            student_only($user);
            create_enrollment($pdo, $user, body_json());
        }
        if ($method === 'PATCH' && isset($parts[2]) && ($parts[3] ?? '') === 'status') {
            teacher_only(require_auth($pdo));
            update_enrollment_status($pdo, (int)$parts[2], body_json());
        }
    }

    json_response(['message' => 'مسیر API پیدا نشد'], 404);
}

function body_json(): array
{
    $raw = file_get_contents('php://input') ?: '';
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function json_response($data, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

class HttpError extends Exception
{
    public int $status;
    public function __construct(string $message, int $status)
    {
        parent::__construct($message);
        $this->status = $status;
    }
}

function fail(string $message, int $status): void
{
    throw new HttpError($message, $status);
}

function bearer_token(): string
{
    $headers = function_exists('apache_request_headers') ? apache_request_headers() : [];
    $auth = $headers['Authorization'] ?? $headers['authorization'] ?? ($_SERVER['HTTP_AUTHORIZATION'] ?? '');
    if (preg_match('/Bearer\s+(.*)$/i', $auth, $m)) return trim($m[1]);
    return '';
}

function require_auth(PDO $pdo): array
{
    $token = bearer_token();
    if ($token === '') fail('لطفاً دوباره وارد شوید', 401);
    $stmt = $pdo->prepare('SELECT * FROM users WHERE token = ? LIMIT 1');
    $stmt->execute([$token]);
    $user = $stmt->fetch();
    if (!$user) fail('نشست کاربری معتبر نیست', 401);
    return $user;
}

function teacher_only(array $user): void
{
    if (($user['role'] ?? '') !== 'teacher') fail('دسترسی فقط برای معلم مجاز است', 403);
}

function student_only(array $user): void
{
    if (($user['role'] ?? '') !== 'student') fail('دسترسی فقط برای دانش‌آموز مجاز است', 403);
}

function public_user(array $user): array
{
    return [
        'id' => (string)$user['id'],
        '_id' => (string)$user['id'],
        'role' => $user['role'],
        'name' => $user['name'] ?? '',
        'phone' => $user['phone'] ?? '',
        'parentPhone' => $user['parent_phone'] ?? '',
        'theme' => $user['theme'] ?: 'girl',
    ];
}

function teacher_login(PDO $pdo): void
{
    $data = body_json();
    $phone = trim((string)($data['phone'] ?? ''));
    $password = (string)($data['password'] ?? '');
    if ($phone === '' || $password === '') fail('شماره موبایل و رمز لازم است', 400);

    $stmt = $pdo->prepare("SELECT * FROM users WHERE role = 'teacher' AND phone = ? LIMIT 1");
    $stmt->execute([$phone]);
    $teacher = $stmt->fetch();
    if (!$teacher || !password_verify($password, (string)$teacher['password_hash'])) fail('شماره یا رمز اشتباه است', 401);

    $token = bin2hex(random_bytes(32));
    $pdo->prepare('UPDATE users SET token = ?, updated_at = NOW() WHERE id = ?')->execute([$token, $teacher['id']]);
    $teacher['token'] = $token;
    json_response(['token' => $token, 'user' => public_user($teacher)]);
}

function student_login(PDO $pdo): void
{
    $data = body_json();
    $name = trim((string)($data['name'] ?? ''));
    $phone = trim((string)($data['phone'] ?? ''));
    $parentPhone = trim((string)($data['parentPhone'] ?? ''));
    $theme = ($data['theme'] ?? '') === 'boy' ? 'boy' : 'girl';
    if ($name === '' || $phone === '') fail('نام دانش‌آموز و شماره موبایل لازم است', 400);

    $stmt = $pdo->prepare("SELECT * FROM users WHERE role = 'student' AND phone = ? LIMIT 1");
    $stmt->execute([$phone]);
    $student = $stmt->fetch();
    $token = bin2hex(random_bytes(32));

    if (!$student) {
        $stmt = $pdo->prepare("INSERT INTO users (role, name, phone, parent_phone, theme, token, created_at, updated_at) VALUES ('student', ?, ?, ?, ?, ?, NOW(), NOW())");
        $stmt->execute([$name, $phone, $parentPhone, $theme, $token]);
        $id = (int)$pdo->lastInsertId();
        $student = get_user($pdo, $id);
    } else {
        $stmt = $pdo->prepare('UPDATE users SET name = ?, parent_phone = ?, theme = ?, token = ?, updated_at = NOW() WHERE id = ?');
        $stmt->execute([$name, $parentPhone ?: ($student['parent_phone'] ?? ''), $theme, $token, $student['id']]);
        $student = get_user($pdo, (int)$student['id']);
    }

    json_response(['token' => $token, 'user' => public_user($student)]);
}

function get_user(PDO $pdo, int $id): array
{
    $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
    $stmt->execute([$id]);
    $user = $stmt->fetch();
    if (!$user) fail('کاربر پیدا نشد', 404);
    return $user;
}

function get_settings(PDO $pdo): array
{
    $stmt = $pdo->query('SELECT * FROM settings WHERE id = 1');
    $s = $stmt->fetch();
    if (!$s) {
        $pdo->exec("INSERT INTO settings (id, app_title, teacher_name, card_number, card_owner, support_phone, payment_help, created_at, updated_at) VALUES (1, 'کلاس خصوصی مهربون', 'خانم معلم', '6037 0000 0000 0000', 'نام صاحب کارت', '09xxxxxxxxx', 'بعد از کارت‌به‌کارت، رسید را ثبت کن.', NOW(), NOW())");
        return get_settings($pdo);
    }
    return [
        '_id' => '1',
        'id' => '1',
        'appTitle' => $s['app_title'],
        'teacherName' => $s['teacher_name'],
        'cardNumber' => $s['card_number'],
        'cardOwner' => $s['card_owner'],
        'supportPhone' => $s['support_phone'],
        'paymentHelp' => $s['payment_help'],
    ];
}

function update_settings(PDO $pdo, array $data): void
{
    get_settings($pdo);
    $fields = [
        'appTitle' => 'app_title',
        'teacherName' => 'teacher_name',
        'cardNumber' => 'card_number',
        'cardOwner' => 'card_owner',
        'supportPhone' => 'support_phone',
        'paymentHelp' => 'payment_help',
    ];
    $updates = [];
    $values = [];
    foreach ($fields as $json => $col) {
        if (isset($data[$json]) && is_string($data[$json])) {
            $updates[] = "$col = ?";
            $values[] = $data[$json];
        }
    }
    if ($updates) {
        $values[] = 1;
        $pdo->prepare('UPDATE settings SET ' . implode(', ', $updates) . ', updated_at = NOW() WHERE id = ?')->execute($values);
    }
    json_response(get_settings($pdo));
}

function upload_file(array $config): void
{
    if (!isset($_FILES['file']) || ($_FILES['file']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        fail('فایل ارسال نشده است', 400);
    }
    $file = $_FILES['file'];
    $max = 20 * 1024 * 1024;
    if (($file['size'] ?? 0) > $max) fail('حجم فایل بیشتر از ۲۰ مگابایت است', 400);

    $original = basename((string)$file['name']);
    $ext = strtolower(pathinfo($original, PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png', 'webp', 'pdf', 'mp4', 'mov', 'mp3', 'zip', 'doc', 'docx', 'ppt', 'pptx'];
    if (!in_array($ext, $allowed, true)) fail('نوع فایل مجاز نیست', 400);

    $dir = __DIR__ . '/uploads';
    if (!is_dir($dir)) mkdir($dir, 0755, true);
    $safeName = date('Ymd_His') . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
    $target = $dir . '/' . $safeName;
    if (!move_uploaded_file((string)$file['tmp_name'], $target)) fail('آپلود فایل انجام نشد', 500);

    $baseUrl = rtrim((string)$config['base_url'], '/');
    json_response([
        'url' => $baseUrl . '/uploads/' . $safeName,
        'fileName' => $original,
        'mimeType' => (string)($file['type'] ?? ''),
        'size' => (int)$file['size'],
    ], 201);
}

function course_row(PDO $pdo, int $id): ?array
{
    $stmt = $pdo->prepare('SELECT * FROM courses WHERE id = ?');
    $stmt->execute([$id]);
    $course = $stmt->fetch();
    return $course ?: null;
}

function resources_for_course(PDO $pdo, int $courseId): array
{
    $stmt = $pdo->prepare('SELECT * FROM course_resources WHERE course_id = ? ORDER BY id ASC');
    $stmt->execute([$courseId]);
    return array_map(fn($r) => [
        '_id' => (string)$r['id'],
        'id' => (string)$r['id'],
        'title' => $r['title'],
        'kind' => $r['kind'],
        'url' => $r['url'],
        'fileName' => $r['file_name'] ?? '',
    ], $stmt->fetchAll());
}

function course_json(PDO $pdo, array $c): array
{
    return [
        '_id' => (string)$c['id'],
        'id' => (string)$c['id'],
        'title' => $c['title'],
        'subject' => $c['subject'],
        'grade' => $c['grade'],
        'price' => (int)$c['price'],
        'schedule' => $c['schedule'] ?? '',
        'type' => $c['type'] ?: 'online',
        'accessLink' => $c['access_link'] ?? '',
        'description' => $c['description'] ?? '',
        'isActive' => ((int)$c['is_active']) === 1,
        'resources' => resources_for_course($pdo, (int)$c['id']),
        'createdAt' => $c['created_at'] ?? '',
    ];
}

function list_courses(PDO $pdo): void
{
    $stmt = $pdo->query('SELECT * FROM courses ORDER BY created_at DESC, id DESC');
    $out = [];
    foreach ($stmt->fetchAll() as $c) $out[] = course_json($pdo, $c);
    json_response($out);
}

function show_course(PDO $pdo, int $id): void
{
    $c = course_row($pdo, $id);
    if (!$c) fail('کلاس پیدا نشد', 404);
    json_response(course_json($pdo, $c));
}

function to_number($value): int
{
    return (int)preg_replace('/[^0-9]/', '', (string)$value);
}

function create_course(PDO $pdo, array $data): void
{
    $title = trim((string)($data['title'] ?? ''));
    $subject = trim((string)($data['subject'] ?? ''));
    $grade = trim((string)($data['grade'] ?? ''));
    if ($title === '' || $subject === '' || $grade === '') fail('عنوان، درس و پایه لازم است', 400);
    $type = ($data['type'] ?? '') === 'offline' ? 'offline' : 'online';
    $isActive = array_key_exists('isActive', $data) ? (($data['isActive'] === true || $data['isActive'] === 1) ? 1 : 0) : 1;

    $stmt = $pdo->prepare('INSERT INTO courses (title, subject, grade, price, schedule, type, access_link, description, is_active, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())');
    $stmt->execute([$title, $subject, $grade, to_number($data['price'] ?? 0), (string)($data['schedule'] ?? ''), $type, (string)($data['accessLink'] ?? ''), (string)($data['description'] ?? ''), $isActive]);
    $id = (int)$pdo->lastInsertId();

    if (isset($data['resources']) && is_array($data['resources'])) {
        foreach ($data['resources'] as $r) insert_resource($pdo, $id, is_array($r) ? $r : []);
    }
    json_response(course_json($pdo, course_row($pdo, $id)), 201);
}

function update_course(PDO $pdo, int $id, array $data): void
{
    if (!course_row($pdo, $id)) fail('کلاس پیدا نشد', 404);
    $fields = [
        'title' => 'title',
        'subject' => 'subject',
        'grade' => 'grade',
        'schedule' => 'schedule',
        'accessLink' => 'access_link',
        'description' => 'description',
    ];
    $updates = [];
    $values = [];
    foreach ($fields as $json => $col) {
        if (isset($data[$json]) && is_string($data[$json])) {
            $updates[] = "$col = ?";
            $values[] = $data[$json];
        }
    }
    if (isset($data['type']) && in_array($data['type'], ['online', 'offline'], true)) {
        $updates[] = 'type = ?';
        $values[] = $data['type'];
    }
    if (array_key_exists('price', $data)) {
        $updates[] = 'price = ?';
        $values[] = to_number($data['price']);
    }
    if (array_key_exists('isActive', $data)) {
        $updates[] = 'is_active = ?';
        $values[] = ($data['isActive'] === true || $data['isActive'] === 1) ? 1 : 0;
    }
    if ($updates) {
        $values[] = $id;
        $pdo->prepare('UPDATE courses SET ' . implode(', ', $updates) . ', updated_at = NOW() WHERE id = ?')->execute($values);
    }
    if (isset($data['resources']) && is_array($data['resources'])) {
        $pdo->prepare('DELETE FROM course_resources WHERE course_id = ?')->execute([$id]);
        foreach ($data['resources'] as $r) insert_resource($pdo, $id, is_array($r) ? $r : []);
    }
    json_response(course_json($pdo, course_row($pdo, $id)));
}

function delete_course(PDO $pdo, int $id): void
{
    if (!course_row($pdo, $id)) fail('کلاس پیدا نشد', 404);
    $pdo->prepare('DELETE FROM enrollments WHERE course_id = ?')->execute([$id]);
    $pdo->prepare('DELETE FROM course_resources WHERE course_id = ?')->execute([$id]);
    $pdo->prepare('DELETE FROM courses WHERE id = ?')->execute([$id]);
    json_response(['ok' => true]);
}

function insert_resource(PDO $pdo, int $courseId, array $data): void
{
    $title = trim((string)($data['title'] ?? ''));
    $url = trim((string)($data['url'] ?? ''));
    if ($title === '' || $url === '') return;
    $kind = (string)($data['kind'] ?? 'link');
    $fileName = (string)($data['fileName'] ?? '');
    $pdo->prepare('INSERT INTO course_resources (course_id, title, kind, url, file_name, created_at) VALUES (?, ?, ?, ?, ?, NOW())')->execute([$courseId, $title, $kind, $url, $fileName]);
}

function add_resource(PDO $pdo, int $courseId, array $data): void
{
    if (!course_row($pdo, $courseId)) fail('کلاس پیدا نشد', 404);
    if (trim((string)($data['title'] ?? '')) === '' || trim((string)($data['url'] ?? '')) === '') fail('عنوان و لینک فایل لازم است', 400);
    insert_resource($pdo, $courseId, $data);
    json_response(course_json($pdo, course_row($pdo, $courseId)), 201);
}

function delete_resource(PDO $pdo, int $courseId, int $resourceId): void
{
    if (!course_row($pdo, $courseId)) fail('کلاس پیدا نشد', 404);
    $pdo->prepare('DELETE FROM course_resources WHERE course_id = ? AND id = ?')->execute([$courseId, $resourceId]);
    json_response(course_json($pdo, course_row($pdo, $courseId)));
}

function enrollment_json(PDO $pdo, array $e): array
{
    $course = course_row($pdo, (int)$e['course_id']);
    $student = get_user($pdo, (int)$e['student_id']);
    return [
        '_id' => (string)$e['id'],
        'id' => (string)$e['id'],
        'status' => $e['status'] ?: 'pending',
        'receiptText' => $e['receipt_text'] ?? '',
        'receiptFileUrl' => $e['receipt_file_url'] ?? '',
        'rejectReason' => $e['reject_reason'] ?? '',
        'course' => $course ? course_json($pdo, $course) : null,
        'student' => public_user($student),
        'createdAt' => $e['created_at'] ?? '',
    ];
}

function list_enrollments(PDO $pdo, array $user): void
{
    if ($user['role'] === 'teacher') {
        $stmt = $pdo->query('SELECT * FROM enrollments ORDER BY created_at DESC, id DESC');
    } else {
        $stmt = $pdo->prepare('SELECT * FROM enrollments WHERE student_id = ? ORDER BY created_at DESC, id DESC');
        $stmt->execute([$user['id']]);
    }
    $out = [];
    foreach ($stmt->fetchAll() as $e) $out[] = enrollment_json($pdo, $e);
    json_response($out);
}

function create_enrollment(PDO $pdo, array $user, array $data): void
{
    $courseId = (int)($data['courseId'] ?? 0);
    if ($courseId <= 0) fail('کلاس انتخاب نشده است', 400);
    $course = course_row($pdo, $courseId);
    if (!$course || (int)$course['is_active'] !== 1) fail('کلاس فعال پیدا نشد', 404);

    $receiptText = (string)($data['receiptText'] ?? '');
    $receiptFileUrl = (string)($data['receiptFileUrl'] ?? '');
    $stmt = $pdo->prepare('SELECT * FROM enrollments WHERE course_id = ? AND student_id = ? LIMIT 1');
    $stmt->execute([$courseId, $user['id']]);
    $e = $stmt->fetch();
    if (!$e) {
        $stmt = $pdo->prepare("INSERT INTO enrollments (course_id, student_id, status, receipt_text, receipt_file_url, reject_reason, created_at, updated_at) VALUES (?, ?, 'pending', ?, ?, '', NOW(), NOW())");
        $stmt->execute([$courseId, $user['id'], $receiptText, $receiptFileUrl]);
        $id = (int)$pdo->lastInsertId();
    } else {
        $stmt = $pdo->prepare("UPDATE enrollments SET status = 'pending', receipt_text = ?, receipt_file_url = ?, reject_reason = '', updated_at = NOW() WHERE id = ?");
        $stmt->execute([$receiptText ?: ($e['receipt_text'] ?? ''), $receiptFileUrl ?: ($e['receipt_file_url'] ?? ''), $e['id']]);
        $id = (int)$e['id'];
    }
    $stmt = $pdo->prepare('SELECT * FROM enrollments WHERE id = ?');
    $stmt->execute([$id]);
    json_response(enrollment_json($pdo, $stmt->fetch()), 201);
}

function update_enrollment_status(PDO $pdo, int $id, array $data): void
{
    $status = (string)($data['status'] ?? '');
    if (!in_array($status, ['approved', 'rejected', 'pending'], true)) fail('وضعیت معتبر نیست', 400);
    $stmt = $pdo->prepare('SELECT * FROM enrollments WHERE id = ?');
    $stmt->execute([$id]);
    $e = $stmt->fetch();
    if (!$e) fail('ثبت‌نام پیدا نشد', 404);
    $rejectReason = $status === 'rejected' ? (string)($data['rejectReason'] ?? '') : '';
    $pdo->prepare('UPDATE enrollments SET status = ?, reject_reason = ?, reviewed_at = NOW(), updated_at = NOW() WHERE id = ?')->execute([$status, $rejectReason, $id]);
    $stmt = $pdo->prepare('SELECT * FROM enrollments WHERE id = ?');
    $stmt->execute([$id]);
    json_response(enrollment_json($pdo, $stmt->fetch()));
}
