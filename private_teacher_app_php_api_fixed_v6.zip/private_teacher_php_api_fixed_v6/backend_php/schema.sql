CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  role ENUM('teacher','student') NOT NULL,
  name VARCHAR(160) NOT NULL,
  phone VARCHAR(40) NOT NULL,
  password_hash VARCHAR(255) NULL,
  parent_phone VARCHAR(40) NULL,
  theme ENUM('girl','boy') DEFAULT 'girl',
  token VARCHAR(128) NULL,
  created_at DATETIME NULL,
  updated_at DATETIME NULL,
  UNIQUE KEY unique_role_phone (role, phone),
  INDEX idx_token (token)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS courses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(220) NOT NULL,
  subject VARCHAR(120) NOT NULL,
  grade VARCHAR(120) NOT NULL,
  price INT NOT NULL DEFAULT 0,
  schedule VARCHAR(220) NULL,
  type ENUM('online','offline') DEFAULT 'online',
  access_link TEXT NULL,
  description TEXT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NULL,
  updated_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS course_resources (
  id INT AUTO_INCREMENT PRIMARY KEY,
  course_id INT NOT NULL,
  title VARCHAR(220) NOT NULL,
  kind VARCHAR(60) DEFAULT 'link',
  url TEXT NOT NULL,
  file_name VARCHAR(255) NULL,
  created_at DATETIME NULL,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS enrollments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  course_id INT NOT NULL,
  student_id INT NOT NULL,
  status ENUM('pending','approved','rejected') DEFAULT 'pending',
  receipt_text TEXT NULL,
  receipt_file_url TEXT NULL,
  reject_reason TEXT NULL,
  reviewed_at DATETIME NULL,
  created_at DATETIME NULL,
  updated_at DATETIME NULL,
  UNIQUE KEY unique_course_student (course_id, student_id),
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
  FOREIGN KEY (student_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS settings (
  id INT PRIMARY KEY,
  app_title VARCHAR(180) NOT NULL DEFAULT 'کلاس خصوصی مهربون',
  teacher_name VARCHAR(180) NOT NULL DEFAULT 'خانم معلم',
  card_number VARCHAR(80) NOT NULL DEFAULT '6037 0000 0000 0000',
  card_owner VARCHAR(180) NOT NULL DEFAULT 'نام صاحب کارت',
  support_phone VARCHAR(60) NOT NULL DEFAULT '09xxxxxxxxx',
  payment_help TEXT NULL,
  created_at DATETIME NULL,
  updated_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
