import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import 'package:webview_flutter/webview_flutter.dart';

const String apiBaseUrl = 'https://likezilla.ir/ahmadvand/backend_php';
const String fixedTeacherPhone = '09035906224';

const Color kPurple = Color(0xFF7B61FF);
const Color kPink = Color(0xFFFF6FAE);
const Color kBlue = Color(0xFF4DA3FF);
const Color kGreen = Color(0xFF20B869);
const Color kOrange = Color(0xFFFFA726);
const Color kText = Color(0xFF1C1C28);
const Color kMuted = Color(0xFF6E6E7A);
const Color kSoft = Color(0xFFF8F7FF);

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.dark,
    systemNavigationBarColor: Colors.white,
    systemNavigationBarIconBrightness: Brightness.dark,
  ));
  runApp(const PrivateTeacherApp());
}

String money(dynamic value) {
  final raw = value.toString().trim();
  if (raw.contains('تومان')) return raw;
  final n = int.tryParse(raw.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;
  final s = n.toString();
  final out = StringBuffer();
  for (int i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) out.write(',');
    out.write(s[i]);
  }
  return '${out.toString()} تومان';
}

String cleanError(Object e) => e.toString().replaceFirst('Exception: ', '').replaceFirst('ApiError: ', '');
void toast(BuildContext context, Object text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(cleanError(text)), behavior: SnackBarBehavior.floating));
Color themeColor(String theme) => theme == 'boy' ? kBlue : kPink;
String themeEmoji(String theme) => theme == 'boy' ? '🚀' : '🌸';
String statusText(String status) => status == 'approved' ? 'تایید شده' : status == 'rejected' ? 'رد شده' : 'در انتظار بررسی';

String guessType(String value) {
  final v = value.toLowerCase();
  if (v.contains('pdf') || v.endsWith('.pdf')) return 'pdf';
  if (v.contains('word') || v.endsWith('.doc') || v.endsWith('.docx')) return 'word';
  if (v.contains('image') || v.endsWith('.jpg') || v.endsWith('.jpeg') || v.endsWith('.png') || v.endsWith('.webp') || v.endsWith('.gif')) return 'image';
  if (v.contains('video') || v.endsWith('.mp4') || v.endsWith('.mov') || v.endsWith('.webm') || v.endsWith('.m3u8')) return 'video';
  return 'link';
}

String typeLabel(String type) {
  switch (type) {
    case 'pdf': return 'PDF';
    case 'word': return 'Word';
    case 'image': return 'عکس';
    case 'video': return 'ویدئو';
    default: return 'لینک';
  }
}

String typeIcon(String type) {
  switch (type) {
    case 'pdf': return '📕';
    case 'word': return '📝';
    case 'image': return '🖼️';
    case 'video': return '🎬';
    default: return '🔗';
  }
}

String docsViewerUrl(String url) => 'https://docs.google.com/gview?embedded=1&url=${Uri.encodeComponent(url)}';

class PrivateTeacherApp extends StatelessWidget {
  const PrivateTeacherApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'کلاس خصوصی',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: kPurple,
        scaffoldBackgroundColor: kSoft,
        fontFamily: 'Roboto',
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: const BorderSide(color: Color(0x11000000))),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: const BorderSide(color: Color(0x11000000))),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: const BorderSide(color: kPurple, width: 1.4)),
        ),
      ),
      home: const Directionality(textDirection: TextDirection.rtl, child: AppRoot()),
    );
  }
}

class ApiError implements Exception {
  ApiError(this.message);
  final String message;
  @override
  String toString() => message;
}

class ApiClient {
  String? token;
  Map<String, String> get headers => {
    'Content-Type': 'application/json',
    if (token != null && token!.isNotEmpty) 'Authorization': 'Bearer $token',
  };
  Uri uri(String path) => Uri.parse('$apiBaseUrl$path');

  Future<dynamic> _handle(http.Response res) async {
    dynamic body;
    try { body = res.body.isEmpty ? null : jsonDecode(res.body); } catch (_) { body = null; }
    if (res.statusCode >= 200 && res.statusCode < 300) return body;
    if (body is Map && body['message'] != null) throw ApiError(body['message'].toString());
    throw ApiError('خطا در ارتباط با سرور');
  }

  Future<dynamic> _request(Future<http.Response> Function() call) async {
    try {
      return _handle(await call().timeout(const Duration(seconds: 25)));
    } on ApiError { rethrow; }
      on SocketException { throw ApiError('اتصال به سرور برقرار نشد. اینترنت، VPN یا DNS دامنه را بررسی کن.'); }
      on TimeoutException { throw ApiError('سرور دیر پاسخ داد. اینترنت یا هاست را بررسی کن.'); }
      on http.ClientException { throw ApiError('ارتباط با سرور برقرار نشد.'); }
      catch (_) { throw ApiError('خطای ارتباط با سرور.'); }
  }

  Future<dynamic> get(String path) => _request(() => http.get(uri(path), headers: headers));
  Future<dynamic> post(String path, Map<String, dynamic> data) => _request(() => http.post(uri(path), headers: headers, body: jsonEncode(data)));
  Future<dynamic> put(String path, Map<String, dynamic> data) => _request(() => http.put(uri(path), headers: headers, body: jsonEncode(data)));
  Future<dynamic> patch(String path, Map<String, dynamic> data) => _request(() => http.patch(uri(path), headers: headers, body: jsonEncode(data)));
  Future<dynamic> delete(String path) => _request(() => http.delete(uri(path), headers: headers));

  Future<UploadedFile> uploadLocalFile(File file) async {
    try {
      final req = http.MultipartRequest('POST', uri('/api/uploads'));
      if (token != null && token!.isNotEmpty) req.headers['Authorization'] = 'Bearer $token';
      req.files.add(await http.MultipartFile.fromPath('file', file.path));
      final streamed = await req.send().timeout(const Duration(seconds: 60));
      final res = await http.Response.fromStream(streamed);
      final body = await _handle(res);
      if (body is Map) return UploadedFile.fromJson(Map<String, dynamic>.from(body));
      throw ApiError('پاسخ آپلود معتبر نیست');
    } on ApiError { rethrow; }
      on SocketException { throw ApiError('اتصال به سرور برقرار نشد. اینترنت را بررسی کن.'); }
      on TimeoutException { throw ApiError('آپلود عکس طول کشید. اینترنت یا حجم عکس را بررسی کن.'); }
      on http.ClientException { throw ApiError('آپلود عکس انجام نشد.'); }
      catch (_) { throw ApiError('خطا در آپلود عکس.'); }
  }
}

class UploadedFile {
  UploadedFile({required this.url, required this.fileName, required this.mimeType, required this.size});
  factory UploadedFile.fromJson(Map<String, dynamic> j) => UploadedFile(
    url: j['url']?.toString() ?? '',
    fileName: j['fileName']?.toString() ?? 'image',
    mimeType: j['mimeType']?.toString() ?? '',
    size: int.tryParse(j['size']?.toString() ?? '') ?? 0,
  );
  final String url;
  final String fileName;
  final String mimeType;
  final int size;
}

Future<UploadedFile?> pickGalleryImageAndUpload(BuildContext context, ApiClient api) async {
  try {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 82, maxWidth: 1600, maxHeight: 1600);
    if (picked == null) return null;
    final uploaded = await api.uploadLocalFile(File(picked.path));
    if (uploaded.url.isEmpty) throw ApiError('لینک عکس از سرور دریافت نشد');
    return uploaded;
  } catch (e) {
    if (context.mounted) toast(context, e);
    return null;
  }
}

class AppSettings {
  AppSettings({required this.appTitle, required this.teacherName, required this.cardNumber, required this.cardOwner, required this.supportPhone, required this.paymentHelp});
  factory AppSettings.fromJson(Map<String, dynamic> j) => AppSettings(
    appTitle: j['appTitle']?.toString() ?? 'کلاس خصوصی مهربون',
    teacherName: j['teacherName']?.toString() ?? 'خانم معلم',
    cardNumber: j['cardNumber']?.toString() ?? '6037 0000 0000 0000',
    cardOwner: j['cardOwner']?.toString() ?? 'نام صاحب کارت',
    supportPhone: j['supportPhone']?.toString() ?? '09xxxxxxxxx',
    paymentHelp: j['paymentHelp']?.toString() ?? 'بعد از کارت‌به‌کارت، رسید را ثبت کن.',
  );
  final String appTitle;
  final String teacherName;
  final String cardNumber;
  final String cardOwner;
  final String supportPhone;
  final String paymentHelp;
  Map<String, dynamic> toJson() => {'appTitle': appTitle, 'teacherName': teacherName, 'cardNumber': cardNumber, 'cardOwner': cardOwner, 'supportPhone': supportPhone, 'paymentHelp': paymentHelp};
}

class UserData {
  UserData({required this.id, required this.role, required this.name, required this.phone, required this.parentPhone, required this.theme});
  factory UserData.fromJson(Map<String, dynamic> j) => UserData(
    id: j['id']?.toString() ?? j['_id']?.toString() ?? '',
    role: j['role']?.toString() ?? '',
    name: j['name']?.toString() ?? '',
    phone: j['phone']?.toString() ?? '',
    parentPhone: j['parentPhone']?.toString() ?? j['parent_phone']?.toString() ?? '',
    theme: j['theme']?.toString() == 'boy' ? 'boy' : 'girl',
  );
  final String id;
  final String role;
  final String name;
  final String phone;
  final String parentPhone;
  final String theme;
}

class Course {
  Course({required this.id, required this.title, required this.subject, required this.grade, required this.price, required this.schedule, required this.type, required this.accessLink, required this.description, required this.isActive});
  factory Course.fromJson(Map<String, dynamic> j) => Course(
    id: j['id']?.toString() ?? j['_id']?.toString() ?? '',
    title: j['title']?.toString() ?? '',
    subject: j['subject']?.toString() ?? '',
    grade: j['grade']?.toString() ?? '',
    price: int.tryParse(j['price'].toString()) ?? 0,
    schedule: j['schedule']?.toString() ?? '',
    type: j['type']?.toString() == 'offline' ? 'offline' : 'online',
    accessLink: j['accessLink']?.toString() ?? '',
    description: j['description']?.toString() ?? '',
    isActive: j['isActive'] == true || j['isActive'] == 1 || j['isActive']?.toString() == '1',
  );
  final String id, title, subject, grade, schedule, type, accessLink, description;
  final int price;
  final bool isActive;
}

class Enrollment {
  Enrollment({required this.id, required this.status, required this.receiptText, required this.receiptFileUrl, required this.rejectReason, this.course, this.student});
  factory Enrollment.fromJson(Map<String, dynamic> j) => Enrollment(
    id: j['id']?.toString() ?? j['_id']?.toString() ?? '',
    status: j['status']?.toString() ?? 'pending',
    receiptText: j['receiptText']?.toString() ?? j['receipt_text']?.toString() ?? '',
    receiptFileUrl: j['receiptFileUrl']?.toString() ?? j['receipt_file_url']?.toString() ?? '',
    rejectReason: j['rejectReason']?.toString() ?? j['reject_reason']?.toString() ?? '',
    course: j['course'] is Map ? Course.fromJson(Map<String, dynamic>.from(j['course'])) : null,
    student: j['student'] is Map ? UserData.fromJson(Map<String, dynamic>.from(j['student'])) : null,
  );
  final String id, status, receiptText, receiptFileUrl, rejectReason;
  final Course? course;
  final UserData? student;
}

class LearningFile {
  LearningFile({required this.id, required this.title, required this.type, required this.url, required this.description, required this.courseId, required this.courseTitle, required this.isActive});
  factory LearningFile.fromJson(Map<String, dynamic> j) {
    final course = j['course'];
    return LearningFile(
      id: j['id']?.toString() ?? j['_id']?.toString() ?? '',
      title: j['title']?.toString() ?? '',
      type: j['type']?.toString() ?? guessType('${j['url'] ?? ''}'),
      url: j['url']?.toString() ?? '',
      description: j['description']?.toString() ?? '',
      courseId: j['courseId']?.toString() ?? j['course_id']?.toString() ?? '',
      courseTitle: course is Map ? (course['title']?.toString() ?? '') : (j['courseTitle']?.toString() ?? ''),
      isActive: j['isActive'] == true || j['isActive'] == 1 || j['isActive']?.toString() == '1',
    );
  }
  final String id, title, type, url, description, courseId, courseTitle;
  final bool isActive;
}

class Assignment {
  Assignment({required this.id, required this.courseId, required this.courseTitle, required this.title, required this.description, required this.dueDate, required this.isActive, this.submission});
  factory Assignment.fromJson(Map<String, dynamic> j) {
    final course = j['course'];
    return Assignment(
      id: j['id']?.toString() ?? j['_id']?.toString() ?? '',
      courseId: j['courseId']?.toString() ?? j['course_id']?.toString() ?? '',
      courseTitle: course is Map ? (course['title']?.toString() ?? '') : (j['courseTitle']?.toString() ?? ''),
      title: j['title']?.toString() ?? '',
      description: j['description']?.toString() ?? '',
      dueDate: j['dueDate']?.toString() ?? j['due_date']?.toString() ?? '',
      isActive: j['isActive'] == true || j['isActive'] == 1 || j['isActive']?.toString() == '1',
      submission: j['submission'] is Map ? Submission.fromJson(Map<String, dynamic>.from(j['submission'])) : null,
    );
  }
  final String id, courseId, courseTitle, title, description, dueDate;
  final bool isActive;
  final Submission? submission;
}

class Submission {
  Submission({required this.id, required this.answerText, required this.imageUrl, required this.status, required this.teacherNote, this.assignment, this.student});
  factory Submission.fromJson(Map<String, dynamic> j) => Submission(
    id: j['id']?.toString() ?? j['_id']?.toString() ?? '',
    answerText: j['answerText']?.toString() ?? j['answer_text']?.toString() ?? '',
    imageUrl: j['imageUrl']?.toString() ?? j['image_url']?.toString() ?? '',
    status: j['status']?.toString() ?? 'sent',
    teacherNote: j['teacherNote']?.toString() ?? j['teacher_note']?.toString() ?? '',
    assignment: j['assignment'] is Map ? Assignment.fromJson(Map<String, dynamic>.from(j['assignment'])) : null,
    student: j['student'] is Map ? UserData.fromJson(Map<String, dynamic>.from(j['student'])) : null,
  );
  final String id, answerText, imageUrl, status, teacherNote;
  final Assignment? assignment;
  final UserData? student;
}

class TeacherMessage {
  TeacherMessage({required this.id, required this.message, required this.reply, required this.isRead, this.student});
  factory TeacherMessage.fromJson(Map<String, dynamic> j) => TeacherMessage(
    id: j['id']?.toString() ?? j['_id']?.toString() ?? '',
    message: j['message']?.toString() ?? '',
    reply: j['reply']?.toString() ?? '',
    isRead: j['isRead'] == true || j['isRead'] == 1 || j['is_read']?.toString() == '1',
    student: j['student'] is Map ? UserData.fromJson(Map<String, dynamic>.from(j['student'])) : null,
  );
  final String id, message, reply;
  final bool isRead;
  final UserData? student;
}

class AppRoot extends StatefulWidget {
  const AppRoot({super.key});
  @override
  State<AppRoot> createState() => _AppRootState();
}

class _AppRootState extends State<AppRoot> {
  final api = ApiClient();
  AppSettings settings = AppSettings.fromJson({});
  UserData? user;
  bool loading = true;
  String page = 'role';

  @override
  void initState() { super.initState(); loadSettings(); }
  Future<void> loadSettings() async {
    try {
      final res = await api.get('/api/settings');
      if (res is Map) settings = AppSettings.fromJson(Map<String, dynamic>.from(res));
    } catch (_) {}
    if (mounted) setState(() => loading = false);
  }
  void login(String token, UserData u) => setState(() { api.token = token; user = u; });
  void logout() => setState(() { api.token = null; user = null; page = 'role'; });

  @override
  Widget build(BuildContext context) {
    if (loading) return const GradientScaffold(child: Center(child: CircularProgressIndicator()));
    if (user?.role == 'teacher') return TeacherShell(api: api, settings: settings, user: user!, onLogout: logout, reloadSettings: loadSettings);
    if (user?.role == 'student') return StudentShell(api: api, settings: settings, user: user!, onLogout: logout);
    if (page == 'teacher') return TeacherLoginScreen(api: api, onBack: () => setState(() => page = 'role'), onLogin: login);
    if (page == 'student') return StudentLoginScreen(api: api, onBack: () => setState(() => page = 'role'), onLogin: login);
    return RoleScreen(settings: settings, onTeacher: () => setState(() => page = 'teacher'), onStudent: () => setState(() => page = 'student'));
  }
}

class GradientScaffold extends StatelessWidget {
  const GradientScaffold({super.key, required this.child});
  final Widget child;
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Container(
      width: double.infinity,
      height: double.infinity,
      decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFFFF7FB), Color(0xFFEFF8FF), Color(0xFFF8F7FF)])),
      child: SafeArea(child: child),
    ),
  );
}

class SoftCard extends StatelessWidget {
  const SoftCard({super.key, required this.child, this.onTap, this.padding = const EdgeInsets.all(16)});
  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsets padding;
  @override
  Widget build(BuildContext context) {
    final card = Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24), boxShadow: const [BoxShadow(color: Color(0x10000000), blurRadius: 24, offset: Offset(0, 10))]),
      child: child,
    );
    return onTap == null ? card : InkWell(borderRadius: BorderRadius.circular(24), onTap: onTap, child: card);
  }
}

class CircleLogo extends StatelessWidget {
  const CircleLogo(this.icon, {super.key, this.size = 102});
  final String icon;
  final double size;
  @override
  Widget build(BuildContext context) => Container(width: size, height: size, decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle, boxShadow: [BoxShadow(color: Color(0x14000000), blurRadius: 24, offset: Offset(0, 12))]), child: Center(child: Text(icon, style: TextStyle(fontSize: size * .45))));
}

class PrimaryButton extends StatelessWidget {
  const PrimaryButton({super.key, required this.text, required this.onTap, this.color = kPurple, this.height = 54});
  final String text;
  final VoidCallback? onTap;
  final Color color;
  final double height;
  @override
  Widget build(BuildContext context) => SizedBox(
    height: height,
    width: double.infinity,
    child: ElevatedButton(onPressed: onTap, style: ElevatedButton.styleFrom(backgroundColor: color, foregroundColor: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))), child: Text(text, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
  );
}

class TinyPill extends StatelessWidget {
  const TinyPill(this.text, {super.key, this.color = kPurple});
  final String text;
  final Color color;
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), decoration: BoxDecoration(color: color.withOpacity(.10), borderRadius: BorderRadius.circular(999)), child: Text(text, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.bold)));
}

class RoleScreen extends StatelessWidget {
  const RoleScreen({super.key, required this.settings, required this.onTeacher, required this.onStudent});
  final AppSettings settings;
  final VoidCallback onTeacher;
  final VoidCallback onStudent;
  @override
  Widget build(BuildContext context) => GradientScaffold(
    child: Center(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 460),
          child: SoftCard(
            padding: const EdgeInsets.fromLTRB(20, 28, 20, 28),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const CircleLogo('🎒'),
              const SizedBox(height: 20),
              Text(settings.appTitle, textAlign: TextAlign.center, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900, color: kText)),
              const SizedBox(height: 12),
              const Text('مدیریت کلاس، فایل، تمرین و پیام‌ها در یک اپ', textAlign: TextAlign.center, style: TextStyle(color: kMuted, height: 1.7)),
              const SizedBox(height: 26),
              RoleButton(icon: '👩‍🏫', title: 'ورود معلم', subtitle: 'داشبورد، کلاس‌ها، فایل‌ها و تمرین‌ها', color: kPurple, onTap: onTeacher),
              const SizedBox(height: 14),
              RoleButton(icon: '🧒', title: 'ورود دانش‌آموز', subtitle: 'کلاس‌ها، فایل‌ها، تمرین و پیام به معلم', color: kBlue, onTap: onStudent),
            ]),
          ),
        ),
      ),
    ),
  );
}

class RoleButton extends StatelessWidget {
  const RoleButton({super.key, required this.icon, required this.title, required this.subtitle, required this.color, required this.onTap});
  final String icon, title, subtitle;
  final Color color;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => SoftCard(
    onTap: onTap,
    child: Row(children: [
      Container(width: 58, height: 58, decoration: BoxDecoration(color: color.withOpacity(.12), shape: BoxShape.circle), child: Center(child: Text(icon, style: const TextStyle(fontSize: 30)))),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)), const SizedBox(height: 4), Text(subtitle, style: const TextStyle(color: kMuted, fontSize: 13))])),
    ]),
  );
}

class TeacherLoginScreen extends StatefulWidget {
  const TeacherLoginScreen({super.key, required this.api, required this.onBack, required this.onLogin});
  final ApiClient api;
  final VoidCallback onBack;
  final void Function(String, UserData) onLogin;
  @override
  State<TeacherLoginScreen> createState() => _TeacherLoginScreenState();
}

class _TeacherLoginScreenState extends State<TeacherLoginScreen> {
  final password = TextEditingController();
  bool busy = false;
  @override
  void dispose() { password.dispose(); super.dispose(); }
  Future<void> submit() async {
    if (password.text.trim().isEmpty) { toast(context, 'رمز معلم را وارد کن.'); return; }
    setState(() => busy = true);
    try {
      final res = await widget.api.post('/api/auth/teacher-login', {'phone': fixedTeacherPhone, 'password': password.text.trim()});
      widget.onLogin(res['token'].toString(), UserData.fromJson(Map<String, dynamic>.from(res['user'])));
    } catch (e) { toast(context, e); } finally { if (mounted) setState(() => busy = false); }
  }
  @override
  Widget build(BuildContext context) => GradientScaffold(
    child: Center(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 460),
          child: SoftCard(
            padding: const EdgeInsets.all(22),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              HeaderRow(title: 'ورود معلم', onBack: widget.onBack),
              const CircleLogo('🔐', size: 94),
              const SizedBox(height: 20),
              const Text('پنل مدیریت', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
              const SizedBox(height: 18),
              TextField(controller: password, obscureText: true, textAlign: TextAlign.center, decoration: const InputDecoration(hintText: 'رمز معلم')),
              const SizedBox(height: 16),
              PrimaryButton(text: busy ? 'در حال ورود...' : 'ورود', onTap: busy ? null : submit, color: kPurple),
            ]),
          ),
        ),
      ),
    ),
  );
}

class StudentLoginScreen extends StatefulWidget {
  const StudentLoginScreen({super.key, required this.api, required this.onBack, required this.onLogin});
  final ApiClient api;
  final VoidCallback onBack;
  final void Function(String, UserData) onLogin;
  @override
  State<StudentLoginScreen> createState() => _StudentLoginScreenState();
}

class _StudentLoginScreenState extends State<StudentLoginScreen> {
  final name = TextEditingController();
  final phone = TextEditingController();
  String theme = 'girl';
  bool busy = false;
  @override
  void dispose() { name.dispose(); phone.dispose(); super.dispose(); }
  Future<void> submit() async {
    if (name.text.trim().isEmpty || phone.text.trim().isEmpty) { toast(context, 'نام دانش‌آموز و شماره والدین را وارد کن.'); return; }
    setState(() => busy = true);
    try {
      final res = await widget.api.post('/api/auth/student-login', {'name': name.text.trim(), 'phone': phone.text.trim(), 'parentPhone': phone.text.trim(), 'theme': theme});
      widget.onLogin(res['token'].toString(), UserData.fromJson(Map<String, dynamic>.from(res['user'])));
    } catch (e) { toast(context, e); } finally { if (mounted) setState(() => busy = false); }
  }
  @override
  Widget build(BuildContext context) => GradientScaffold(
    child: Center(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 460),
          child: SoftCard(
            padding: const EdgeInsets.all(22),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              HeaderRow(title: 'ورود دانش‌آموز', onBack: widget.onBack),
              CircleLogo(themeEmoji(theme), size: 94),
              const SizedBox(height: 18),
              const Text('سلام قهرمان کوچولو!', textAlign: TextAlign.center, style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
              const SizedBox(height: 16),
              TextField(controller: name, textAlign: TextAlign.right, decoration: const InputDecoration(hintText: 'نام دانش‌آموز')),
              const SizedBox(height: 12),
              TextField(controller: phone, keyboardType: TextInputType.phone, textDirection: TextDirection.ltr, decoration: const InputDecoration(hintText: 'شماره والدین')),
              const SizedBox(height: 14),
              Row(children: [Expanded(child: ThemeChoice(icon: '🚀', text: 'پسرونه', selected: theme == 'boy', color: kBlue, onTap: () => setState(() => theme = 'boy'))), const SizedBox(width: 10), Expanded(child: ThemeChoice(icon: '🌸', text: 'دخترونه', selected: theme == 'girl', color: kPink, onTap: () => setState(() => theme = 'girl')))]),
              const SizedBox(height: 16),
              PrimaryButton(text: busy ? 'در حال ورود...' : 'ورود به اپ', onTap: busy ? null : submit, color: themeColor(theme)),
            ]),
          ),
        ),
      ),
    ),
  );
}

class HeaderRow extends StatelessWidget {
  const HeaderRow({super.key, required this.title, required this.onBack});
  final String title;
  final VoidCallback onBack;
  @override
  Widget build(BuildContext context) => Row(children: [
    IconButton.filledTonal(onPressed: onBack, icon: const Icon(Icons.arrow_forward_rounded)),
    Expanded(child: Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20))),
    const SizedBox(width: 48),
  ]);
}

class ThemeChoice extends StatelessWidget {
  const ThemeChoice({super.key, required this.icon, required this.text, required this.selected, required this.color, required this.onTap});
  final String icon, text;
  final bool selected;
  final Color color;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => InkWell(
    borderRadius: BorderRadius.circular(22),
    onTap: onTap,
    child: Container(height: 92, decoration: BoxDecoration(color: selected ? color.withOpacity(.12) : Colors.white, border: Border.all(color: selected ? color : const Color(0x08000000), width: 2), borderRadius: BorderRadius.circular(22)), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(icon, style: const TextStyle(fontSize: 28)), const SizedBox(height: 5), Text(text, style: const TextStyle(fontWeight: FontWeight.w900))])),
  );
}

class AppShell extends StatelessWidget {
  const AppShell({super.key, required this.title, required this.index, required this.onChanged, required this.pages, required this.color});
  final String title;
  final int index;
  final void Function(int) onChanged;
  final List<Widget> pages;
  final Color color;
  @override
  Widget build(BuildContext context) => Scaffold(
    backgroundColor: Colors.transparent,
    body: Container(
      decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [color.withOpacity(.10), const Color(0xFFEFF8FF), kSoft])),
      child: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 520),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
              child: Column(children: [
                Row(children: [
                  CircleAvatar(backgroundColor: Colors.white, child: Text(index == 2 ? '🏠' : '✨')),
                  const SizedBox(width: 10),
                  Expanded(child: Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: kText))),
                ]),
                const SizedBox(height: 12),
                Expanded(child: IndexedStack(index: index, children: pages)),
              ]),
            ),
          ),
        ),
      ),
    ),
    bottomNavigationBar: Directionality(
      textDirection: TextDirection.rtl,
      child: BottomNavigationBar(
        currentIndex: index,
        type: BottomNavigationBarType.fixed,
        selectedItemColor: color,
        unselectedItemColor: kMuted,
        onTap: onChanged,
        selectedFontSize: 12,
        unselectedFontSize: 11,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.dashboard_rounded), label: 'داشبورد'),
          BottomNavigationBarItem(icon: Icon(Icons.school_rounded), label: 'کلاس‌ها'),
          BottomNavigationBarItem(icon: Icon(Icons.home_rounded, size: 31), label: 'خانه'),
          BottomNavigationBarItem(icon: Icon(Icons.folder_rounded), label: 'فایل‌ها'),
          BottomNavigationBarItem(icon: Icon(Icons.settings_rounded), label: 'تنظیمات'),
        ],
      ),
    ),
  );
}

class TeacherShell extends StatefulWidget {
  const TeacherShell({super.key, required this.api, required this.settings, required this.user, required this.onLogout, required this.reloadSettings});
  final ApiClient api;
  final AppSettings settings;
  final UserData user;
  final VoidCallback onLogout;
  final Future<void> Function() reloadSettings;
  @override
  State<TeacherShell> createState() => _TeacherShellState();
}

class _TeacherShellState extends State<TeacherShell> {
  int index = 2;
  bool loading = true;
  List<Course> courses = [];
  List<Enrollment> enrollments = [];
  List<LearningFile> files = [];
  List<Assignment> assignments = [];
  List<Submission> submissions = [];
  List<TeacherMessage> messages = [];

  @override
  void initState() { super.initState(); refresh(); }
  Future<void> refresh() async {
    setState(() => loading = true);
    try {
      final c = await widget.api.get('/api/courses');
      final e = await widget.api.get('/api/enrollments');
      final m = await widget.api.get('/api/materials');
      final a = await widget.api.get('/api/assignments');
      final s = await widget.api.get('/api/submissions');
      final msg = await widget.api.get('/api/messages');
      courses = (c as List).map((x) => Course.fromJson(Map<String, dynamic>.from(x))).toList();
      enrollments = (e as List).map((x) => Enrollment.fromJson(Map<String, dynamic>.from(x))).toList();
      files = (m as List).map((x) => LearningFile.fromJson(Map<String, dynamic>.from(x))).toList();
      assignments = (a as List).map((x) => Assignment.fromJson(Map<String, dynamic>.from(x))).toList();
      submissions = (s as List).map((x) => Submission.fromJson(Map<String, dynamic>.from(x))).toList();
      messages = (msg as List).map((x) => TeacherMessage.fromJson(Map<String, dynamic>.from(x))).toList();
    } catch (e) { if (mounted) toast(context, e); }
    finally { if (mounted) setState(() => loading = false); }
  }

  @override
  Widget build(BuildContext context) => AppShell(
    title: ['داشبورد معلم', 'کلاس‌ها', 'خانه معلم', 'فایل‌ها', 'تنظیمات'][index],
    index: index,
    color: kPurple,
    onChanged: (i) => setState(() => index = i),
    pages: [
      LoadingWrap(loading: loading, child: TeacherDashboardPage(enrollments: enrollments, submissions: submissions, messages: messages, onRefresh: refresh, api: widget.api)),
      LoadingWrap(loading: loading, child: TeacherClassesPage(api: widget.api, courses: courses, assignments: assignments, onRefresh: refresh)),
      LoadingWrap(loading: loading, child: TeacherHomePage(settings: widget.settings, courses: courses, files: files, enrollments: enrollments, assignments: assignments, onLogout: widget.onLogout, onAddCourse: () => showCourseDialog(context, widget.api, null, refresh), onAddFile: () => showFileDialog(context, widget.api, courses, null, refresh), onAddAssignment: () => showAssignmentDialog(context, widget.api, courses, null, refresh), onMessagePage: () => setState(() => index = 0))),
      LoadingWrap(loading: loading, child: TeacherFilesPage(api: widget.api, courses: courses, files: files, onRefresh: refresh)),
      TeacherSettingsPage(api: widget.api, settings: widget.settings, onSaved: () async { await widget.reloadSettings(); if (mounted) toast(context, 'تنظیمات ذخیره شد.'); }, onLogout: widget.onLogout),
    ],
  );
}

class StudentShell extends StatefulWidget {
  const StudentShell({super.key, required this.api, required this.settings, required this.user, required this.onLogout});
  final ApiClient api;
  final AppSettings settings;
  final UserData user;
  final VoidCallback onLogout;
  @override
  State<StudentShell> createState() => _StudentShellState();
}

class _StudentShellState extends State<StudentShell> {
  int index = 2;
  bool loading = true;
  List<Course> courses = [];
  List<Enrollment> enrollments = [];
  List<LearningFile> files = [];
  List<Assignment> assignments = [];
  List<TeacherMessage> messages = [];
  Color get color => themeColor(widget.user.theme);
  @override
  void initState() { super.initState(); refresh(); }
  Future<void> refresh() async {
    setState(() => loading = true);
    try {
      final c = await widget.api.get('/api/courses');
      final e = await widget.api.get('/api/enrollments');
      final m = await widget.api.get('/api/materials');
      final a = await widget.api.get('/api/assignments');
      final msg = await widget.api.get('/api/messages');
      courses = (c as List).map((x) => Course.fromJson(Map<String, dynamic>.from(x))).where((x) => x.isActive).toList();
      enrollments = (e as List).map((x) => Enrollment.fromJson(Map<String, dynamic>.from(x))).toList();
      files = (m as List).map((x) => LearningFile.fromJson(Map<String, dynamic>.from(x))).toList();
      assignments = (a as List).map((x) => Assignment.fromJson(Map<String, dynamic>.from(x))).toList();
      messages = (msg as List).map((x) => TeacherMessage.fromJson(Map<String, dynamic>.from(x))).toList();
    } catch (e) { if (mounted) toast(context, e); }
    finally { if (mounted) setState(() => loading = false); }
  }
  Enrollment? enrollmentFor(String courseId) {
    for (final e in enrollments) { if (e.course?.id == courseId) return e; }
    return null;
  }

  @override
  Widget build(BuildContext context) => AppShell(
    title: ['تمرین‌ها و پیام‌ها', 'کلاس‌های من', 'خانه دانش‌آموز', 'فایل‌ها', 'تنظیمات'][index],
    index: index,
    color: color,
    onChanged: (i) => setState(() => index = i),
    pages: [
      LoadingWrap(loading: loading, child: StudentDashboardPage(api: widget.api, theme: widget.user.theme, assignments: assignments, messages: messages, onRefresh: refresh)),
      LoadingWrap(loading: loading, child: StudentClassesPage(api: widget.api, settings: widget.settings, theme: widget.user.theme, courses: courses, enrollments: enrollments, onRefresh: refresh)),
      LoadingWrap(loading: loading, child: StudentHomePage(user: widget.user, settings: widget.settings, courses: courses, files: files, assignments: assignments, color: color, onClasses: () => setState(() => index = 1), onFiles: () => setState(() => index = 3), onAssignments: () => setState(() => index = 0), onMessage: () => showMessageDialog(context, widget.api, refresh))),
      LoadingWrap(loading: loading, child: StudentFilesPage(files: files, theme: widget.user.theme)),
      StudentSettingsPage(user: widget.user, settings: widget.settings, messages: messages, color: color, onLogout: widget.onLogout, onMessage: () => showMessageDialog(context, widget.api, refresh)),
    ],
  );
}

class LoadingWrap extends StatelessWidget {
  const LoadingWrap({super.key, required this.loading, required this.child});
  final bool loading;
  final Widget child;
  @override
  Widget build(BuildContext context) => loading ? const Center(child: CircularProgressIndicator()) : child;
}

class FixedPage extends StatelessWidget {
  const FixedPage({super.key, required this.children, this.footer});
  final List<Widget> children;
  final Widget? footer;
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    ...children,
    if (footer != null) footer!,
  ]);
}

class PageList extends StatelessWidget {
  const PageList({super.key, required this.children, this.emptyText = 'موردی وجود ندارد.'});
  final List<Widget> children;
  final String emptyText;
  @override
  Widget build(BuildContext context) => Expanded(child: children.isEmpty ? Center(child: Text(emptyText, style: const TextStyle(color: kMuted))) : ListView.separated(padding: const EdgeInsets.only(bottom: 12), itemCount: children.length, separatorBuilder: (_, __) => const SizedBox(height: 10), itemBuilder: (_, i) => children[i]));
}

class StatBox extends StatelessWidget {
  const StatBox({super.key, required this.icon, required this.value, required this.label, this.color = kPurple});
  final String icon, value, label;
  final Color color;
  @override
  Widget build(BuildContext context) => Expanded(child: SoftCard(padding: const EdgeInsets.all(12), child: Column(children: [Text(icon, style: const TextStyle(fontSize: 26)), const SizedBox(height: 4), Text(value, style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900, color: color)), Text(label, style: const TextStyle(color: kMuted, fontSize: 12))])));
}

class TeacherHomePage extends StatelessWidget {
  const TeacherHomePage({super.key, required this.settings, required this.courses, required this.files, required this.enrollments, required this.assignments, required this.onLogout, required this.onAddCourse, required this.onAddFile, required this.onAddAssignment, required this.onMessagePage});
  final AppSettings settings;
  final List<Course> courses;
  final List<LearningFile> files;
  final List<Enrollment> enrollments;
  final List<Assignment> assignments;
  final VoidCallback onLogout, onAddCourse, onAddFile, onAddAssignment, onMessagePage;
  @override
  Widget build(BuildContext context) => FixedPage(children: [
    SoftCard(child: Row(children: [const CircleLogo('👩‍🏫', size: 70), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(settings.teacherName, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)), const Text('همه چیز از صفحه‌های جدا مدیریت می‌شود.', style: TextStyle(color: kMuted))]))])),
    const SizedBox(height: 10),
    Row(children: [StatBox(icon: '📚', value: courses.length.toString(), label: 'کلاس'), const SizedBox(width: 10), StatBox(icon: '📁', value: files.length.toString(), label: 'فایل'), const SizedBox(width: 10), StatBox(icon: '📝', value: assignments.length.toString(), label: 'تمرین')]),
    const SizedBox(height: 10),
    Expanded(child: GridView.count(crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.25, physics: const NeverScrollableScrollPhysics(), children: [
      HomeAction(icon: '➕', title: 'کلاس جدید', color: kPurple, onTap: onAddCourse),
      HomeAction(icon: '📁', title: 'فایل جدید', color: kBlue, onTap: onAddFile),
      HomeAction(icon: '📝', title: 'تمرین جدید', color: kOrange, onTap: onAddAssignment),
      HomeAction(icon: '💬', title: 'پیام‌ها', color: kGreen, onTap: onMessagePage),
    ])),
    PrimaryButton(text: 'خروج از حساب معلم', onTap: onLogout, color: const Color(0xFFE53935), height: 48),
  ]);
}

class HomeAction extends StatelessWidget {
  const HomeAction({super.key, required this.icon, required this.title, required this.color, required this.onTap});
  final String icon, title;
  final Color color;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => SoftCard(onTap: onTap, padding: const EdgeInsets.all(12), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Container(width: 50, height: 50, decoration: BoxDecoration(color: color.withOpacity(.12), shape: BoxShape.circle), child: Center(child: Text(icon, style: const TextStyle(fontSize: 26)))), const SizedBox(height: 8), Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900))]));
}

class TeacherDashboardPage extends StatelessWidget {
  const TeacherDashboardPage({super.key, required this.enrollments, required this.submissions, required this.messages, required this.onRefresh, required this.api});
  final List<Enrollment> enrollments;
  final List<Submission> submissions;
  final List<TeacherMessage> messages;
  final Future<void> Function() onRefresh;
  final ApiClient api;
  Future<void> status(BuildContext context, Enrollment e, String s) async { try { await api.patch('/api/enrollments/${e.id}/status', {'status': s, 'rejectReason': s == 'rejected' ? 'رسید تایید نشد' : ''}); await onRefresh(); } catch (err) { if (context.mounted) toast(context, err); } }
  @override
  Widget build(BuildContext context) {
    final pending = enrollments.where((e) => e.status == 'pending').toList();
    final latest = <Widget>[
      ...pending.map((e) => EnrollmentCard(e: e, onApprove: () => status(context, e, 'approved'), onReject: () => status(context, e, 'rejected'))),
      ...submissions.map((s) => SubmissionCard(submission: s, teacher: true)),
      ...messages.map((m) => MessageCard(message: m, teacher: true, api: api, onRefresh: onRefresh)),
    ];
    return FixedPage(children: [
      Row(children: [StatBox(icon: '🧾', value: pending.length.toString(), label: 'رسید جدید'), const SizedBox(width: 10), StatBox(icon: '📸', value: submissions.length.toString(), label: 'تمرین ارسالی'), const SizedBox(width: 10), StatBox(icon: '💬', value: messages.where((m) => !m.isRead).length.toString(), label: 'پیام جدید')]),
      const SizedBox(height: 12),
      const Text('آخرین موارد', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      PageList(children: latest, emptyText: 'فعلاً رسید، تمرین یا پیام جدیدی وجود ندارد.'),
    ]);
  }
}

class TeacherClassesPage extends StatelessWidget {
  const TeacherClassesPage({super.key, required this.api, required this.courses, required this.assignments, required this.onRefresh});
  final ApiClient api;
  final List<Course> courses;
  final List<Assignment> assignments;
  final Future<void> Function() onRefresh;
  Future<void> delete(BuildContext context, Course c) async { try { await api.delete('/api/courses/${c.id}'); await onRefresh(); } catch (e) { if (context.mounted) toast(context, e); } }
  @override
  Widget build(BuildContext context) => FixedPage(children: [
    Row(children: [Expanded(child: PrimaryButton(text: '+ کلاس جدید', onTap: () => showCourseDialog(context, api, null, onRefresh), color: kPurple)), const SizedBox(width: 10), Expanded(child: PrimaryButton(text: '+ تمرین', onTap: () => showAssignmentDialog(context, api, courses, null, onRefresh), color: kOrange))]),
    const SizedBox(height: 10),
    PageList(children: courses.map((c) => CourseCard(course: c, trailing: PopupMenuButton<String>(onSelected: (v) { if (v == 'edit') showCourseDialog(context, api, c, onRefresh); if (v == 'delete') delete(context, c); if (v == 'assignment') showAssignmentDialog(context, api, courses, c.id, onRefresh); }, itemBuilder: (_) => const [PopupMenuItem(value: 'edit', child: Text('ویرایش')), PopupMenuItem(value: 'assignment', child: Text('تمرین برای این کلاس')), PopupMenuItem(value: 'delete', child: Text('حذف'))]))).toList(), emptyText: 'هنوز کلاسی ساخته نشده است.'),
  ]);
}

class TeacherFilesPage extends StatelessWidget {
  const TeacherFilesPage({super.key, required this.api, required this.courses, required this.files, required this.onRefresh});
  final ApiClient api;
  final List<Course> courses;
  final List<LearningFile> files;
  final Future<void> Function() onRefresh;
  Future<void> delete(BuildContext context, LearningFile f) async { try { await api.delete('/api/materials/${f.id}'); await onRefresh(); } catch (e) { if (context.mounted) toast(context, e); } }
  @override
  Widget build(BuildContext context) => FixedPage(children: [
    PrimaryButton(text: '+ فایل جدید', onTap: () => showFileDialog(context, api, courses, null, onRefresh), color: kBlue),
    const SizedBox(height: 10),
    PageList(children: files.map((f) => FileCard(file: f, onOpen: () => openFileViewer(context, f), trailing: IconButton(onPressed: () => delete(context, f), icon: const Icon(Icons.delete_outline_rounded)))).toList(), emptyText: 'هنوز فایلی ثبت نشده است.'),
  ]);
}

class TeacherSettingsPage extends StatefulWidget {
  const TeacherSettingsPage({super.key, required this.api, required this.settings, required this.onSaved, required this.onLogout});
  final ApiClient api;
  final AppSettings settings;
  final Future<void> Function() onSaved;
  final VoidCallback onLogout;
  @override
  State<TeacherSettingsPage> createState() => _TeacherSettingsPageState();
}

class _TeacherSettingsPageState extends State<TeacherSettingsPage> {
  late final TextEditingController appTitle, teacherName, cardNumber, cardOwner, supportPhone, paymentHelp;
  bool busy = false;
  @override
  void initState() { super.initState(); final s = widget.settings; appTitle = TextEditingController(text: s.appTitle); teacherName = TextEditingController(text: s.teacherName); cardNumber = TextEditingController(text: s.cardNumber); cardOwner = TextEditingController(text: s.cardOwner); supportPhone = TextEditingController(text: s.supportPhone); paymentHelp = TextEditingController(text: s.paymentHelp); }
  @override
  void dispose() { appTitle.dispose(); teacherName.dispose(); cardNumber.dispose(); cardOwner.dispose(); supportPhone.dispose(); paymentHelp.dispose(); super.dispose(); }
  Future<void> save() async {
    setState(() => busy = true);
    try { await widget.api.put('/api/settings', {'appTitle': appTitle.text, 'teacherName': teacherName.text, 'cardNumber': cardNumber.text, 'cardOwner': cardOwner.text, 'supportPhone': supportPhone.text, 'paymentHelp': paymentHelp.text}); await widget.onSaved(); } catch (e) { if (mounted) toast(context, e); } finally { if (mounted) setState(() => busy = false); }
  }
  @override
  Widget build(BuildContext context) => FixedPage(children: [
    Expanded(child: Column(children: [
      TextField(controller: appTitle, decoration: const InputDecoration(labelText: 'عنوان اپ')),
      const SizedBox(height: 8),
      TextField(controller: teacherName, decoration: const InputDecoration(labelText: 'نام معلم')),
      const SizedBox(height: 8),
      TextField(controller: cardNumber, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'شماره کارت')),
      const SizedBox(height: 8),
      TextField(controller: cardOwner, decoration: const InputDecoration(labelText: 'نام صاحب کارت')),
      const SizedBox(height: 8),
      TextField(controller: supportPhone, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'شماره پشتیبانی')),
      const SizedBox(height: 8),
      TextField(controller: paymentHelp, maxLines: 2, decoration: const InputDecoration(labelText: 'متن راهنمای پرداخت')),
    ])),
    PrimaryButton(text: busy ? 'در حال ذخیره...' : 'ذخیره تنظیمات', onTap: busy ? null : save, color: kGreen),
    const SizedBox(height: 8),
    PrimaryButton(text: 'خروج', onTap: widget.onLogout, color: const Color(0xFFE53935), height: 48),
  ]);
}

class StudentHomePage extends StatelessWidget {
  const StudentHomePage({super.key, required this.user, required this.settings, required this.courses, required this.files, required this.assignments, required this.color, required this.onClasses, required this.onFiles, required this.onAssignments, required this.onMessage});
  final UserData user;
  final AppSettings settings;
  final List<Course> courses;
  final List<LearningFile> files;
  final List<Assignment> assignments;
  final Color color;
  final VoidCallback onClasses, onFiles, onAssignments, onMessage;
  @override
  Widget build(BuildContext context) => FixedPage(children: [
    SoftCard(child: Row(children: [CircleLogo(themeEmoji(user.theme), size: 72), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('سلام ${user.name}', style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900)), Text('معلم: ${settings.teacherName}', style: const TextStyle(color: kMuted))]))])),
    const SizedBox(height: 10),
    Row(children: [StatBox(icon: '📚', value: courses.length.toString(), label: 'کلاس', color: color), const SizedBox(width: 10), StatBox(icon: '📁', value: files.length.toString(), label: 'فایل', color: color), const SizedBox(width: 10), StatBox(icon: '📝', value: assignments.length.toString(), label: 'تمرین', color: color)]),
    const SizedBox(height: 10),
    Expanded(child: GridView.count(crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 1.25, physics: const NeverScrollableScrollPhysics(), children: [
      HomeAction(icon: '📚', title: 'کلاس‌ها', color: color, onTap: onClasses),
      HomeAction(icon: '📁', title: 'فایل‌ها', color: kBlue, onTap: onFiles),
      HomeAction(icon: '📝', title: 'تمرین‌ها', color: kOrange, onTap: onAssignments),
      HomeAction(icon: '💬', title: 'پیام به معلم', color: kGreen, onTap: onMessage),
    ])),
    PaymentBox(settings: settings),
  ]);
}

class StudentDashboardPage extends StatelessWidget {
  const StudentDashboardPage({super.key, required this.api, required this.theme, required this.assignments, required this.messages, required this.onRefresh});
  final ApiClient api;
  final String theme;
  final List<Assignment> assignments;
  final List<TeacherMessage> messages;
  final Future<void> Function() onRefresh;
  @override
  Widget build(BuildContext context) => FixedPage(children: [
    Row(children: [Expanded(child: PrimaryButton(text: 'پیام به معلم', onTap: () => showMessageDialog(context, api, onRefresh), color: themeColor(theme))), const SizedBox(width: 10), Expanded(child: PrimaryButton(text: 'ارسال تمرین', onTap: assignments.isEmpty ? null : () => showSubmitDialog(context, api, assignments.first, onRefresh), color: kOrange))]),
    const SizedBox(height: 10),
    const Text('تمرین‌های من', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
    const SizedBox(height: 8),
    PageList(children: [
      ...assignments.map((a) => AssignmentCard(assignment: a, color: themeColor(theme), onSubmit: () => showSubmitDialog(context, api, a, onRefresh))),
      ...messages.map((m) => MessageCard(message: m, teacher: false)),
    ], emptyText: 'فعلاً تمرین یا پیامی ثبت نشده است.'),
  ]);
}

class StudentClassesPage extends StatelessWidget {
  const StudentClassesPage({super.key, required this.api, required this.settings, required this.theme, required this.courses, required this.enrollments, required this.onRefresh});
  final ApiClient api;
  final AppSettings settings;
  final String theme;
  final List<Course> courses;
  final List<Enrollment> enrollments;
  final Future<void> Function() onRefresh;
  Enrollment? enrollmentFor(String id) { for (final e in enrollments) { if (e.course?.id == id) return e; } return null; }
  @override
  Widget build(BuildContext context) => FixedPage(children: [
    PageList(children: courses.map((c) => StudentCourseCard(course: c, settings: settings, color: themeColor(theme), enrollment: enrollmentFor(c.id), onEnroll: () => showEnrollDialog(context, api, c, settings, onRefresh))).toList(), emptyText: 'هنوز کلاسی فعال نیست.'),
  ]);
}

class StudentFilesPage extends StatelessWidget {
  const StudentFilesPage({super.key, required this.files, required this.theme});
  final List<LearningFile> files;
  final String theme;
  @override
  Widget build(BuildContext context) => FixedPage(children: [
    PageList(children: files.map((f) => FileCard(file: f, onOpen: () => openFileViewer(context, f))).toList(), emptyText: 'فعلاً فایلی برای شما فعال نیست.'),
  ]);
}

class StudentSettingsPage extends StatelessWidget {
  const StudentSettingsPage({super.key, required this.user, required this.settings, required this.messages, required this.color, required this.onLogout, required this.onMessage});
  final UserData user;
  final AppSettings settings;
  final List<TeacherMessage> messages;
  final Color color;
  final VoidCallback onLogout, onMessage;
  @override
  Widget build(BuildContext context) => FixedPage(children: [
    SoftCard(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('نام: ${user.name}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)), const SizedBox(height: 6), Text('شماره والدین: ${user.parentPhone}', style: const TextStyle(color: kMuted)), Text('پشتیبانی: ${settings.supportPhone}', style: const TextStyle(color: kMuted))])),
    const SizedBox(height: 10),
    PrimaryButton(text: 'پیام دادن به معلم', onTap: onMessage, color: color),
    const SizedBox(height: 10),
    const Text('پیام‌های اخیر', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
    const SizedBox(height: 8),
    PageList(children: messages.take(5).map((m) => MessageCard(message: m, teacher: false)).toList(), emptyText: 'پیامی ثبت نشده است.'),
    PrimaryButton(text: 'خروج از حساب', onTap: onLogout, color: const Color(0xFFE53935), height: 48),
  ]);
}

class CourseCard extends StatelessWidget {
  const CourseCard({super.key, required this.course, this.trailing});
  final Course course;
  final Widget? trailing;
  @override
  Widget build(BuildContext context) => SoftCard(child: Row(children: [
    Container(width: 52, height: 52, decoration: BoxDecoration(color: (course.type == 'online' ? kPurple : kGreen).withOpacity(.12), shape: BoxShape.circle), child: Center(child: Text(course.type == 'online' ? '🎥' : '🎬', style: const TextStyle(fontSize: 26)))),
    const SizedBox(width: 10),
    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(course.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)), const SizedBox(height: 4), Text('${course.subject} • ${course.grade}', style: const TextStyle(color: kMuted)), const SizedBox(height: 6), Wrap(spacing: 6, runSpacing: 5, children: [TinyPill(money(course.price)), TinyPill(course.schedule.isEmpty ? 'بدون زمان' : course.schedule, color: kBlue), TinyPill(course.isActive ? 'فعال' : 'غیرفعال', color: course.isActive ? kGreen : kMuted)])])),
    if (trailing != null) trailing!,
  ]));
}

class StudentCourseCard extends StatelessWidget {
  const StudentCourseCard({super.key, required this.course, required this.settings, required this.color, required this.enrollment, required this.onEnroll});
  final Course course;
  final AppSettings settings;
  final Color color;
  final Enrollment? enrollment;
  final VoidCallback onEnroll;
  @override
  Widget build(BuildContext context) {
    final status = enrollment?.status;
    return SoftCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      CourseCard(course: course),
      const SizedBox(height: 10),
      if (course.description.isNotEmpty) Text(course.description, textAlign: TextAlign.center, style: const TextStyle(color: kMuted, height: 1.5)),
      const SizedBox(height: 8),
      if (status != null) Center(child: TinyPill(statusText(status), color: status == 'approved' ? kGreen : status == 'rejected' ? Colors.red : kOrange)),
      if (status == 'approved' && course.accessLink.isNotEmpty) TextButton.icon(onPressed: () { Clipboard.setData(ClipboardData(text: course.accessLink)); toast(context, 'لینک کلاس کپی شد.'); }, icon: const Icon(Icons.copy_rounded), label: const Text('کپی لینک ورود به کلاس')),
      const SizedBox(height: 6),
      PrimaryButton(text: status == 'pending' ? 'در انتظار تایید' : status == 'approved' ? 'ثبت‌نام تایید شده' : status == 'rejected' ? 'ارسال دوباره رسید' : 'ثبت‌نام در کلاس', onTap: status == 'pending' || status == 'approved' ? null : onEnroll, color: color, height: 48),
    ]));
  }
}

class FileCard extends StatelessWidget {
  const FileCard({super.key, required this.file, required this.onOpen, this.trailing});
  final LearningFile file;
  final VoidCallback onOpen;
  final Widget? trailing;
  @override
  Widget build(BuildContext context) => SoftCard(onTap: onOpen, child: Row(children: [
    Container(width: 52, height: 52, decoration: BoxDecoration(color: kBlue.withOpacity(.12), shape: BoxShape.circle), child: Center(child: Text(typeIcon(file.type), style: const TextStyle(fontSize: 26)))),
    const SizedBox(width: 10),
    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(file.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)), const SizedBox(height: 4), Text(file.courseTitle.isEmpty ? 'فایل عمومی' : file.courseTitle, style: const TextStyle(color: kMuted)), if (file.description.isNotEmpty) Text(file.description, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: kMuted, fontSize: 12))])),
    TinyPill(typeLabel(file.type), color: kBlue),
    if (trailing != null) trailing!,
  ]));
}

class EnrollmentCard extends StatelessWidget {
  const EnrollmentCard({super.key, required this.e, required this.onApprove, required this.onReject});
  final Enrollment e;
  final VoidCallback onApprove, onReject;
  @override
  Widget build(BuildContext context) => SoftCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    Text('${e.student?.name ?? 'دانش‌آموز'} • ${e.course?.title ?? 'کلاس'}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
    if (e.receiptText.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text(e.receiptText, style: const TextStyle(color: kMuted))),
    if (e.receiptFileUrl.isNotEmpty) TextButton(onPressed: () => openFileViewer(context, LearningFile(id: '', title: 'رسید پرداخت', type: guessType(e.receiptFileUrl), url: e.receiptFileUrl, description: '', courseId: '', courseTitle: '', isActive: true)), child: const Text('مشاهده عکس/فایل رسید')),
    const SizedBox(height: 8),
    Row(children: [Expanded(child: PrimaryButton(text: 'تایید', onTap: onApprove, color: kGreen, height: 44)), const SizedBox(width: 8), Expanded(child: PrimaryButton(text: 'رد', onTap: onReject, color: Colors.red, height: 44))]),
  ]));
}

class AssignmentCard extends StatelessWidget {
  const AssignmentCard({super.key, required this.assignment, required this.color, required this.onSubmit});
  final Assignment assignment;
  final Color color;
  final VoidCallback onSubmit;
  @override
  Widget build(BuildContext context) => SoftCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    Row(children: [Container(width: 50, height: 50, decoration: BoxDecoration(color: kOrange.withOpacity(.13), shape: BoxShape.circle), child: const Center(child: Text('📝', style: TextStyle(fontSize: 26)))), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(assignment.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)), Text(assignment.courseTitle, style: const TextStyle(color: kMuted))]))]),
    if (assignment.description.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text(assignment.description, style: const TextStyle(color: kMuted, height: 1.5))),
    if (assignment.dueDate.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: TinyPill('مهلت: ${assignment.dueDate}', color: kOrange)),
    const SizedBox(height: 8),
    if (assignment.submission != null) TinyPill('تمرین ارسال شده', color: kGreen) else PrimaryButton(text: 'ارسال پاسخ تمرین', onTap: onSubmit, color: color, height: 46),
  ]));
}

class SubmissionCard extends StatelessWidget {
  const SubmissionCard({super.key, required this.submission, required this.teacher});
  final Submission submission;
  final bool teacher;
  @override
  Widget build(BuildContext context) => SoftCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    Text(teacher ? '${submission.student?.name ?? 'دانش‌آموز'} • ${submission.assignment?.title ?? 'تمرین'}' : (submission.assignment?.title ?? 'تمرین ارسال شده'), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
    if (submission.answerText.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text(submission.answerText, style: const TextStyle(color: kMuted, height: 1.5))),
    if (submission.imageUrl.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.network(submission.imageUrl, height: 150, fit: BoxFit.cover, errorBuilder: (_, __, ___) => TextButton(onPressed: () => openFileViewer(context, LearningFile(id: '', title: 'عکس تمرین', type: guessType(submission.imageUrl), url: submission.imageUrl, description: '', courseId: '', courseTitle: '', isActive: true)), child: const Text('مشاهده عکس تمرین'))))),
  ]));
}

class MessageCard extends StatelessWidget {
  const MessageCard({super.key, required this.message, required this.teacher, this.api, this.onRefresh});
  final TeacherMessage message;
  final bool teacher;
  final ApiClient? api;
  final Future<void> Function()? onRefresh;
  Future<void> reply(BuildContext context) async {
    final c = TextEditingController(text: message.reply);
    final text = await showTextInputDialog(context, title: 'پاسخ به پیام', controller: c, hint: 'پاسخ معلم');
    if (text == null || api == null) return;
    try { await api!.patch('/api/messages/${message.id}', {'reply': text, 'isRead': true}); if (onRefresh != null) await onRefresh!(); } catch (e) { if (context.mounted) toast(context, e); }
  }
  @override
  Widget build(BuildContext context) => SoftCard(child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
    Text(teacher ? 'پیام از ${message.student?.name ?? 'دانش‌آموز'}' : 'پیام به معلم', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
    const SizedBox(height: 6),
    Text(message.message, style: const TextStyle(color: kMuted, height: 1.5)),
    if (message.reply.isNotEmpty) ...[const Divider(), Text('پاسخ معلم: ${message.reply}', style: const TextStyle(color: kGreen, height: 1.5, fontWeight: FontWeight.bold))],
    if (teacher) Align(alignment: Alignment.centerLeft, child: TextButton.icon(onPressed: () => reply(context), icon: const Icon(Icons.reply_rounded), label: const Text('پاسخ'))),
  ]));
}

class PaymentBox extends StatelessWidget {
  const PaymentBox({super.key, required this.settings});
  final AppSettings settings;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(gradient: const LinearGradient(colors: [kPurple, kPink]), borderRadius: BorderRadius.circular(22)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const Text('💳 پرداخت کارت‌به‌کارت', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
      const SizedBox(height: 6),
      Directionality(textDirection: TextDirection.ltr, child: Text(settings.cardNumber, textAlign: TextAlign.right, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 1.2))),
      Text('به نام: ${settings.cardOwner}', style: const TextStyle(color: Colors.white)),
    ]),
  );
}

Future<void> showCourseDialog(BuildContext context, ApiClient api, Course? course, Future<void> Function() refresh) async {
  final title = TextEditingController(text: course?.title ?? '');
  final subject = TextEditingController(text: course?.subject ?? '');
  final grade = TextEditingController(text: course?.grade ?? '');
  final price = TextEditingController(text: course?.price.toString() ?? '');
  final schedule = TextEditingController(text: course?.schedule ?? '');
  final link = TextEditingController(text: course?.accessLink ?? '');
  final description = TextEditingController(text: course?.description ?? '');
  String type = course?.type ?? 'online';
  bool active = course?.isActive ?? true;
  await showAppDialog(context, titleText: course == null ? 'کلاس جدید' : 'ویرایش کلاس', builder: (setState) => [
    TextField(controller: title, decoration: const InputDecoration(labelText: 'عنوان کلاس')),
    const SizedBox(height: 8), TextField(controller: subject, decoration: const InputDecoration(labelText: 'درس')),
    const SizedBox(height: 8), TextField(controller: grade, decoration: const InputDecoration(labelText: 'پایه')),
    const SizedBox(height: 8), TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'قیمت')),
    const SizedBox(height: 8), TextField(controller: schedule, decoration: const InputDecoration(labelText: 'زمان کلاس')),
    const SizedBox(height: 8), TextField(controller: link, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'لینک کلاس آنلاین / فایل آفلاین')),
    const SizedBox(height: 8), TextField(controller: description, maxLines: 2, decoration: const InputDecoration(labelText: 'توضیحات')),
    const SizedBox(height: 8), Row(children: [Expanded(child: RadioListTile<String>(value: 'online', groupValue: type, onChanged: (v) => setState(() => type = v!), title: const Text('آنلاین'))), Expanded(child: RadioListTile<String>(value: 'offline', groupValue: type, onChanged: (v) => setState(() => type = v!), title: const Text('آفلاین')))]),
    SwitchListTile(value: active, onChanged: (v) => setState(() => active = v), title: const Text('کلاس فعال باشد')),
  ], onSave: () async {
    final data = {'title': title.text, 'subject': subject.text, 'grade': grade.text, 'price': price.text, 'schedule': schedule.text, 'type': type, 'accessLink': link.text, 'description': description.text, 'isActive': active};
    if (course == null) { await api.post('/api/courses', data); } else { await api.put('/api/courses/${course.id}', data); }
    await refresh();
  });
}

Future<void> showFileDialog(BuildContext context, ApiClient api, List<Course> courses, LearningFile? file, Future<void> Function() refresh) async {
  final title = TextEditingController(text: file?.title ?? '');
  final url = TextEditingController(text: file?.url ?? '');
  final description = TextEditingController(text: file?.description ?? '');
  String type = file?.type ?? 'pdf';
  String courseId = file?.courseId ?? '';
  await showAppDialog(context, titleText: 'فایل جدید', builder: (setState) => [
    TextField(controller: title, decoration: const InputDecoration(labelText: 'عنوان فایل')),
    const SizedBox(height: 8), TextField(controller: url, textDirection: TextDirection.ltr, decoration: const InputDecoration(labelText: 'لینک مستقیم فایل')),
    const SizedBox(height: 8), DropdownButtonFormField<String>(value: type, items: const [DropdownMenuItem(value: 'pdf', child: Text('PDF')), DropdownMenuItem(value: 'word', child: Text('Word')), DropdownMenuItem(value: 'image', child: Text('عکس')), DropdownMenuItem(value: 'video', child: Text('ویدئو')), DropdownMenuItem(value: 'link', child: Text('لینک'))], onChanged: (v) => setState(() => type = v ?? 'link'), decoration: const InputDecoration(labelText: 'نوع فایل')),
    const SizedBox(height: 8), DropdownButtonFormField<String>(value: courseId, items: [const DropdownMenuItem(value: '', child: Text('عمومی برای همه')), ...courses.map((c) => DropdownMenuItem(value: c.id, child: Text(c.title)))], onChanged: (v) => setState(() => courseId = v ?? ''), decoration: const InputDecoration(labelText: 'مربوط به کلاس')),
    const SizedBox(height: 8), TextField(controller: description, maxLines: 2, decoration: const InputDecoration(labelText: 'توضیحات')),
  ], onSave: () async { await api.post('/api/materials', {'title': title.text, 'url': url.text, 'type': type, 'courseId': courseId.isEmpty ? null : courseId, 'description': description.text, 'isActive': true}); await refresh(); });
}

Future<void> showAssignmentDialog(BuildContext context, ApiClient api, List<Course> courses, String? selectedCourseId, Future<void> Function() refresh) async {
  final title = TextEditingController();
  final description = TextEditingController();
  final dueDate = TextEditingController();
  String courseId = selectedCourseId ?? (courses.isNotEmpty ? courses.first.id : '');
  await showAppDialog(context, titleText: 'تمرین جدید', builder: (setState) => [
    DropdownButtonFormField<String>(value: courseId.isEmpty ? null : courseId, items: courses.map((c) => DropdownMenuItem(value: c.id, child: Text(c.title))).toList(), onChanged: (v) => setState(() => courseId = v ?? ''), decoration: const InputDecoration(labelText: 'کلاس')),
    const SizedBox(height: 8), TextField(controller: title, decoration: const InputDecoration(labelText: 'عنوان تمرین')),
    const SizedBox(height: 8), TextField(controller: dueDate, decoration: const InputDecoration(labelText: 'مهلت ارسال')),
    const SizedBox(height: 8), TextField(controller: description, maxLines: 3, decoration: const InputDecoration(labelText: 'توضیح تمرین')),
  ], onSave: () async { await api.post('/api/assignments', {'courseId': courseId, 'title': title.text, 'description': description.text, 'dueDate': dueDate.text, 'isActive': true}); await refresh(); });
}

Future<void> showSubmitDialog(BuildContext context, ApiClient api, Assignment assignment, Future<void> Function() refresh) async {
  final answer = TextEditingController();
  String imageUrl = assignment.submission?.imageUrl ?? '';
  String imageName = imageUrl.isEmpty ? '' : 'عکس انتخاب شده';
  bool uploading = false;

  await showAppDialog(context, titleText: 'ارسال تمرین', builder: (setState) => [
    Text(assignment.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
    if (assignment.description.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6, bottom: 8), child: Text(assignment.description, style: const TextStyle(color: kMuted))),
    TextField(controller: answer, maxLines: 3, decoration: const InputDecoration(labelText: 'توضیح پاسخ')),
    const SizedBox(height: 10),
    Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: const Color(0xFFFFF8E8), borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0x22FFA726))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('عکس تمرین', style: TextStyle(fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (imageUrl.isNotEmpty)
          ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.network(imageUrl, height: 145, width: double.infinity, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(height: 90, alignment: Alignment.center, color: Colors.white, child: Text(imageName.isEmpty ? 'عکس انتخاب شده' : imageName)))),
        if (imageUrl.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text(imageName, style: const TextStyle(color: kMuted, fontSize: 12))),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: uploading ? null : () async {
            setState(() => uploading = true);
            final uploaded = await pickGalleryImageAndUpload(context, api);
            if (uploaded != null) {
              setState(() { imageUrl = uploaded.url; imageName = uploaded.fileName; });
            }
            setState(() => uploading = false);
          },
          icon: uploading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.photo_library_rounded),
          label: Text(uploading ? 'در حال آپلود عکس...' : 'انتخاب عکس از گالری'),
        ),
        if (imageUrl.isNotEmpty) TextButton.icon(onPressed: () => setState(() { imageUrl = ''; imageName = ''; }), icon: const Icon(Icons.close_rounded), label: const Text('حذف عکس')),
        const Text('دانش‌آموز فقط عکس را از گالری انتخاب می‌کند؛ لینک به‌صورت خودکار ساخته می‌شود.', style: TextStyle(color: kMuted, fontSize: 12, height: 1.5)),
      ]),
    ),
  ], onSave: () async { await api.post('/api/assignments/${assignment.id}/submissions', {'answerText': answer.text, 'imageUrl': imageUrl}); await refresh(); });
}

Future<void> showMessageDialog(BuildContext context, ApiClient api, Future<void> Function() refresh) async {
  final message = TextEditingController();
  await showAppDialog(context, titleText: 'پیام به معلم', builder: (_) => [TextField(controller: message, maxLines: 5, decoration: const InputDecoration(labelText: 'متن پیام'))], onSave: () async { await api.post('/api/messages', {'message': message.text}); await refresh(); });
}

Future<void> showEnrollDialog(BuildContext context, ApiClient api, Course course, AppSettings settings, Future<void> Function() refresh) async {
  final receiptText = TextEditingController();
  String receiptFileUrl = '';
  String receiptFileName = '';
  bool uploading = false;

  await showAppDialog(context, titleText: 'ثبت‌نام کلاس', builder: (setState) => [
    PaymentBox(settings: settings),
    const SizedBox(height: 10),
    Text('کلاس: ${course.title}', style: const TextStyle(fontWeight: FontWeight.w900)),
    const SizedBox(height: 8), TextField(controller: receiptText, maxLines: 2, decoration: const InputDecoration(labelText: 'توضیح رسید / کد پیگیری')),
    const SizedBox(height: 10),
    Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: const Color(0xFFF1FFF6), borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0x2220B869))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('عکس رسید پرداخت', style: TextStyle(fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (receiptFileUrl.isNotEmpty)
          ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.network(receiptFileUrl, height: 130, width: double.infinity, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(height: 80, alignment: Alignment.center, color: Colors.white, child: Text(receiptFileName.isEmpty ? 'رسید انتخاب شده' : receiptFileName)))),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: uploading ? null : () async {
            setState(() => uploading = true);
            final uploaded = await pickGalleryImageAndUpload(context, api);
            if (uploaded != null) {
              setState(() { receiptFileUrl = uploaded.url; receiptFileName = uploaded.fileName; });
            }
            setState(() => uploading = false);
          },
          icon: uploading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.photo_library_rounded),
          label: Text(uploading ? 'در حال آپلود رسید...' : 'انتخاب عکس رسید از گالری'),
        ),
        if (receiptFileUrl.isNotEmpty) TextButton.icon(onPressed: () => setState(() { receiptFileUrl = ''; receiptFileName = ''; }), icon: const Icon(Icons.close_rounded), label: const Text('حذف رسید')),
      ]),
    ),
  ], onSave: () async { await api.post('/api/enrollments', {'courseId': course.id, 'receiptText': receiptText.text, 'receiptFileUrl': receiptFileUrl}); await refresh(); });
}

Future<String?> showTextInputDialog(BuildContext context, {required String title, required TextEditingController controller, required String hint}) async {
  String? result;
  await showAppDialog(context, titleText: title, builder: (_) => [TextField(controller: controller, maxLines: 4, decoration: InputDecoration(labelText: hint))], onSave: () async { result = controller.text; });
  return result;
}

Future<void> showAppDialog(BuildContext context, {required String titleText, required List<Widget> Function(void Function(void Function())) builder, required Future<void> Function() onSave}) async {
  bool busy = false;
  await showDialog<void>(context: context, builder: (dialogContext) => Directionality(textDirection: TextDirection.rtl, child: StatefulBuilder(builder: (context, setState) => AlertDialog(
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
    title: Text(titleText, style: const TextStyle(fontWeight: FontWeight.w900)),
    content: SizedBox(width: 440, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: builder(setState)))),
    actions: [TextButton(onPressed: busy ? null : () => Navigator.pop(dialogContext), child: const Text('انصراف')), FilledButton(onPressed: busy ? null : () async { setState(() => busy = true); try { await onSave(); if (dialogContext.mounted) Navigator.pop(dialogContext); } catch (e) { if (dialogContext.mounted) toast(dialogContext, e); } finally { if (context.mounted) setState(() => busy = false); } }, child: Text(busy ? 'در حال ذخیره...' : 'ذخیره'))],
  ))));
}

void openFileViewer(BuildContext context, LearningFile file) {
  final url = file.url.trim();
  if (!url.startsWith('http')) { toast(context, 'لینک باید با http یا https شروع شود.'); return; }
  Navigator.of(context).push(MaterialPageRoute(builder: (_) => Directionality(textDirection: TextDirection.rtl, child: MaterialViewerPage(file: file))));
}

class MaterialViewerPage extends StatelessWidget {
  const MaterialViewerPage({super.key, required this.file});
  final LearningFile file;
  @override
  Widget build(BuildContext context) {
    Widget viewer;
    if (file.type == 'image' || guessType(file.url) == 'image') {
      viewer = InteractiveViewer(child: Center(child: Image.network(file.url, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Text('عکس باز نشد.'))));
    } else if (file.type == 'video' || guessType(file.url) == 'video') {
      viewer = NetworkVideoPlayer(url: file.url);
    } else {
      final u = (file.type == 'pdf' || file.type == 'word' || guessType(file.url) == 'pdf' || guessType(file.url) == 'word') ? docsViewerUrl(file.url) : file.url;
      viewer = InAppWebViewer(url: u);
    }
    return Scaffold(
      body: Container(decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFFFF7FB), Color(0xFFEFF8FF)])), child: SafeArea(child: Padding(padding: const EdgeInsets.all(14), child: Column(children: [
        HeaderRow(title: file.title, onBack: () => Navigator.pop(context)),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [TinyPill(typeLabel(file.type)), if (file.courseTitle.isNotEmpty) ...[const SizedBox(width: 8), TinyPill(file.courseTitle, color: kBlue)]]),
        const SizedBox(height: 10),
        Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(24), child: Container(color: Colors.white, child: viewer))),
        const SizedBox(height: 8),
        OutlinedButton.icon(onPressed: () { Clipboard.setData(ClipboardData(text: file.url)); toast(context, 'لینک کپی شد.'); }, icon: const Icon(Icons.copy_rounded), label: const Text('کپی لینک')),
      ])))));
  }
}

class InAppWebViewer extends StatefulWidget {
  const InAppWebViewer({super.key, required this.url});
  final String url;
  @override
  State<InAppWebViewer> createState() => _InAppWebViewerState();
}

class _InAppWebViewerState extends State<InAppWebViewer> {
  late final WebViewController controller;
  bool loading = true;
  @override
  void initState() {
    super.initState();
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(onPageStarted: (_) => setState(() => loading = true), onPageFinished: (_) => setState(() => loading = false)))
      ..loadRequest(Uri.parse(widget.url));
  }
  @override
  Widget build(BuildContext context) => Stack(children: [WebViewWidget(controller: controller), if (loading) const Center(child: CircularProgressIndicator())]);
}

class NetworkVideoPlayer extends StatefulWidget {
  const NetworkVideoPlayer({super.key, required this.url});
  final String url;
  @override
  State<NetworkVideoPlayer> createState() => _NetworkVideoPlayerState();
}

class _NetworkVideoPlayerState extends State<NetworkVideoPlayer> {
  late final VideoPlayerController controller;
  late final Future<void> init;
  @override
  void initState() { super.initState(); controller = VideoPlayerController.networkUrl(Uri.parse(widget.url)); init = controller.initialize(); }
  @override
  void dispose() { controller.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => FutureBuilder<void>(future: init, builder: (context, snap) {
    if (snap.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
    if (snap.hasError) return const Center(child: Text('ویدئو باز نشد. لینک مستقیم MP4 را بررسی کن.'));
    return Stack(alignment: Alignment.center, children: [
      Center(child: AspectRatio(aspectRatio: controller.value.aspectRatio == 0 ? 16 / 9 : controller.value.aspectRatio, child: VideoPlayer(controller))),
      IconButton.filled(iconSize: 52, onPressed: () => setState(() { controller.value.isPlaying ? controller.pause() : controller.play(); }), icon: Icon(controller.value.isPlaying ? Icons.pause_rounded : Icons.play_arrow_rounded)),
      Positioned(bottom: 0, left: 0, right: 0, child: VideoProgressIndicator(controller, allowScrubbing: true, padding: const EdgeInsets.all(12))),
    ]);
  });
}
