# Private Teacher App V11

نسخه V11 شامل صفحه‌های جدا با Bottom Navigation، خانه وسط، داشبورد، کلاس‌ها، فایل‌ها، تنظیمات، تمرین‌ها، ارسال تمرین با عکس/لینک عکس، و پیام دانش‌آموز به معلم است.

API ثابت داخل اپ:
https://likezilla.ir/ahmadvand/backend_php

بعد از آپلود backend_php روی هاست، این لینک را یک‌بار اجرا کن:
https://likezilla.ir/ahmadvand/backend_php/upgrade_v11.php

بعد از موفقیت، فایل upgrade_v11.php را حذف کن.
