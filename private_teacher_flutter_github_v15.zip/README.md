# Private Teacher App V13

نسخه مخصوص GitHub برای گرفتن APK. این نسخه شامل نقش همکاران، اشتراک‌های ۱، ۳ و ۶ ماهه، مدیریت دسترسی فایل‌ها و انتخاب عکس از گالری است.

API ثابت داخل اپ:
https://likezilla.ir/ahmadvand/backend_php
