# Private Teacher App - Clean V7

این نسخه مخصوص خروجی APK پایدار ساخته شده است.

- API داخل اپ ثابت است: https://likezilla.ir/ahmadvand/backend_php
- پکیج‌های مشکل‌ساز مثل file_picker، url_launcher و shared_preferences حذف شده‌اند.
- اپ به بک‌اند PHP/MySQL نصب‌شده روی هاست وصل می‌شود.
- برای کلاس آنلاین، لینک Google Meet یا هر لینک دیگر داخل کلاس ثبت می‌شود و بعد از تایید پرداخت برای دانش‌آموز قابل کپی است.

## ورود معلم
Phone: 09035906224
Password: 1234Za

## نکته
اگر این فایل را به شکل ZIP در ریپو می‌گذاری، ZIPهای قبلی را حذف کن تا Workflow اشتباه فایل قدیمی را برندارد.
