import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

const String apiBaseUrl = 'https://likezilla.ir/ahmadvand/backend_php';
const String fixedTeacherPhone = '09035906224';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    systemNavigationBarColor: Color(0xFFEFF8FF),
    statusBarIconBrightness: Brightness.dark,
  ));
  runApp(const PrivateTeacherApp());
}

const Color kPurple = Color(0xFF7B61FF);
const Color kPink = Color(0xFFFF6FAE);
const Color kBlue = Color(0xFF4DA3FF);
const Color kGreen = Color(0xFF20B869);
const Color kText = Color(0xFF1C1C28);
const Color kMuted = Color(0xFF6E6E7A);
const Color kSoft = Color(0xFFF8F7FF);

String money(dynamic value) {
  var raw = value.toString().trim();
  if (raw.contains('تومان')) return raw;
  final n = int.tryParse(raw.replaceAll(RegExp(r'[^0-9]'), '')) ?? 0;
  final s = n.toString();
  final out = StringBuffer();
  for (int i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) out.write(',');
    out.write(s[i]);
  }
  return '${out.toString()} تومان';
}

String cleanError(Object e) {
  var text = e.toString();
  text = text.replaceFirst('Exception: ', '').replaceFirst('ApiError: ', '');
  return text;
}

void toast(BuildContext context, String text) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(cleanError(text)), behavior: SnackBarBehavior.floating));
}

String statusText(String value) {
  if (value == 'approved') return 'تایید شده';
  if (value == 'rejected') return 'رد شده';
  return 'در انتظار بررسی';
}

Color themeColor(String theme) => theme == 'boy' ? kBlue : kPink;
String themeEmoji(String theme) => theme == 'boy' ? '🚀' : '🌸';

class PrivateTeacherApp extends StatelessWidget {
  const PrivateTeacherApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'کلاس خصوصی',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Roboto',
        colorSchemeSeed: kPurple,
        scaffoldBackgroundColor: kSoft,
        textTheme: const TextTheme(
          titleLarge: TextStyle(fontWeight: FontWeight.w900, color: kText),
          headlineSmall: TextStyle(fontWeight: FontWeight.w900, color: kText),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: const BorderSide(color: Color(0x11000000))),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: const BorderSide(color: Color(0x11000000))),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(22), borderSide: const BorderSide(color: kPurple, width: 1.3)),
        ),
      ),
      home: const Directionality(textDirection: TextDirection.rtl, child: AppRoot()),
    );
  }
}

class ApiError implements Exception {
  ApiError(this.message);
  final String message;
  @override
  String toString() => message;
}

class ApiClient {
  String? token;

  Map<String, String> get headers => <String, String>{
        'Content-Type': 'application/json',
        if (token != null && token!.isNotEmpty) 'Authorization': 'Bearer $token',
      };

  Uri uri(String path) => Uri.parse('$apiBaseUrl$path');

  Future<dynamic> _handle(http.Response res) async {
    dynamic body;
    try {
      body = res.body.isEmpty ? null : jsonDecode(res.body);
    } catch (_) {
      body = null;
    }
    if (res.statusCode >= 200 && res.statusCode < 300) return body;
    if (body is Map && body['message'] != null) throw ApiError(body['message'].toString());
    throw ApiError('خطا در ارتباط با سرور');
  }

  Future<dynamic> _request(Future<http.Response> Function() call) async {
    try {
      return _handle(await call().timeout(const Duration(seconds: 25)));
    } on ApiError {
      rethrow;
    } on SocketException {
      throw ApiError('اتصال به سرور برقرار نشد. اینترنت گوشی، VPN یا DNS دامنه likezilla.ir را بررسی کن.');
    } on TimeoutException {
      throw ApiError('سرور دیر پاسخ داد. اینترنت یا هاست را بررسی کن.');
    } on http.ClientException catch (e) {
      if (e.message.toLowerCase().contains('failed host lookup')) {
        throw ApiError('دامنه سرور پیدا نشد. اینترنت، VPN یا DNS دامنه را بررسی کن.');
      }
      throw ApiError('ارتباط با سرور برقرار نشد.');
    } catch (_) {
      throw ApiError('خطای ارتباط با سرور.');
    }
  }

  Future<dynamic> get(String path) => _request(() => http.get(uri(path), headers: headers));
  Future<dynamic> post(String path, Map<String, dynamic> data) => _request(() => http.post(uri(path), headers: headers, body: jsonEncode(data)));
  Future<dynamic> put(String path, Map<String, dynamic> data) => _request(() => http.put(uri(path), headers: headers, body: jsonEncode(data)));
  Future<dynamic> patch(String path, Map<String, dynamic> data) => _request(() => http.patch(uri(path), headers: headers, body: jsonEncode(data)));
  Future<dynamic> delete(String path) => _request(() => http.delete(uri(path), headers: headers));
}

class AppSettings {
  AppSettings({required this.appTitle, required this.teacherName, required this.cardNumber, required this.cardOwner, required this.supportPhone, required this.paymentHelp});
  factory AppSettings.fromJson(Map<String, dynamic> j) => AppSettings(
        appTitle: j['appTitle']?.toString() ?? 'کلاس خصوصی مهربون',
        teacherName: j['teacherName']?.toString() ?? 'خانم معلم',
        cardNumber: j['cardNumber']?.toString() ?? '6037 0000 0000 0000',
        cardOwner: j['cardOwner']?.toString() ?? 'نام صاحب کارت',
        supportPhone: j['supportPhone']?.toString() ?? '09xxxxxxxxx',
        paymentHelp: j['paymentHelp']?.toString() ?? 'بعد از کارت‌به‌کارت، کد پیگیری یا توضیح رسید را ثبت کن.',
      );
  final String appTitle;
  final String teacherName;
  final String cardNumber;
  final String cardOwner;
  final String supportPhone;
  final String paymentHelp;
}

class UserData {
  UserData({required this.role, required this.name, required this.phone, required this.parentPhone, required this.theme});
  factory UserData.fromJson(Map<String, dynamic> j) => UserData(
        role: j['role']?.toString() ?? '',
        name: j['name']?.toString() ?? '',
        phone: j['phone']?.toString() ?? '',
        parentPhone: j['parentPhone']?.toString() ?? j['parent_phone']?.toString() ?? '',
        theme: j['theme']?.toString() == 'boy' ? 'boy' : 'girl',
      );
  final String role;
  final String name;
  final String phone;
  final String parentPhone;
  final String theme;
}

class Course {
  Course({required this.id, required this.title, required this.subject, required this.grade, required this.price, required this.schedule, required this.type, required this.accessLink, required this.description, required this.isActive, required this.resources});
  factory Course.fromJson(Map<String, dynamic> j) {
    final list = <Resource>[];
    if (j['resources'] is List) {
      for (final item in j['resources']) {
        if (item is Map) list.add(Resource.fromJson(Map<String, dynamic>.from(item)));
      }
    }
    return Course(
      id: j['id']?.toString() ?? j['_id']?.toString() ?? '',
      title: j['title']?.toString() ?? '',
      subject: j['subject']?.toString() ?? '',
      grade: j['grade']?.toString() ?? '',
      price: int.tryParse(j['price'].toString()) ?? 0,
      schedule: j['schedule']?.toString() ?? '',
      type: j['type']?.toString() == 'offline' ? 'offline' : 'online',
      accessLink: j['accessLink']?.toString() ?? '',
      description: j['description']?.toString() ?? '',
      isActive: j['isActive'] == true || j['isActive'] == 1 || j['isActive']?.toString() == '1',
      resources: list,
    );
  }
  final String id;
  final String title;
  final String subject;
  final String grade;
  final int price;
  final String schedule;
  final String type;
  final String accessLink;
  final String description;
  final bool isActive;
  final List<Resource> resources;
}

class Resource {
  Resource({required this.title, required this.kind, required this.url});
  factory Resource.fromJson(Map<String, dynamic> j) => Resource(title: j['title']?.toString() ?? '', kind: j['kind']?.toString() ?? 'لینک', url: j['url']?.toString() ?? '');
  final String title;
  final String kind;
  final String url;
  Map<String, dynamic> toJson() => {'title': title, 'kind': kind, 'url': url};
}

class Enrollment {
  Enrollment({required this.id, required this.status, required this.receiptText, required this.rejectReason, this.course, this.student});
  factory Enrollment.fromJson(Map<String, dynamic> j) => Enrollment(
        id: j['id']?.toString() ?? j['_id']?.toString() ?? '',
        status: j['status']?.toString() ?? 'pending',
        receiptText: j['receiptText']?.toString() ?? j['receipt_text']?.toString() ?? '',
        rejectReason: j['rejectReason']?.toString() ?? j['reject_reason']?.toString() ?? '',
        course: j['course'] is Map ? Course.fromJson(Map<String, dynamic>.from(j['course'])) : null,
        student: j['student'] is Map ? UserData.fromJson(Map<String, dynamic>.from(j['student'])) : null,
      );
  final String id;
  final String status;
  final String receiptText;
  final String rejectReason;
  final Course? course;
  final UserData? student;
}

class AppRoot extends StatefulWidget {
  const AppRoot({super.key});
  @override
  State<AppRoot> createState() => _AppRootState();
}

class _AppRootState extends State<AppRoot> {
  final api = ApiClient();
  AppSettings settings = AppSettings.fromJson({});
  UserData? user;
  bool loading = true;
  String page = 'role';

  @override
  void initState() {
    super.initState();
    loadSettings();
  }

  Future<void> loadSettings() async {
    try {
      final res = await api.get('/api/settings');
      if (res is Map) settings = AppSettings.fromJson(Map<String, dynamic>.from(res));
    } catch (_) {}
    if (mounted) setState(() => loading = false);
  }

  void openPage(String p) => setState(() => page = p);
  void login(String token, UserData u) => setState(() { api.token = token; user = u; });
  void logout() => setState(() { api.token = null; user = null; page = 'role'; });

  @override
  Widget build(BuildContext context) {
    if (loading) return const GradientBackground(child: Center(child: CircularProgressIndicator()));
    if (user != null && user!.role == 'teacher') return TeacherHome(api: api, settings: settings, user: user!, onLogout: logout, onSettingsChanged: loadSettings);
    if (user != null) return StudentHome(api: api, settings: settings, user: user!, onLogout: logout);
    if (page == 'teacherLogin') return TeacherLoginScreen(api: api, settings: settings, onBack: () => openPage('role'), onLogin: login);
    if (page == 'studentLogin') return StudentLoginScreen(api: api, settings: settings, onBack: () => openPage('role'), onLogin: login);
    return RoleScreen(settings: settings, onTeacher: () => openPage('teacherLogin'), onStudent: () => openPage('studentLogin'));
  }
}

class GradientBackground extends StatelessWidget {
  const GradientBackground({super.key, required this.child});
  final Widget child;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFFFFF7FB), Color(0xFFEFF8FF), Color(0xFFF8F7FF)]),
        ),
        child: SafeArea(child: child),
      ),
    );
  }
}

class ScreenPanel extends StatelessWidget {
  const ScreenPanel({super.key, required this.child, this.padding = const EdgeInsets.fromLTRB(20, 26, 20, 26)});
  final Widget child;
  final EdgeInsets padding;
  @override
  Widget build(BuildContext context) {
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 480),
        child: Container(
          margin: const EdgeInsets.all(14),
          padding: padding,
          decoration: BoxDecoration(
            color: const Color(0xEEF9F8FF),
            borderRadius: BorderRadius.circular(38),
            border: Border.all(color: Colors.white.withOpacity(0.75)),
            boxShadow: const [BoxShadow(color: Color(0x12000000), blurRadius: 34, offset: Offset(0, 18))],
          ),
          child: child,
        ),
      ),
    );
  }
}

class CircleLogo extends StatelessWidget {
  const CircleLogo(this.text, {super.key});
  final String text;
  @override
  Widget build(BuildContext context) => Container(
        width: 106,
        height: 106,
        decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle, boxShadow: [BoxShadow(color: Color(0x12000000), blurRadius: 28, offset: Offset(0, 12))]),
        child: Center(child: Text(text, style: const TextStyle(fontSize: 48))),
      );
}

class SoftCard extends StatelessWidget {
  const SoftCard({super.key, required this.child, this.onTap, this.padding = const EdgeInsets.all(18)});
  final Widget child;
  final VoidCallback? onTap;
  final EdgeInsets padding;
  @override
  Widget build(BuildContext context) {
    final card = Container(
      width: double.infinity,
      padding: padding,
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(26), border: Border.all(color: const Color(0x08000000)), boxShadow: const [BoxShadow(color: Color(0x10000000), blurRadius: 25, offset: Offset(0, 12))]),
      child: child,
    );
    if (onTap == null) return card;
    return InkWell(borderRadius: BorderRadius.circular(26), onTap: onTap, child: card);
  }
}

class TopBar extends StatelessWidget {
  const TopBar({super.key, required this.title, required this.onBack, this.backText = 'خروج'});
  final String title;
  final VoidCallback onBack;
  final String backText;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 20),
        child: Row(children: [
          _TopButton(text: backText, onTap: onBack),
          Expanded(child: Text(title, textAlign: TextAlign.center, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: kText))),
          _TopButton(text: '›', onTap: onBack, wide: false),
        ]),
      );
}

class _TopButton extends StatelessWidget {
  const _TopButton({required this.text, required this.onTap, this.wide = true});
  final String text;
  final VoidCallback onTap;
  final bool wide;
  @override
  Widget build(BuildContext context) => InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Container(
          width: wide ? 70 : 52,
          height: 52,
          decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.all(Radius.circular(18)), boxShadow: [BoxShadow(color: Color(0x0F000000), blurRadius: 22, offset: Offset(0, 10))]),
          child: Center(child: Text(text, style: TextStyle(fontSize: wide ? 14 : 26, fontWeight: FontWeight.bold, color: kText))),
        ),
      );
}

class RoleScreen extends StatelessWidget {
  const RoleScreen({super.key, required this.settings, required this.onTeacher, required this.onStudent});
  final AppSettings settings;
  final VoidCallback onTeacher;
  final VoidCallback onStudent;
  @override
  Widget build(BuildContext context) {
    return GradientBackground(
      child: SingleChildScrollView(
        child: ScreenPanel(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const CircleLogo('🎒'),
            const SizedBox(height: 18),
            Text(settings.appTitle.isEmpty ? 'کلاس خصوصی مهربون' : settings.appTitle, textAlign: TextAlign.center, style: const TextStyle(fontSize: 31, fontWeight: FontWeight.w900, color: kText)),
            const SizedBox(height: 14),
            const Text('مدیریت کلاس آنلاین و آفلاین برای دانش‌آموزهای ابتدایی', textAlign: TextAlign.center, style: TextStyle(fontSize: 16, color: kMuted, height: 1.8)),
            const SizedBox(height: 28),
            RoleCard(icon: '👩‍🏫', title: 'ورود معلم', subtitle: 'افزودن کلاس، بررسی رسید و مدیریت دانش‌آموزها', color: kPurple, onTap: onTeacher),
            const SizedBox(height: 16),
            RoleCard(icon: '🧒', title: 'ورود دانش‌آموز', subtitle: 'دیدن کلاس‌ها، ثبت‌نام و دریافت لینک یا فایل آموزشی', color: kBlue, onTap: onStudent),
            const SizedBox(height: 28),
            const Chip(label: Text('نسخه دمو برای ارائه به مشتری')),
          ]),
        ),
      ),
    );
  }
}

class RoleCard extends StatelessWidget {
  const RoleCard({super.key, required this.icon, required this.title, required this.subtitle, required this.color, required this.onTap});
  final String icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => SoftCard(
        onTap: onTap,
        child: Row(children: [
          Container(width: 64, height: 64, decoration: BoxDecoration(color: color.withOpacity(0.12), shape: BoxShape.circle), child: Center(child: Text(icon, style: const TextStyle(fontSize: 33)))),
          const SizedBox(width: 14),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w900, color: kText)), const SizedBox(height: 6), Text(subtitle, style: const TextStyle(fontSize: 14, color: kMuted, height: 1.7))])),
        ]),
      );
}

class TeacherLoginScreen extends StatefulWidget {
  const TeacherLoginScreen({super.key, required this.api, required this.settings, required this.onBack, required this.onLogin});
  final ApiClient api;
  final AppSettings settings;
  final VoidCallback onBack;
  final void Function(String token, UserData user) onLogin;
  @override
  State<TeacherLoginScreen> createState() => _TeacherLoginScreenState();
}

class _TeacherLoginScreenState extends State<TeacherLoginScreen> {
  final password = TextEditingController();
  bool busy = false;
  @override
  void dispose() { password.dispose(); super.dispose(); }
  Future<void> submit() async {
    if (password.text.trim().isEmpty) { toast(context, 'رمز معلم را وارد کن.'); return; }
    setState(() => busy = true);
    try {
      final res = await widget.api.post('/api/auth/teacher-login', {'phone': fixedTeacherPhone, 'password': password.text.trim()});
      widget.onLogin(res['token'].toString(), UserData.fromJson(Map<String, dynamic>.from(res['user'])));
    } catch (e) { toast(context, e.toString()); } finally { if (mounted) setState(() => busy = false); }
  }
  @override
  Widget build(BuildContext context) => GradientBackground(
        child: SingleChildScrollView(
          child: ScreenPanel(
            child: Column(children: [
              TopBar(title: 'ورود معلم', onBack: widget.onBack, backText: 'بازگشت'),
              const CircleLogo('🔐'),
              const SizedBox(height: 18),
              const Text('پنل مدیریت داخل اپ', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: kText)),
              const SizedBox(height: 10),
              const Text('برای ورود فقط رمز معلم را وارد کن.', style: TextStyle(color: kMuted)),
              const SizedBox(height: 24),
              TextField(controller: password, obscureText: true, textAlign: TextAlign.center, decoration: const InputDecoration(hintText: 'رمز معلم')),
              const SizedBox(height: 18),
              PrimaryButton(text: busy ? 'در حال ورود...' : 'ورود به مدیریت', onTap: busy ? null : submit, color: kPurple),
            ]),
          ),
        ),
      );
}

class StudentLoginScreen extends StatefulWidget {
  const StudentLoginScreen({super.key, required this.api, required this.settings, required this.onBack, required this.onLogin});
  final ApiClient api;
  final AppSettings settings;
  final VoidCallback onBack;
  final void Function(String token, UserData user) onLogin;
  @override
  State<StudentLoginScreen> createState() => _StudentLoginScreenState();
}

class _StudentLoginScreenState extends State<StudentLoginScreen> {
  final name = TextEditingController();
  final parentPhone = TextEditingController();
  String theme = 'girl';
  bool busy = false;
  @override
  void dispose() { name.dispose(); parentPhone.dispose(); super.dispose(); }
  Future<void> submit() async {
    if (name.text.trim().isEmpty || parentPhone.text.trim().isEmpty) { toast(context, 'نام دانش‌آموز و شماره والدین را وارد کن.'); return; }
    setState(() => busy = true);
    try {
      final phone = parentPhone.text.trim();
      final res = await widget.api.post('/api/auth/student-login', {'name': name.text.trim(), 'phone': phone, 'parentPhone': phone, 'theme': theme});
      widget.onLogin(res['token'].toString(), UserData.fromJson(Map<String, dynamic>.from(res['user'])));
    } catch (e) { toast(context, e.toString()); } finally { if (mounted) setState(() => busy = false); }
  }
  @override
  Widget build(BuildContext context) => GradientBackground(
        child: SingleChildScrollView(
          child: ScreenPanel(
            child: Column(children: [
              TopBar(title: 'ورود دانش‌آموز', onBack: widget.onBack, backText: 'بازگشت'),
              CircleLogo(themeEmoji(theme)),
              const SizedBox(height: 26),
              const Text('سلام قهرمان کوچولو!', textAlign: TextAlign.center, style: TextStyle(fontSize: 33, fontWeight: FontWeight.w900, color: kText)),
              const SizedBox(height: 22),
              const Text('اسم دانش‌آموز و تم دلخواه را انتخاب کن.', style: TextStyle(color: kMuted, fontSize: 16)),
              const SizedBox(height: 26),
              TextField(controller: name, textAlign: TextAlign.right, decoration: const InputDecoration(hintText: 'نام دانش‌آموز')),
              const SizedBox(height: 14),
              TextField(controller: parentPhone, keyboardType: TextInputType.phone, decoration: const InputDecoration(hintText: 'شماره والدین')),
              const SizedBox(height: 18),
              Row(children: [
                Expanded(child: ThemeChoice(icon: '🚀', title: 'تم پسرونه', selected: theme == 'boy', color: kBlue, onTap: () => setState(() => theme = 'boy'))),
                const SizedBox(width: 14),
                Expanded(child: ThemeChoice(icon: '🌸', title: 'تم دخترونه', selected: theme == 'girl', color: kPink, onTap: () => setState(() => theme = 'girl'))),
              ]),
              const SizedBox(height: 20),
              PrimaryButton(text: busy ? 'در حال ورود...' : 'ورود به کلاس‌ها', onTap: busy ? null : submit, color: themeColor(theme)),
            ]),
          ),
        ),
      );
}

class ThemeChoice extends StatelessWidget {
  const ThemeChoice({super.key, required this.icon, required this.title, required this.selected, required this.color, required this.onTap});
  final String icon;
  final String title;
  final bool selected;
  final Color color;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => InkWell(
        borderRadius: BorderRadius.circular(26),
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          height: 116,
          decoration: BoxDecoration(color: selected ? color.withOpacity(0.13) : Colors.white, borderRadius: BorderRadius.circular(26), border: Border.all(color: selected ? color : Colors.transparent, width: 2.2), boxShadow: const [BoxShadow(color: Color(0x0A000000), blurRadius: 18, offset: Offset(0, 8))]),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Text(icon, style: const TextStyle(fontSize: 32)), const SizedBox(height: 8), Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: kText))]),
        ),
      );
}

class PrimaryButton extends StatelessWidget {
  const PrimaryButton({super.key, required this.text, required this.onTap, this.color = kPurple});
  final String text;
  final VoidCallback? onTap;
  final Color color;
  @override
  Widget build(BuildContext context) => SizedBox(
        width: double.infinity,
        height: 58,
        child: ElevatedButton(
          onPressed: onTap,
          style: ElevatedButton.styleFrom(backgroundColor: color, foregroundColor: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
          child: Text(text, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
        ),
      );
}

class TeacherHome extends StatefulWidget {
  const TeacherHome({super.key, required this.api, required this.settings, required this.user, required this.onLogout, required this.onSettingsChanged});
  final ApiClient api;
  final AppSettings settings;
  final UserData user;
  final VoidCallback onLogout;
  final Future<void> Function() onSettingsChanged;
  @override
  State<TeacherHome> createState() => _TeacherHomeState();
}

class _TeacherHomeState extends State<TeacherHome> {
  bool loading = true;
  List<Course> courses = [];
  List<Enrollment> enrollments = [];
  @override
  void initState() { super.initState(); refresh(); }
  Future<void> refresh() async {
    setState(() => loading = true);
    try {
      final c = await widget.api.get('/api/courses');
      final e = await widget.api.get('/api/enrollments');
      courses = (c as List).map((x) => Course.fromJson(Map<String, dynamic>.from(x))).toList();
      enrollments = (e as List).map((x) => Enrollment.fromJson(Map<String, dynamic>.from(x))).toList();
    } catch (err) { if (mounted) toast(context, err.toString()); } finally { if (mounted) setState(() => loading = false); }
  }
  Future<void> updateStatus(Enrollment e, String status) async {
    try { await widget.api.patch('/api/enrollments/${e.id}/status', {'status': status, 'rejectReason': status == 'rejected' ? 'رسید تایید نشد' : ''}); await refresh(); } catch (err) { if (mounted) toast(context, err.toString()); }
  }
  Future<void> deleteCourse(Course c) async {
    try { await widget.api.delete('/api/courses/${c.id}'); await refresh(); } catch (err) { if (mounted) toast(context, err.toString()); }
  }
  @override
  Widget build(BuildContext context) => GradientBackground(
        child: Stack(children: [
          RefreshIndicator(
            onRefresh: refresh,
            child: SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              child: ScreenPanel(
                padding: const EdgeInsets.fromLTRB(20, 22, 20, 92),
                child: loading ? const SizedBox(height: 360, child: Center(child: CircularProgressIndicator())) : Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                  TopBar(title: 'مدیریت معلم', onBack: widget.onLogout),
                  Row(children: [Expanded(child: StatCard(icon: '🧾', value: enrollments.where((e) => e.status == 'pending').length.toString(), label: 'رسید جدید')), const SizedBox(width: 14), Expanded(child: StatCard(icon: '📚', value: courses.length.toString(), label: 'کلاس‌ها'))]),
                  const SizedBox(height: 28),
                  const SectionTitle('✅ رسیدها و ثبت‌نام‌ها'),
                  if (enrollments.isEmpty) const SoftCard(child: Text('هنوز ثبت‌نامی ثبت نشده است.', textAlign: TextAlign.center, style: TextStyle(color: kMuted, fontSize: 16))) else ...enrollments.map((e) => EnrollmentTile(enrollment: e, teacher: true, onApprove: () => updateStatus(e, 'approved'), onReject: () => updateStatus(e, 'rejected'))),
                  const SizedBox(height: 24),
                  const SectionTitle('🗂️ کلاس‌های فعال'),
                  if (courses.isEmpty) const SoftCard(child: Text('هنوز کلاسی ثبت نشده است.', textAlign: TextAlign.center, style: TextStyle(color: kMuted))) else ...courses.map((c) => TeacherCourseTile(course: c, onEdit: () => openCourseForm(context, widget.api, c, refresh), onDelete: () => deleteCourse(c))),
                  const SizedBox(height: 28),
                  SettingsMini(settings: widget.settings, api: widget.api, onDone: () async { await widget.onSettingsChanged(); await refresh(); }),
                ]),
              ),
            ),
          ),
          Positioned(left: 28, bottom: 28, child: FloatingActionButton.extended(backgroundColor: kPurple, foregroundColor: Colors.white, elevation: 6, onPressed: () => openCourseForm(context, widget.api, null, refresh), icon: const Icon(Icons.add_rounded), label: const Text('کلاس جدید', style: TextStyle(fontWeight: FontWeight.w900)))),
        ]),
      );
}

class StatCard extends StatelessWidget {
  const StatCard({super.key, required this.icon, required this.value, required this.label});
  final String icon, value, label;
  @override
  Widget build(BuildContext context) => SoftCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(icon, style: const TextStyle(fontSize: 23)), Text(value, style: const TextStyle(color: kPurple, fontSize: 34, fontWeight: FontWeight.w900)), Text(label, style: const TextStyle(color: kMuted, fontSize: 15))]),
      );
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key});
  final String text;
  @override
  Widget build(BuildContext context) => Padding(padding: const EdgeInsets.fromLTRB(4, 8, 4, 14), child: Text(text, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: kText)));
}

class TeacherCourseTile extends StatelessWidget {
  const TeacherCourseTile({super.key, required this.course, required this.onEdit, required this.onDelete});
  final Course course;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: SoftCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Row(children: [TypePill(type: course.type), const Spacer(), Expanded(flex: 5, child: Text(course.title, textAlign: TextAlign.right, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: kText)))]),
            const SizedBox(height: 12),
            Text('${course.subject} • ${course.grade}', textAlign: TextAlign.right, style: const TextStyle(color: kMuted, fontSize: 15)),
            const SizedBox(height: 16),
            Wrap(spacing: 8, runSpacing: 8, alignment: WrapAlignment.end, children: [InfoPill(money(course.price)), InfoPill(course.schedule.isEmpty ? 'زمان اعلام می‌شود' : course.schedule)]),
            const SizedBox(height: 12),
            Row(children: [Expanded(child: OutlinedButton(onPressed: onDelete, child: const Text('حذف'))), const SizedBox(width: 10), Expanded(child: ElevatedButton(onPressed: onEdit, style: ElevatedButton.styleFrom(backgroundColor: kPurple, foregroundColor: Colors.white), child: const Text('ویرایش')))]),
          ]),
        ),
      );
}

class StudentHome extends StatefulWidget {
  const StudentHome({super.key, required this.api, required this.settings, required this.user, required this.onLogout});
  final ApiClient api;
  final AppSettings settings;
  final UserData user;
  final VoidCallback onLogout;
  @override
  State<StudentHome> createState() => _StudentHomeState();
}

class _StudentHomeState extends State<StudentHome> {
  bool loading = true;
  List<Course> courses = [];
  List<Enrollment> enrollments = [];
  @override
  void initState() { super.initState(); refresh(); }
  Future<void> refresh() async {
    setState(() => loading = true);
    try {
      final c = await widget.api.get('/api/courses');
      final e = await widget.api.get('/api/enrollments');
      courses = (c as List).map((x) => Course.fromJson(Map<String, dynamic>.from(x))).where((x) => x.isActive).toList();
      enrollments = (e as List).map((x) => Enrollment.fromJson(Map<String, dynamic>.from(x))).toList();
    } catch (err) { if (mounted) toast(context, err.toString()); } finally { if (mounted) setState(() => loading = false); }
  }
  Enrollment? enrollmentFor(Course c) {
    for (final e in enrollments) {
      if (e.course?.id == c.id) return e;
    }
    return null;
  }
  Future<void> enroll(Course c) async {
    final controller = TextEditingController();
    final res = await showDialog<String>(context: context, builder: (ctx) => Directionality(textDirection: TextDirection.rtl, child: AlertDialog(
      title: const Text('ثبت رسید پرداخت'),
      content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        PaymentBox(settings: widget.settings, compact: true),
        const SizedBox(height: 12),
        TextField(controller: controller, maxLines: 3, decoration: const InputDecoration(hintText: 'کد پیگیری یا توضیح رسید')),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('انصراف')), ElevatedButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('ارسال رسید'))],
    )));
    controller.dispose();
    if (res == null) return;
    try { await widget.api.post('/api/enrollments', {'courseId': c.id, 'receiptText': res.isEmpty ? 'رسید ارسال شد' : res}); await refresh(); if (mounted) toast(context, 'درخواست ثبت‌نام ارسال شد.'); } catch (err) { if (mounted) toast(context, err.toString()); }
  }
  @override
  Widget build(BuildContext context) => GradientBackground(
        child: RefreshIndicator(
          onRefresh: refresh,
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            child: ScreenPanel(
              padding: const EdgeInsets.fromLTRB(20, 22, 20, 30),
              child: loading ? const SizedBox(height: 360, child: Center(child: CircularProgressIndicator())) : Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                TopBar(title: 'کلاس‌های ${widget.user.name}', onBack: widget.onLogout),
                SoftCard(child: Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('سلام ${widget.user.name}!', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w900, color: kText)), const SizedBox(height: 12), const Text('کلاس دلخواهت رو انتخاب کن و منتظر تایید معلم باش.', style: TextStyle(color: kMuted, fontSize: 16, height: 1.7))])), Text(themeEmoji(widget.user.theme), style: const TextStyle(fontSize: 58))])),
                const SizedBox(height: 24),
                PaymentBox(settings: widget.settings),
                const SizedBox(height: 24),
                const SectionTitle('📚 کلاس‌های قابل ثبت‌نام'),
                if (courses.isEmpty) const SoftCard(child: Text('فعلاً کلاسی فعال نیست.', textAlign: TextAlign.center, style: TextStyle(color: kMuted))) else ...courses.map((c) => StudentCourseTile(course: c, enrollment: enrollmentFor(c), theme: widget.user.theme, onEnroll: () => enroll(c))),
              ]),
            ),
          ),
        ),
      );
}

class StudentCourseTile extends StatelessWidget {
  const StudentCourseTile({super.key, required this.course, required this.enrollment, required this.theme, required this.onEnroll});
  final Course course;
  final Enrollment? enrollment;
  final String theme;
  final VoidCallback onEnroll;
  @override
  Widget build(BuildContext context) {
    final approved = enrollment?.status == 'approved';
    final pending = enrollment?.status == 'pending';
    final rejected = enrollment?.status == 'rejected';
    final color = approved ? kGreen : themeColor(theme);
    final button = approved ? 'کلاس فعال شد' : pending ? 'منتظر تایید معلم' : rejected ? 'ارسال دوباره رسید' : 'ثبت‌نام';
    return Padding(
      padding: const EdgeInsets.only(bottom: 18),
      child: SoftCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [Container(width: 58, height: 58, decoration: BoxDecoration(shape: BoxShape.circle, color: color.withOpacity(0.12)), child: Center(child: Text(course.type == 'online' ? '🎥' : '🎬', style: const TextStyle(fontSize: 30)))), const SizedBox(width: 12), Expanded(child: Text(course.title, textAlign: TextAlign.right, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: kText)))]),
          const SizedBox(height: 12),
          Text('${course.subject} • ${course.grade}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 15, color: kMuted)),
          const SizedBox(height: 14),
          if (course.description.isNotEmpty) Text(course.description, textAlign: TextAlign.center, style: const TextStyle(fontSize: 15, color: kMuted, height: 1.7)),
          const SizedBox(height: 16),
          Wrap(spacing: 8, runSpacing: 8, alignment: WrapAlignment.center, children: [InfoPill(money(course.price)), InfoPill(course.schedule.isEmpty ? 'زمان اعلام می‌شود' : course.schedule), InfoPill(course.type == 'online' ? 'آنلاین' : 'آفلاین')]),
          if (enrollment != null) ...[const SizedBox(height: 10), StatusChip(status: enrollment!.status)],
          if (approved) AccessBox(course: course),
          const SizedBox(height: 18),
          PrimaryButton(text: button, color: color, onTap: pending || approved ? null : onEnroll),
        ]),
      ),
    );
  }
}

class PaymentBox extends StatelessWidget {
  const PaymentBox({super.key, required this.settings, this.compact = false});
  final AppSettings settings;
  final bool compact;
  @override
  Widget build(BuildContext context) => Container(
        padding: EdgeInsets.all(compact ? 12 : 18),
        decoration: BoxDecoration(gradient: const LinearGradient(colors: [kPurple, kPink]), borderRadius: BorderRadius.circular(24)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('💳 پرداخت کارت‌به‌کارت', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 17)),
          const SizedBox(height: 10),
          Directionality(textDirection: TextDirection.ltr, child: Text(settings.cardNumber, textAlign: TextAlign.right, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900, letterSpacing: 1.2))),
          const SizedBox(height: 6),
          Text('به نام: ${settings.cardOwner}', style: const TextStyle(color: Colors.white)),
          if (!compact) TextButton(onPressed: () { Clipboard.setData(ClipboardData(text: settings.cardNumber)); toast(context, 'شماره کارت کپی شد.'); }, child: const Text('کپی شماره کارت', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold))),
        ]),
      );
}

class AccessBox extends StatelessWidget {
  const AccessBox({super.key, required this.course});
  final Course course;
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(top: 14),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: kGreen.withOpacity(0.10), borderRadius: BorderRadius.circular(18)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('دسترسی کلاس', style: TextStyle(fontWeight: FontWeight.w900, color: kText)),
          if (course.accessLink.isNotEmpty) TextButton.icon(onPressed: () { Clipboard.setData(ClipboardData(text: course.accessLink)); toast(context, 'لینک کلاس کپی شد.'); }, icon: const Icon(Icons.copy_rounded), label: const Text('کپی لینک کلاس')),
          if (course.resources.isNotEmpty) ...course.resources.map((r) => TextButton.icon(onPressed: () { Clipboard.setData(ClipboardData(text: r.url)); toast(context, 'لینک منبع کپی شد.'); }, icon: const Icon(Icons.link_rounded), label: Text('${r.kind}: ${r.title}'))),
        ]),
      );
}

class EnrollmentTile extends StatelessWidget {
  const EnrollmentTile({super.key, required this.enrollment, required this.teacher, this.onApprove, this.onReject});
  final Enrollment enrollment;
  final bool teacher;
  final VoidCallback? onApprove;
  final VoidCallback? onReject;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: SoftCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Row(children: [StatusChip(status: enrollment.status), const SizedBox(width: 8), Expanded(child: Text(enrollment.course?.title ?? 'کلاس حذف‌شده', textAlign: TextAlign.right, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: kText)))]),
            const SizedBox(height: 10),
            if (teacher && enrollment.student != null) Text('دانش‌آموز: ${enrollment.student!.name} - ${enrollment.student!.phone}', style: const TextStyle(color: kMuted)),
            if (enrollment.receiptText.isNotEmpty) Text('رسید: ${enrollment.receiptText}', style: const TextStyle(color: kMuted)),
            if (enrollment.rejectReason.isNotEmpty) Text('علت رد: ${enrollment.rejectReason}', style: const TextStyle(color: Colors.red)),
            if (teacher && enrollment.status == 'pending') ...[const SizedBox(height: 12), Row(children: [Expanded(child: OutlinedButton(onPressed: onReject, child: const Text('رد'))), const SizedBox(width: 10), Expanded(child: ElevatedButton(onPressed: onApprove, style: ElevatedButton.styleFrom(backgroundColor: kGreen, foregroundColor: Colors.white), child: const Text('تایید')))])],
          ]),
        ),
      );
}

class TypePill extends StatelessWidget {
  const TypePill({super.key, required this.type});
  final String type;
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9), decoration: BoxDecoration(color: const Color(0xFFE0F7EE), borderRadius: BorderRadius.circular(18)), child: Text(type == 'online' ? 'آنلاین' : 'آفلاین', style: const TextStyle(color: Color(0xFF008D54), fontWeight: FontWeight.w900)));
}

class InfoPill extends StatelessWidget {
  const InfoPill(this.text, {super.key});
  final String text;
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9), decoration: BoxDecoration(color: const Color(0xFFF4F4F5), borderRadius: BorderRadius.circular(18)), child: Text(text, style: const TextStyle(color: kText, fontWeight: FontWeight.w800)));
}

class StatusChip extends StatelessWidget {
  const StatusChip({super.key, required this.status});
  final String status;
  @override
  Widget build(BuildContext context) {
    final color = status == 'approved' ? kGreen : status == 'rejected' ? Colors.red : Colors.orange;
    return Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7), decoration: BoxDecoration(color: color.withOpacity(0.13), borderRadius: BorderRadius.circular(99)), child: Text(statusText(status), style: TextStyle(color: color, fontWeight: FontWeight.w900)));
  }
}

class SettingsMini extends StatefulWidget {
  const SettingsMini({super.key, required this.settings, required this.api, required this.onDone});
  final AppSettings settings;
  final ApiClient api;
  final VoidCallback onDone;
  @override
  State<SettingsMini> createState() => _SettingsMiniState();
}

class _SettingsMiniState extends State<SettingsMini> {
  late final TextEditingController appTitle = TextEditingController(text: widget.settings.appTitle);
  late final TextEditingController teacherName = TextEditingController(text: widget.settings.teacherName);
  late final TextEditingController cardNumber = TextEditingController(text: widget.settings.cardNumber);
  late final TextEditingController cardOwner = TextEditingController(text: widget.settings.cardOwner);
  late final TextEditingController supportPhone = TextEditingController(text: widget.settings.supportPhone);
  late final TextEditingController paymentHelp = TextEditingController(text: widget.settings.paymentHelp);
  bool busy = false;
  @override
  void dispose() { appTitle.dispose(); teacherName.dispose(); cardNumber.dispose(); cardOwner.dispose(); supportPhone.dispose(); paymentHelp.dispose(); super.dispose(); }
  Future<void> save() async {
    setState(() => busy = true);
    try {
      await widget.api.put('/api/settings', {'appTitle': appTitle.text.trim(), 'teacherName': teacherName.text.trim(), 'cardNumber': cardNumber.text.trim(), 'cardOwner': cardOwner.text.trim(), 'supportPhone': supportPhone.text.trim(), 'paymentHelp': paymentHelp.text.trim()});
      widget.onDone();
      if (mounted) toast(context, 'تنظیمات ذخیره شد.');
    } catch (e) { if (mounted) toast(context, e.toString()); } finally { if (mounted) setState(() => busy = false); }
  }
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const SectionTitle('⚙️ تنظیمات'),
        TextField(controller: appTitle, decoration: const InputDecoration(hintText: 'عنوان اپ')),
        const SizedBox(height: 10),
        TextField(controller: teacherName, decoration: const InputDecoration(hintText: 'نام معلم')),
        const SizedBox(height: 10),
        TextField(controller: cardNumber, decoration: const InputDecoration(hintText: 'شماره کارت')),
        const SizedBox(height: 10),
        TextField(controller: cardOwner, decoration: const InputDecoration(hintText: 'نام صاحب کارت')),
        const SizedBox(height: 10),
        TextField(controller: supportPhone, decoration: const InputDecoration(hintText: 'شماره پشتیبانی')),
        const SizedBox(height: 10),
        TextField(controller: paymentHelp, maxLines: 2, decoration: const InputDecoration(hintText: 'راهنمای پرداخت')),
        const SizedBox(height: 12),
        PrimaryButton(text: busy ? 'در حال ذخیره...' : 'ذخیره تنظیمات', onTap: busy ? null : save, color: kPurple),
      ]);
}

Future<void> openCourseForm(BuildContext context, ApiClient api, Course? course, Future<void> Function() onDone) async {
  final title = TextEditingController(text: course?.title ?? '');
  final subject = TextEditingController(text: course?.subject ?? '');
  final grade = TextEditingController(text: course?.grade ?? 'ابتدایی');
  final price = TextEditingController(text: course?.price.toString() ?? '');
  final schedule = TextEditingController(text: course?.schedule ?? '');
  final accessLink = TextEditingController(text: course?.accessLink ?? '');
  final description = TextEditingController(text: course?.description ?? '');
  final resources = TextEditingController(text: course == null ? '' : course.resources.map((r) => '${r.kind}: ${r.title} - ${r.url}').join(' | '));
  String type = course?.type ?? 'online';
  bool isActive = course?.isActive ?? true;
  bool busy = false;
  List<Resource> parseResources() {
    final out = <Resource>[];
    for (final part in resources.text.split('|')) {
      final p = part.trim();
      if (p.isEmpty) continue;
      final dash = p.split('-');
      final first = dash.first.trim();
      final url = dash.length > 1 ? dash.sublist(1).join('-').trim() : '';
      final colon = first.indexOf(':');
      if (colon >= 0) {
        out.add(Resource(kind: first.substring(0, colon).trim(), title: first.substring(colon + 1).trim(), url: url));
      } else {
        out.add(Resource(kind: 'لینک', title: first, url: url));
      }
    }
    return out;
  }
  await Navigator.of(context).push(MaterialPageRoute(builder: (ctx) => Directionality(
        textDirection: TextDirection.rtl,
        child: GradientBackground(
          child: SingleChildScrollView(
            child: StatefulBuilder(builder: (ctx, setLocal) => ScreenPanel(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                    TopBar(title: course == null ? 'کلاس جدید' : 'ویرایش کلاس', onBack: () => Navigator.pop(ctx), backText: 'بستن'),
                    const Text('این اطلاعات برای دانش‌آموز و والدین نمایش داده می‌شود.', textAlign: TextAlign.center, style: TextStyle(color: kMuted)),
                    const SizedBox(height: 18),
                    TextField(controller: title, decoration: const InputDecoration(hintText: 'عنوان کلاس')),
                    const SizedBox(height: 12),
                    TextField(controller: subject, decoration: const InputDecoration(hintText: 'نام درس')),
                    const SizedBox(height: 12),
                    TextField(controller: grade, decoration: const InputDecoration(hintText: 'پایه')),
                    const SizedBox(height: 12),
                    TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(hintText: 'قیمت')),
                    const SizedBox(height: 12),
                    TextField(controller: schedule, decoration: const InputDecoration(hintText: 'زمان برگزاری')),
                    const SizedBox(height: 12),
                    DropdownButtonFormField<String>(value: type, decoration: const InputDecoration(), items: const [DropdownMenuItem(value: 'online', child: Text('آنلاین')), DropdownMenuItem(value: 'offline', child: Text('آفلاین'))], onChanged: (v) => setLocal(() => type = v ?? 'online')),
                    const SizedBox(height: 12),
                    TextField(controller: accessLink, decoration: const InputDecoration(hintText: 'لینک کلاس یا توضیح فایل')),
                    const SizedBox(height: 12),
                    TextField(controller: resources, decoration: const InputDecoration(hintText: 'منابع: PDF: تمرین - لینک | ویدئو: جلسه اول - لینک')),
                    const SizedBox(height: 12),
                    TextField(controller: description, maxLines: 4, decoration: const InputDecoration(hintText: 'توضیحات کلاس')),
                    SwitchListTile(value: isActive, onChanged: (v) => setLocal(() => isActive = v), title: const Text('نمایش برای دانش‌آموز')),
                    const SizedBox(height: 14),
                    PrimaryButton(text: busy ? 'در حال ذخیره...' : 'ذخیره کلاس', color: kPurple, onTap: busy ? null : () async {
                      setLocal(() => busy = true);
                      try {
                        final data = {'title': title.text.trim(), 'subject': subject.text.trim(), 'grade': grade.text.trim(), 'price': price.text.trim(), 'schedule': schedule.text.trim(), 'type': type, 'accessLink': accessLink.text.trim(), 'description': description.text.trim(), 'isActive': isActive, 'resources': parseResources().map((r) => r.toJson()).toList()};
                        if (course == null) { await api.post('/api/courses', data); } else { await api.put('/api/courses/${course.id}', data); }
                        await onDone();
                        if (ctx.mounted) Navigator.pop(ctx);
                      } catch (e) { if (ctx.mounted) toast(ctx, e.toString()); } finally { if (ctx.mounted) setLocal(() => busy = false); }
                    }),
                  ]),
                )),
          ),
        ),
      )));
  title.dispose(); subject.dispose(); grade.dispose(); price.dispose(); schedule.dispose(); accessLink.dispose(); description.dispose(); resources.dispose();
}
